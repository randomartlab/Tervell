/** 不依赖开发服务器的本地产物预览；不提供目录列表。 */
import { createServer } from 'node:http'
import { readFileSync, existsSync, statSync } from 'node:fs'
import { resolve, extname, sep } from 'node:path'
const root=resolve(process.argv[2]||'apps/site/dist'),port=Number(process.env.SITE_PORT||4178)
const types:Record<string,string>={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.woff2':'font/woff2','.txt':'text/plain','.xml':'application/xml'}
createServer((req,res)=>{try{const path=decodeURIComponent(new URL(req.url||'/', 'http://localhost').pathname);let file=resolve(root,'.'+path);if(file!==root&&!file.startsWith(root+sep)){res.writeHead(403);res.end();return}if(existsSync(file)&&statSync(file).isDirectory())file=resolve(file,'index.html');if(!existsSync(file)){res.writeHead(404);res.end('Not found');return}res.writeHead(200,{'content-type':types[extname(file)]||'application/octet-stream'});res.end(readFileSync(file))}catch{res.writeHead(400);res.end()}}).listen(port,'127.0.0.1',()=>console.log('Tervell site preview http://127.0.0.1:'+port))
