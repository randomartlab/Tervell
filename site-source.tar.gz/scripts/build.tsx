import { build } from 'vite'
import { renderToString } from 'react-dom/server'
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { App } from '../src/App'
import { SITE, downloads, pages, features, screenshots } from '../src/content'
const base = process.env.SITE_BASE || '/'
const origin = process.env.SITE_ORIGIN || SITE.origin
const prefix = base === '/' ? '' : base.replace(/\/$/, '')
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
await build({ root, configFile: resolve(root, 'vite.config.ts'), base })
const siteVersion = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8')).version as string
const template = readFileSync(resolve(root, 'dist/index.html'), 'utf8')
const escape = (value: string) => value.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;')
for (const page of pages) {
  const directory = resolve(root, 'dist', '.' + page.path)
  mkdirSync(directory, { recursive: true })
  const head = `<meta name="tervell-site-version" content="${siteVersion}"/><link rel="canonical" href="${origin}${prefix}${page.path}"/><meta property="og:type" content="website"/><meta property="og:locale" content="zh_CN"/><meta property="og:site_name" content="Tervell"/><meta property="og:title" content="${escape(page.title)} · Tervell"/><meta property="og:description" content="${escape(page.description)}"/><meta property="og:image" content="${origin}${prefix}/media/workspace-1280.webp"/><meta property="og:url" content="${origin}${prefix}${page.path}"/><meta name="twitter:card" content="summary_large_image"/>`
  const html = template.replace(/<title>[^<]*<\/title>/, `<title>${page.path === '/' ? 'Tervell · ' + page.title : page.title + ' · Tervell'}</title>`).replace(/<meta name="description"[^>]*\/>/, `<meta name="description" content="${escape(page.description)}"/>`).replace('<!--site-head-->',head).replace('<!--site-html-->', renderToString(<App path={page.path} base={prefix} mirrorReady={process.env.VITE_MIRROR_READY!=='0'}/>))
  writeFileSync(resolve(directory, 'index.html'), html)
}
const checksums = downloads.map(x => `${x.sha256}  ${x.file}`).join('\n') + '\n'
writeFileSync(resolve(root, 'dist/SHA256SUMS.txt'), checksums)
writeFileSync(resolve(root, 'dist/releases.json'), JSON.stringify({ schemaVersion:1, channel:'alpha', desktopVersion:SITE.version, androidVersion:SITE.androidVersion, baselineVerifiedAt:SITE.verifiedAt, sourceArchive:SITE.sourceArchive, sourceTag:'v'+SITE.version, downloads:downloads.map(x=>({...x,mirror:`https://randomai.art/downloads/v${SITE.version}/${x.file}`,github:`${SITE.repository}/releases/download/v${SITE.version}/${x.file}`})) },null,2))
writeFileSync(resolve(root, 'dist/features.json'), JSON.stringify({ baseline:SITE.version, features },null,2))
writeFileSync(resolve(root, 'dist/screenshots.json'), JSON.stringify({ screenshots },null,2))
writeFileSync(resolve(root, 'dist/sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${pages.map(x=>`<url><loc>${origin}${prefix}${x.path}</loc></url>`).join('')}</urlset>`)
writeFileSync(resolve(root, 'dist/robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${origin}${prefix}/sitemap.xml\n`)
copyFileSync(resolve(root,'dist/index.html'),resolve(root,'dist/404.html'))
console.log(`预渲染 ${pages.length} 个页面；发行清单与校验文件已生成。`)
