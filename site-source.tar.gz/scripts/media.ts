import sharp from 'sharp'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { screenshots } from '../src/content'
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..')
const provenance=[]
for(const shot of screenshots){
 const input=resolve(root,'public/media',shot.id+'.png')
 const info=await sharp(input).metadata()
 if(info.width!==shot.width||info.height!==shot.height)throw Error(`截图尺寸与清单不符：${shot.id}`)
 for(const width of[800,1280])await sharp(input).resize({width,withoutEnlargement:true}).webp({quality:85}).toFile(resolve(root,`public/media/${shot.id}-${width}.webp`))
 await sharp(input).webp({quality:88}).toFile(resolve(root,`public/media/${shot.id}.webp`))
 provenance.push({id:shot.id,title:shot.title,source:'本地隔离环境实际应用截图',publisher:'Random / Tervell',capturedAt:shot.capturedAt,version:shot.version,device:shot.device,width:info.width,height:info.height,original:`media/${shot.id}.png`,sha256:createHash('sha256').update(readFileSync(input)).digest('hex'),data:'专门创建的离线演示项目，不含日常会话或密钥',method:shot.method,rights:'用于本产品说明；上游项目、模型供应商的名称与标志仍归各自权利人所有'})
}
writeFileSync(resolve(root,'public/media/provenance.json'),JSON.stringify(provenance,null,2)+'\n')
