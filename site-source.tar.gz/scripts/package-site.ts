/** 将本站与实际用到的品牌源打包，不复制桌面源码或整个依赖树。 */
import { cpSync, mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..')
const output=process.env.SITE_PACKAGE_DIR
if(!output)throw Error('SITE_PACKAGE_DIR 必须指向登记的临时目录')
const stage=resolve(output,'site-source');mkdirSync(stage,{recursive:true})
for(const name of['src','scripts','public','index.html','vite.config.ts'])cpSync(resolve(root,name),resolve(stage,name),{recursive:true})
mkdirSync(resolve(stage,'vendor'),{recursive:true})
for(const[from,to]of[['packages/shared/src/config/brand.ts','brand.ts'],['packages/ui/src/brand/index.tsx','index.tsx'],['packages/ui/src/brand/palette.css','palette.css']]as const)cpSync(resolve(root,'../..',from),resolve(stage,'vendor',to))
const tools=process.env.SITE_TOOLCHAIN_DIR
if(!tools||!existsSync(resolve(tools,'bun.lock')))throw Error('需要已验证的本站固定版本工具链与锁文件')
const pkg=JSON.parse(readFileSync(resolve(tools,'package.json'),'utf8'));pkg.scripts={build:'bun scripts/build.tsx',typecheck:'tsc --noEmit'};writeFileSync(resolve(stage,'package.json'),JSON.stringify(pkg,null,2)+'\n');cpSync(resolve(tools,'bun.lock'),resolve(stage,'bun.lock'))
let vite=readFileSync(resolve(stage,'vite.config.ts'),'utf8').replace('../../packages/ui/src/brand/index.tsx','vendor/index.tsx').replace('../../packages/shared/src/config/brand.ts','vendor/brand.ts');writeFileSync(resolve(stage,'vite.config.ts'),vite)
const css=resolve(stage,'src/style.css');writeFileSync(css,readFileSync(css,'utf8').replace('../../../packages/ui/src/brand/palette.css','../vendor/palette.css'))
writeFileSync(resolve(stage,'tsconfig.json'),JSON.stringify({compilerOptions:{target:'ESNext',module:'Preserve',jsx:'react-jsx',moduleResolution:'bundler',allowImportingTsExtensions:true,verbatimModuleSyntax:true,noEmit:true,strict:true,skipLibCheck:true,lib:['ESNext','DOM','DOM.Iterable'],types:['vite/client','node'],paths:{'@proma/ui/brand':['./vendor/index.tsx'],'@proma/shared/config':['./vendor/brand.ts']}},include:['src','scripts','vendor','vite.config.ts'],exclude:['src/**/*.test.tsx']},null,2))
const archive=resolve(output,'site-source.tar.gz');execFileSync('tar',['-czf',archive,'-C',stage,'.']);const sha=createHash('sha256').update(readFileSync(archive)).digest('hex');writeFileSync(resolve(output,'site-source-sha256.txt'),sha+'  site-source.tar.gz\n');console.log(JSON.stringify({archive,sha256:sha}))
