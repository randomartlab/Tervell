import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'
export default defineConfig({
  resolve: { alias: {
    '@proma/ui/brand': fileURLToPath(new URL('vendor/index.tsx', import.meta.url)),
    '@proma/shared/config': fileURLToPath(new URL('vendor/brand.ts', import.meta.url)),
  } },
  esbuild: { jsx: 'automatic' },
  build: { target: 'es2022', assetsInlineLimit: 0 },
  server: { host: '127.0.0.1', port: 4178 },
})
