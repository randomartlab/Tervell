import React from 'react'
import { createRoot, hydrateRoot } from 'react-dom/client'
import '@fontsource-variable/inter'
import './style.css'
import { App } from './App'
const container = document.getElementById('root')!
const base = import.meta.env.BASE_URL.replace(/\/$/, '')
const path = base && location.pathname.startsWith(base) ? location.pathname.slice(base.length) || '/' : location.pathname
const app = <React.StrictMode><App path={path} base={base} mirrorReady={import.meta.env.VITE_MIRROR_READY!=='0'}/></React.StrictMode>
if (container.children.length) hydrateRoot(container, app)
else createRoot(container).render(app)
