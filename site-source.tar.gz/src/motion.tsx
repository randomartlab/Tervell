import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
export const MOTION = {
  enter: 520,
  control: 180,
  dialog: 220,
  distance: 18,
  easing: 'cubic-bezier(0.22, 1, 0.36, 1)'
} as const;

/** 内容始终可见；只在入视时增强，不以 JS/CSS 隐藏正文等待动画。 */
export function Reveal({
  children,
  className = '',
  delay = 0
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node || !('IntersectionObserver' in window) || !node.animate) return;
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    let animation: Animation | undefined;
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        observer.unobserve(node);
        if (media.matches || document.hidden) return;
        animation = node.animate([{
          opacity: 0.35,
          transform: `translateY(${MOTION.distance}px)`
        }, {
          opacity: 1,
          transform: 'translateY(0)'
        }], {
          duration: MOTION.enter,
          easing: MOTION.easing,
          delay,
          fill: 'backwards'
        });
        animation.finished.then(() => animation?.cancel()).catch(() => {});
      }
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -24px 0px'
    });
    const stop = () => {
      if (media.matches || document.hidden) animation?.cancel();
    };
    observer.observe(node);
    media.addEventListener('change', stop);
    document.addEventListener('visibilitychange', stop);
    return () => {
      observer.disconnect();
      animation?.cancel();
      media.removeEventListener('change', stop);
      document.removeEventListener('visibilitychange', stop);
    };
  }, [delay]);
  return <div ref={ref} className={`reveal ${className}`} data-reveal="">{children}</div>;
}

/** 快速重复点击取消前一段动画，键盘选择保持即时。 */
export function TransitionSurface({
  children,
  id,
  className = ''
}: {
  children: ReactNode;
  id: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    if (!node?.animate || media.matches || document.hidden) return;
    if (document.documentElement.dataset.siteInput === 'keyboard') return;
    const animation = node.animate([{
      opacity: 0.5,
      transform: 'translateY(5px)'
    }, {
      opacity: 1,
      transform: 'translateY(0)'
    }], {
      duration: MOTION.dialog,
      easing: MOTION.easing
    });
    const stop = () => {
      if (document.hidden || media.matches) animation.cancel();
    };
    document.addEventListener('visibilitychange', stop);
    media.addEventListener('change', stop);
    return () => {
      animation.cancel();
      media.removeEventListener('change', stop);
      document.removeEventListener('visibilitychange', stop);
    };
  }, [id]);
  return <div ref={ref} className={className}>{children}</div>;
}
export function InputModality() {
  useEffect(() => {
    const keyboard = () => {
      document.documentElement.dataset.siteInput = 'keyboard';
    };
    const pointer = () => {
      document.documentElement.dataset.siteInput = 'pointer';
    };
    window.addEventListener('keydown', keyboard, true);
    window.addEventListener('pointerdown', pointer, true);
    return () => {
      window.removeEventListener('keydown', keyboard, true);
      window.removeEventListener('pointerdown', pointer, true);
      delete document.documentElement.dataset.siteInput;
    };
  }, []);
  return null;
}
