import { createContext, useContext, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Pause, Play } from 'lucide-react';
export const MOTION = {
  enter: 560,
  control: 180,
  dialog: 220,
  distance: 18,
  easing: 'cubic-bezier(0.22, 1, 0.36, 1)'
} as const;
interface MotionState {
  allowed: boolean;
  enabled: boolean;
  reduced: boolean;
  toggle: () => void;
}
const MotionContext = createContext<MotionState>({
  allowed: true,
  enabled: true,
  reduced: false,
  toggle: () => {}
});

/** 整页共用偏好；停止动效后还原可读终态，不冻结在移动中的位置。 */
export function MotionProvider({
  children
}: {
  children: ReactNode;
}) {
  const [enabled, setEnabled] = useState(true);
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    try {
      setEnabled(localStorage.getItem('tervell-site-motion') !== 'off');
    } catch {}
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () => setReduced(media.matches);
    apply();
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, []);
  const allowed = enabled && !reduced;
  useEffect(() => {
    document.documentElement.dataset.pageMotion = allowed ? 'on' : 'off';
    const visibility = () => {
      document.documentElement.dataset.pagePaused = String(document.hidden);
    };
    visibility();
    document.addEventListener('visibilitychange', visibility);
    return () => {
      document.removeEventListener('visibilitychange', visibility);
      delete document.documentElement.dataset.pageMotion;
      delete document.documentElement.dataset.pagePaused;
    };
  }, [allowed]);
  const toggle = () => setEnabled(previous => {
    const next = !previous;
    try {
      localStorage.setItem('tervell-site-motion', next ? 'on' : 'off');
    } catch {}
    return next;
  });
  return <MotionContext.Provider value={{
    allowed,
    enabled,
    reduced,
    toggle
  }}>{children}</MotionContext.Provider>;
}
export function MotionControl() {
  const {
    allowed,
    reduced,
    toggle
  } = useContext(MotionContext);
  return <button className="motion-control" aria-label="页面动效" aria-pressed={allowed} onClick={toggle} disabled={reduced} title={reduced ? '已跟随系统减少动态效果' : allowed ? '关闭整页动效' : '开启整页动效'}>{allowed ? <Pause size={15} aria-hidden="true" /> : <Play size={15} aria-hidden="true" />}<span>动效</span></button>;
}
export function ReadingProgress() {
  return <div className="reading-progress" aria-hidden="true"><span /></div>;
}

/** 原生 view timeline 优先；旧浏览器仅入场增强，始终保留无 JS 正文。 */
export function Reveal({
  children,
  className = '',
  delay = 0
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const {
    allowed
  } = useContext(MotionContext);
  useEffect(() => {
    const node = ref.current;
    if (!allowed || document.documentElement.dataset.pageMotion === 'off' || !node?.animate || !('IntersectionObserver' in window)) return;
    if (CSS.supports('animation-timeline', 'view()')) return;
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    let animation: Animation | undefined;
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        observer.unobserve(node);
        if (media.matches || document.hidden) return;
        animation = node.animate([{
          opacity: 0.65,
          transform: `translateY(${MOTION.distance}px)`
        }, {
          opacity: 1,
          transform: 'translateY(0)'
        }], {
          duration: MOTION.enter,
          easing: MOTION.easing,
          delay,
          fill: 'backwards'
        });
        animation.finished.then(() => animation?.cancel()).catch(() => {});
      }
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -24px 0px'
    });
    const stop = () => {
      if (media.matches || document.hidden) animation?.cancel();
    };
    observer.observe(node);
    media.addEventListener('change', stop);
    document.addEventListener('visibilitychange', stop);
    return () => {
      observer.disconnect();
      animation?.cancel();
      media.removeEventListener('change', stop);
      document.removeEventListener('visibilitychange', stop);
    };
  }, [allowed, delay]);
  return <div ref={ref} className={`reveal ${className}`} data-reveal="">{children}</div>;
}
export function TransitionSurface({
  children,
  id,
  className = ''
}: {
  children: ReactNode;
  id: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const {
    allowed
  } = useContext(MotionContext);
  useEffect(() => {
    const node = ref.current;
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    if (!allowed || document.documentElement.dataset.pageMotion === 'off' || !node?.animate || media.matches || document.hidden || document.documentElement.dataset.siteInput === 'keyboard') return;
    const animation = node.animate([{
      opacity: 0.5,
      transform: 'translateY(7px)'
    }, {
      opacity: 1,
      transform: 'translateY(0)'
    }], {
      duration: MOTION.dialog,
      easing: MOTION.easing
    });
    const stop = () => {
      if (media.matches || document.hidden) animation.cancel();
    };
    media.addEventListener('change', stop);
    document.addEventListener('visibilitychange', stop);
    return () => {
      animation.cancel();
      media.removeEventListener('change', stop);
      document.removeEventListener('visibilitychange', stop);
    };
  }, [id, allowed]);
  return <div ref={ref} className={className}>{children}</div>;
}
export function InputModality() {
  useEffect(() => {
    const keyboard = () => {
      document.documentElement.dataset.siteInput = 'keyboard';
    };
    const pointer = () => {
      document.documentElement.dataset.siteInput = 'pointer';
    };
    window.addEventListener('keydown', keyboard, true);
    window.addEventListener('pointerdown', pointer, true);
    return () => {
      window.removeEventListener('keydown', keyboard, true);
      window.removeEventListener('pointerdown', pointer, true);
      delete document.documentElement.dataset.siteInput;
    };
  }, []);
  return null;
}
