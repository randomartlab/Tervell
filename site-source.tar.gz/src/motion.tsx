import { useEffect, useRef } from 'react'
import type { ReactNode } from 'react'

export const MOTION = {
  enter: 560,
  stagger: 55,
  control: 180,
  dialog: 260,
  distance: 18,
  easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
} as const

/** 页面级入场编排：仅在首次进入页面/视口时做有密度的节奏揭示，随后保持静止；不设动效开关，自动响应 prefers-reduced-motion。 */
export function MotionRoot({ children }: { children: ReactNode }) {
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)')
    const sync = () => {
      document.documentElement.dataset.pageMotion = media.matches ? 'off' : 'on'
    }
    sync()
    media.addEventListener('change', sync)
    return () => {
      media.removeEventListener('change', sync)
      delete document.documentElement.dataset.pageMotion
    }
  }, [])
  return <>{children}</>
}

/** 分组/区块入场：遵循 StyleKit Scroll Reveal + Stagger Children，只在进入视口时播一次并清理。 */
export function Reveal({
  children,
  className = '',
  delay = 0,
  variant = 'rise',
}: {
  children: ReactNode
  className?: string
  delay?: number
  variant?: 'rise' | 'stage' | 'scale'
}) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const node = ref.current
    if (!node?.animate || !('IntersectionObserver' in window)) return
    const media = matchMedia('(prefers-reduced-motion: reduce)')
    if (media.matches || document.documentElement.dataset.pageMotion === 'off') return
    if (CSS.supports('animation-timeline', 'view()')) return
    let animation: Animation | undefined
    const observer = new IntersectionObserver(
      entries => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue
          observer.unobserve(node)
          if (media.matches || document.hidden) return
          const fromFrame =
            variant === 'stage'
              ? { opacity: 0.72, transform: 'translateY(22px) scale(0.985)' }
              : variant === 'scale'
                ? { opacity: 0.76, transform: 'scale(0.97)' }
                : { opacity: 0.7, transform: `translateY(${MOTION.distance}px)` }
          animation = node.animate([fromFrame, { opacity: 1, transform: 'none' }], {
            duration: MOTION.enter,
            easing: MOTION.easing,
            delay,
            fill: 'backwards',
          })
          animation.finished.then(() => animation?.cancel()).catch(() => {})
        }
      },
      { threshold: 0.08, rootMargin: '0px 0px -24px 0px' },
    )
    const stop = () => {
      if (media.matches || document.hidden) animation?.cancel()
    }
    observer.observe(node)
    media.addEventListener('change', stop)
    document.addEventListener('visibilitychange', stop)
    return () => {
      observer.disconnect()
      animation?.cancel()
      media.removeEventListener('change', stop)
      document.removeEventListener('visibilitychange', stop)
    }
  }, [delay, variant])

  return (
    <div
      ref={ref}
      className={`reveal reveal-${variant} ${className}`}
      data-reveal={variant}
      style={delay ? ({ '--reveal-delay': `${delay}ms` } as React.CSSProperties) : undefined}
    >
      {children}
    </div>
  )
}

/** 切换面交叉淡化与轻微位阶过渡（仅用于交互切换与步骤换页）。 */
export function TransitionSurface({
  children,
  id,
  className = '',
}: {
  children: ReactNode
  id: string
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const node = ref.current
    const media = matchMedia('(prefers-reduced-motion: reduce)')
    if (!node?.animate || media.matches || document.hidden || document.documentElement.dataset.siteInput === 'keyboard') return
    const animation = node.animate(
      [
        { opacity: 0.65, transform: 'translateY(6px)' },
        { opacity: 1, transform: 'translateY(0)' },
      ],
      { duration: MOTION.dialog, easing: MOTION.easing },
    )
    const stop = () => {
      if (media.matches || document.hidden) animation.cancel()
    }
    media.addEventListener('change', stop)
    document.addEventListener('visibilitychange', stop)
    return () => {
      animation.cancel()
      media.removeEventListener('change', stop)
      document.removeEventListener('visibilitychange', stop)
    }
  }, [id])
  return <div ref={ref} className={className}>{children}</div>
}

export function InputModality() {
  useEffect(() => {
    const set = (v: 'keyboard' | 'pointer') => {
      document.documentElement.dataset.siteInput = v
    }
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Tab' || e.key.startsWith('Arrow') || e.key === 'Home' || e.key === 'End') set('keyboard')
    }
    const pointer = () => set('pointer')
    window.addEventListener('keydown', key, true)
    window.addEventListener('pointerdown', pointer, true)
    return () => {
      window.removeEventListener('keydown', key, true)
      window.removeEventListener('pointerdown', pointer, true)
    }
  }, [])
  return null
}
