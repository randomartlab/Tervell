export const SITE = {
  origin: 'https://tervell.randomai.art',
  repository: 'https://github.com/randomartlab/Tervell',
  market: 'https://randomai.art',
  author: 'https://github.com/randomartlab',
  version: '0.19.119', androidVersion: '0.1.22', publishedAt: '2026-11-25T09:02:31Z',
} as const
export interface Download {
  id: 'windows' | 'mac' | 'android'; name: string; version: string; platform: string
  requirements: string; file: string; bytes: number; sha256: string; signing: string
}
export const downloads: Download[] = [
  { id: 'windows', name: 'Windows', version: SITE.version, platform: 'x64 · 安装程序', requirements: '64 位 Windows；本版在 Windows 2025 原生构建与安装验证。', file: 'Tervell-Alpha-0.19.119-windows-x64-setup.exe', bytes: 310964950, sha256: '29fa75a39ac8917f79bc624e957f84e994063dac427c1009a82184fe64fc2d78', signing: 'Alpha 安装包尚未代码签名。' },
  { id: 'mac', name: 'macOS', version: SITE.version, platform: 'Apple Silicon · DMG', requirements: 'macOS 14 或更新版本，Apple M 系列芯片。当前不提供 Intel 版。', file: 'Tervell-Alpha-0.19.119-mac-arm64.dmg', bytes: 467022494, sha256: 'dedd7fc9780114acf7292d6389166e37fe8e6908a6d0f0838f994c46e9d74e1d', signing: '本地 ad-hoc 签名，尚未 Apple 公证。' },
  { id: 'android', name: 'Android', version: SITE.androidVersion, platform: 'Android 8+ · APK', requirements: 'Android 8.0 或更新版本；配合运行中的桌面版使用。', file: 'Tervell-Android-0.1.22-alpha.apk', bytes: 1668322, sha256: '611e7a278101ff30239bf1a7a0cdae9ed6f27fb10aff246ca8c52d5692f210a2', signing: '沿用 Tervell Alpha 签名，可覆盖同渠道版本。' },
]
export function downloadUrl(item: Download, channel: 'mirror' | 'github'): string {
  return channel === 'mirror' ? `/downloads/v${SITE.version}/${item.file}` : `${SITE.repository}/releases/download/v${SITE.version}/${item.file}`
}
export type FeatureState = 'available' | 'developing' | 'planned'
export const stateLabels: Record<FeatureState, string> = { available: '当前可用', developing: '开发中', planned: '规划中' }
export interface Feature {
  id: string; title: string; description: string; state: FeatureState; category: string
  version?: string; help?: string; screenshot?: string
}
export const features: Feature[] = [
  { id: 'workspace', title: '让项目成为工作的起点', description: '把会话、文件、项目记忆和工具放在一起。研究一个问题，或推进一个长期项目，都有清楚的上下文。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#projects', screenshot: 'workspace' },
  { id: 'kernels', title: '熟悉的内核，统一的入口', description: '使用内置 Pi，或安装与启用 ACP 内核。模型、权限、推理档位及内核提供的选项，可以在界面中调整。', state: 'available', category: '内核与模型', version: SITE.version, help: '/guide/#kernels', screenshot: 'kernels' },
  { id: 'mobile', title: '离开电脑，也能接着推进', description: 'Android 扫码连接电脑，切换项目、查看结果、发送任务与调整会话配置。电脑保持执行，手机承接进度。', state: 'available', category: '移动生态', version: SITE.version, help: '/guide/#mobile', screenshot: 'mobile' },
  { id: 'artifacts', title: '每一次回复，都可以继续使用', description: '从回复分叉新的思路，用批注补充问题，导入已有会话，再将结果导出为 Markdown 或 JSON。', state: 'available', category: '成果与交互', version: SITE.version, help: '/guide/#results', screenshot: 'activity' },
  { id: 'extensions', title: '把常用能力放进工作台', description: '通过 Skills、MCP 和扩展组织工具。内置的过程展示、任务视图与导出能力，融入现有界面。', state: 'available', category: '扩展与工具', version: SITE.version, help: '/guide/#tools' },
  { id: 'history', title: '为长任务继续打磨', description: '长历史分批读取、减少重复副本、限制悬浮预览缓存。保留完整记录，同时持续改进资源占用。', state: 'available', category: '持续工作', version: SITE.version, help: '/updates/#v0-19-119' },
  { id: 'work-modes', title: '适合不同工作的模式', description: '围绕中重度工作、编程和临时提问分别整理入口与收尾方式。具体名称和交互仍在打磨。', state: 'developing', category: '工作台' },
  { id: 'experts', title: '专家与专家团', description: '准备可用的专家内容，支持自定义专家与组合协作。使用时快速接入，不使用时保留原生模型体验。', state: 'developing', category: '工作台' },
  { id: 'evolution', title: '可控的记忆与进化', description: '记录长期偏好与改进过程，让用户按对话决定是否注入。功能开启、记忆注入和自动执行分别表达。', state: 'developing', category: '持续工作' },
  { id: 'connection-paths', title: '更清楚的连接选择', description: '将内网与公网分开。公网保留 Random 入口，同时完善自定义隧道与目标配置。', state: 'developing', category: '移动生态' },
  { id: 'result-actions', title: '更顺手的成果处理', description: '完善便捷保存、PDF、分享与截图，强化历史导入、归档浏览和重新开启。', state: 'developing', category: '成果与交互' },
  { id: 'continuation', title: '更稳地接着工作', description: '针对各 CLI 打磨上下文压缩与异常接续，结合当前模型提供下一步建议和显式继续按钮。', state: 'developing', category: '持续工作' },
  { id: 'observatory', title: '看清过程，保持界面清爽', description: '完善 Ask、Agent 观测台、侧栏显隐和更直观的流程配置，让扩展增长时仍能找到工作。', state: 'developing', category: '成果与交互' },
  { id: 'resource-budget', title: '持续完善资源治理', description: '改进历史、过程产物、缓存的回收与压缩，继续减少长时间运行的内存和存储占用。', state: 'developing', category: '持续工作' },
  { id: 'guided-help', title: '随功能一起提供帮助', description: '为新能力提供配图说明和可跳过、可重开的交互引导。', state: 'developing', category: '工作台' },
]
export interface Screenshot {
  id: string; title: string; description: string; width: number; height: number
  version: string; device: 'desktop' | 'mobile'
}
export const screenshots: Screenshot[] = [
  { id: 'workspace', title: '从项目出发，推进完整工作', description: '真实桌面界面，使用离线演示资料展示会话、文件与项目。', width: 3200, height: 2040, version: SITE.version, device: 'desktop' },
  { id: 'activity', title: '思考、工具和结果，各有位置', description: '保留 Tervell 原生字号与布局，按需展开执行过程。', width: 3200, height: 2040, version: SITE.version, device: 'desktop' },
  { id: 'kernels', title: '在界面中管理 Agent 内核', description: '查看已有工具，安装适配器与运行时，了解真实可用状态。', width: 3200, height: 2040, version: SITE.version, device: 'desktop' },
  { id: 'mobile', title: '手机接上同一个工作台', description: 'Android 实际界面，展示演示项目的会话与结果。', width: 1082, height: 2140, version: SITE.androidVersion, device: 'mobile' },
]
export const updates = [
  { id: 'v0-19-119', date: '2026-11-25', version: '0.19.119', title: '打牢多内核与持续工作的基础', kind: '当前 Alpha 基线', items: ['完善 CLI、适配器、运行时的一键安装链路。', '修复 ACP 终端、Windows 命令、超时、取消及部分内核启动问题。', 'Windows 改为原生构建，并在安装后验证界面和运行时。', '优化长历史恢复、Pi 分叉和悬浮预览的内存保留。'], note: '实际流程覆盖 Mac 22 个、Windows 21 个内核，使用隔离回环模型；不代表所有目录条目与厂商账号都已完成验收。' },
  { id: 'mobile-milestone', date: '2026-11-24', version: '移动生态', title: '让工作区与配置延伸到手机', kind: '研发里程碑', items: ['完善多工作区、文件编辑与会话配置。', '对齐模型、推理档位及动态内核选项的控制。', '改进连接恢复和长结果的完整读取。'], note: '这是研发记录，非独立公开发行版；实际支持范围以当前版本说明为准。' },
  { id: 'interaction-milestone', date: '2026-11-22', version: '交互基础', title: '让过程和成果更容易看清', kind: '研发里程碑', items: ['整合过程展示、导出、任务与批注能力。', '在保留原生排版的基础上接入扩展界面。', '建立 Tervell 电脑与手机的共同视觉语言。'], note: '历史阶段记录，不提供旧测试包下载。' },
]
export const guides = [
  { id: 'kernels', title: '启用一个 Agent 内核', short: '内核', screenshot: 'kernels', text: '内核负责执行任务。Tervell 自带 Pi，也可以接入你熟悉的 ACP 工具。', steps: ['打开左侧「Agent 内核」，先检测电脑上已有的工具。', '已有 Codex 等工具时，按界面提示启用对应入口；没有时选择一键安装，等待 CLI、适配器及运行时验证完成。', '进入「全局模型路由」添加模型渠道或登录支持的官方账号。不是所有内核都允许用第三方模型替代官方登录。', '回到会话，选择内核与模型，按需要调整推理、权限和专属选项。'] },
  { id: 'projects', title: '建立你的第一个项目', short: '项目', screenshot: 'workspace', text: 'Agent 会在指定的项目与路径中工作。把相关资料放在一起，方便下次继续。', steps: ['在左侧项目区域新建项目，选择已有文件夹，或使用受管工作区。', '创建会话，描述目标、已有资料和想要的交付物。', '按提示确认工具权限；文件、执行过程和结果都能在同一工作台查看。', '下一次进入原项目继续，或从某条回复分叉讨论另一条思路。'] },
  { id: 'mobile', title: '让手机接上电脑', short: '手机', screenshot: 'mobile', text: '电脑执行任务，手机查看与接续。开始前，确保桌面版正在运行。', steps: ['在电脑的手机连接设置中启用连接，并生成配对二维码。', 'Android 打开扫码，扫描电脑二维码，核对后确认信任。配对资料不要公开分享。', '同一网络可用内网连接；公网使用 Random 入口时按页面指引登录和授权。', '连接后可切换项目、打开会话、发送消息、处理确认或调整内核配置。撤销设备在电脑端完成。'] },
  { id: 'results', title: '把成果保存并继续使用', short: '成果', screenshot: 'activity', text: '一次回答可以是阶段成果，也可以是另一项工作的起点。', steps: ['回复下方可复制、分叉，或选中文字添加批注。', '新建会话时，用「导入会话」浏览已有历史，作为可移除的输入附件。', '使用「导出」保存 Markdown 或 JSON；自定义位置通过电脑文件夹浏览器选择。', 'PDF、快捷分享与截图等增强操作正在开发，以未来发行说明为准。'] },
  { id: 'tools', title: '为项目增加工具与经验', short: '扩展', screenshot: 'workspace', text: '按需要启用 Skills、MCP 与扩展，不必一次配置所有功能。', steps: ['Skills 用于复用任务方法；MCP 用于连接工具与资料来源。', '在对应项目下查看、配置与验证，确认实际访问范围。', '扩展可以在原生界面贡献面板、输入工具或过程展示；当前不保证任意市场插件完全兼容。', '项目记忆可保留项目知识；新的可控进化系统仍在开发。'] },
]
export const pages = [
  { path: '/', title: '完整的 AI 工作台，从电脑延伸到手机', description: '围绕项目组织模型、Agent、资料与产物。' },
  { path: '/features/', title: '功能与体验', description: '多内核、移动接续、工作台与成果处理，了解当前功能和后续方向。' },
  { path: '/download/', title: '下载 Tervell Alpha', description: '下载 Windows、macOS Apple Silicon 和 Android 版本。' },
  { path: '/updates/', title: '更新与路线', description: '查看版本更新、研发里程碑与正在打磨的体验。' },
  { path: '/guide/', title: '快速上手', description: '从内核、模型和项目开始，让手机接上电脑。' },
  { path: '/opensource/', title: '开源与致谢', description: '了解 Proma、Paseo、Magpie 与 Tervell 的关系，以及相关开源许可。' },
]
