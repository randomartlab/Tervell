export const SITE = {
  origin: 'https://tervell.randomai.art',
  repository: 'https://github.com/randomartlab/Tervell',
  market: 'https://randomai.art',
  author: 'https://github.com/randomartlab',
  version: '0.19.122', androidVersion: '0.1.25', verifiedAt: '2026-11-26',
  sourceArchive: 'https://github.com/randomartlab/Tervell/releases/download/v0.19.122/Tervell-0.19.122-source.tar.gz',
} as const
export interface Download {
  id: 'windows' | 'mac' | 'android'; name: string; version: string; platform: string
  requirements: string; file: string; bytes: number; sha256: string; signing: string
}
export const downloads: Download[] = [
  { id: 'windows', name: 'Windows', version: SITE.version, platform: 'x64 · 安装程序', requirements: '64 位 Windows；本版在 Windows 2025 原生构建与安装验证。', file: 'Tervell-Alpha-0.19.122-windows-x64-setup.exe', bytes: 316387729, sha256: 'd36d20cc8a1ef530ca2d1989530eeba92f9f323673ae4bfd620e7670828ca3b3', signing: 'Alpha 安装包尚未代码签名。' },
  { id: 'mac', name: 'macOS', version: SITE.version, platform: 'Apple Silicon · DMG', requirements: 'macOS 14 或更新版本，Apple M 系列芯片。当前不提供 Intel 版。', file: 'Tervell-Alpha-0.19.122-mac-arm64.dmg', bytes: 473180862, sha256: '5ebde4d7abd95b9e0dd677fd555aec1a11fb605eec44246028f7283ed672a7b6', signing: '本地 ad-hoc 签名，尚未 Apple 公证。' },
  { id: 'android', name: 'Android', version: SITE.androidVersion, platform: 'Android 8+ · APK', requirements: 'Android 8.0 或更新版本；配合运行中的桌面版使用。', file: 'Tervell-Android-0.1.25-alpha.apk', bytes: 1680610, sha256: 'd5686c8befcaa8e686d72423d12e99053f1973b88c4003e5af98bdf9609206cb', signing: '沿用 Tervell Alpha 签名，可覆盖同渠道版本。' },
]
export function downloadUrl(item: Download, channel: 'mirror' | 'github'): string {
  return channel === 'mirror' ? `/downloads/v${SITE.version}/${item.file}` : `${SITE.repository}/releases/download/v${SITE.version}/${item.file}`
}
export type FeatureState = 'available' | 'developing' | 'planned'
export const stateLabels: Record<FeatureState, string> = { available: '当前可用', developing: '开发中', planned: '规划中' }
export interface Feature {
  id: string; title: string; description: string; state: FeatureState; category: string
  version?: string; help?: string; screenshot?: string
}
export const features: Feature[] = [
  { id: 'workspace', title: '让项目成为工作的起点', description: '把会话、文件、项目记忆和工具放在一起。研究一个问题，或推进一个长期项目，都有清楚的上下文。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#projects', screenshot: 'workspace' },
  { id: 'kernels', title: '熟悉的内核，统一的入口', description: '使用内置 Pi，或安装与启用 ACP 内核。模型、权限、推理档位及内核提供的选项，可以在界面中调整。', state: 'available', category: '内核与模型', version: SITE.version, help: '/guide/#kernels', screenshot: 'kernels' },
  { id: 'mobile', title: '离开电脑，也能接着推进', description: 'Android 扫码连接电脑，切换项目、查看结果、发送任务与调整会话配置。电脑保持执行，手机承接进度。', state: 'available', category: '移动生态', version: SITE.version, help: '/guide/#mobile', screenshot: 'mobile' },
  { id: 'artifacts', title: '每一次回复，都可以继续使用', description: '从回复分叉新的思路，用批注补充问题，导入已有会话，再将结果导出为 Markdown 或 JSON。', state: 'available', category: '成果与交互', version: SITE.version, help: '/guide/#results', screenshot: 'activity' },
  { id: 'extensions', title: '把常用能力放进工作台', description: '通过 Skills、MCP 和扩展组织工具。内置的过程展示、任务视图与导出能力，融入现有界面。', state: 'available', category: '扩展与工具', version: SITE.version, help: '/guide/#tools' },
  { id: 'history', title: '为长任务继续打磨', description: '长历史分批读取、减少重复副本、限制悬浮预览缓存。保留完整记录，同时持续改进资源占用。', state: 'available', category: '持续工作', version: SITE.version, help: '/updates/#v0-19-122' },
  { id: 'work-modes', title: 'Work／Code／速问', description: '左侧顶部三种模式：Work 适配中重度工作，Code 专注编程，速问适合临时提问并快速归档。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#projects' },
  { id: 'experts', title: '专家与专家团', description: '内置 315 个专家、8 个团队，可查看正文、来源与依赖，并创建自己的角色与团队。未选择时不加入角色约定；不是 WorkBuddy 官方全库。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#experts' },
  { id: 'evolution', title: '记忆与进化', description: '本地管理事实与偏好，提取、使用和会话注入分别控制，候选确认后才注入；不改变模型权重。', state: 'available', category: '持续工作', version: SITE.version, help: '/guide/#memory' },
  { id: 'connection-paths', title: '内网与公网连接', description: '内网直接配对；公网默认 Random 中转，支持自定义 SSH/HTTPS 隧道。', state: 'available', category: '移动生态', version: SITE.version, help: '/guide/#mobile' },
  { id: 'result-actions', title: '成果处理与归档重开', description: '桌面保存回复、导出 Markdown／PDF／PNG；分享为复制正文。会话可归档、浏览快照后重开。Android 支持 Markdown 保存，不提供原生 PDF／PNG 导出。', state: 'available', category: '成果与交互', version: SITE.version, help: '/guide/#results' },
  { id: 'continuation', title: '同模型建议与点击继续', description: '能确认本轮实际模型时提供三条接续建议；点击「继续」发起新请求。建议可能产生额外模型费用，不是无限后台重试。', state: 'available', category: '持续工作', version: SITE.version, help: '/guide/#results' },
  { id: 'observatory', title: 'Agent 观测台与过程透明', description: '默认开启的观测台展示任务状态与父子关系；CLI Ask/审批有针对性交互设计。', state: 'available', category: '成果与交互', version: SITE.version, help: '/guide/#tools' },
  { id: 'resource-budget', title: '缓存回收与磁盘管理', description: '设置中管理磁盘与启动缓存回收；长历史分批读取。仅回收可再生内容，低内存目标仍在打磨，不提供全局内存硬配额。', state: 'available', category: '持续工作', version: SITE.version, help: '/guide/#controls' },
  { id: 'guided-help', title: '交互式引导与帮助', description: '首次欢迎页提供核心 7 步与专题引导；可暂停、恢复、跳过和重播，定位软件中的真实入口。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#onboarding', screenshot: 'onboarding' },
  { id: 'migration', title: '本机工作记录迁移', description: '导入 Codex、Claude Code、Gemini CLI、Qwen Code、Pi、Paseo、WorkBuddy 的已支持格式，先预览再确认。源文件只读；未知数据库与 ZIP 不作兼容承诺。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#migration', screenshot: 'migration' },
  { id: 'relay', title: '跨 CLI 协作接力', description: '单页安排 1–8 个阶段的 CLI、模型和职责，逐阶段生成完整交接并处理 Ask 与审批；安卓可控制电脑已创建的路线。', state: 'available', category: '内核与模型', version: SITE.version, help: '/guide/#relay', screenshot: 'relay' },
  { id: 'office', title: '办公文件编辑与批注', description: '0.19.123 分支已完成 Mac 与安卓内网验收，Windows 最终结果待收取。DOCX 段落、PPTX 文本和普通 XLSX 单元格可编辑；不提供完整 Office 排版，XLSX 不写原生批注。', state: 'developing', category: '工作台', version: '0.19.123', help: '/guide/#office', screenshot: 'office' },
  { id: 'sidebar-customize', title: '侧栏项目显隐', description: '选择左侧菜单哪些项目显示。隐藏入口不会撤销权限或取消任务；功能启停另行控制。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#controls', screenshot: 'controls' },
  { id: 'switch-info', title: '开关用途说明', description: '每项开关带用途说明，解释作用范围、关闭影响、资源与模型用量。查看说明不会改变开关状态。', state: 'available', category: '工作台', version: SITE.version, help: '/guide/#controls' },
  { id: 'resource-next', title: '继续降低长任务资源占用', description: '在已交付缓存回收基础上，继续改进长历史的驻留内存、过程产物与压缩机制。尚未达到全部低内存目标，不承诺上线日期。', state: 'developing', category: '持续工作', help: '/updates/#roadmap' },
]
export interface Screenshot {
  id: string; title: string; description: string; width: number; height: number
  version: string; device: 'desktop' | 'mobile'; capturedAt: string; method: string
}
export const screenshots: Screenshot[] = [
  { id: 'workspace', title: '从项目出发，推进完整工作', description: '0.19.119 桌面演示项目历史截图，用于说明会话、文件与项目关系；新版模式与入口见新增截图。', width: 3200, height: 2040, version: '0.19.119', device: 'desktop', capturedAt: '2026-11-25', method: 'macOS arm64 正式安装包，通过 CDP 截图' },
  { id: 'activity', title: '思考、工具和结果，各有位置', description: '0.19.119 桌面演示项目历史截图，展示执行过程与批注布局。', width: 3200, height: 2040, version: '0.19.119', device: 'desktop', capturedAt: '2026-11-25', method: 'macOS arm64 正式安装包，通过 CDP 截图' },
  { id: 'kernels', title: '在界面中管理 Agent 内核', description: '0.19.119 内核目录历史截图；不以目录条目证明所有工具已验收。', width: 3200, height: 2040, version: '0.19.119', device: 'desktop', capturedAt: '2026-11-25', method: 'macOS arm64 正式安装包，通过 CDP 截图' },
  { id: 'mobile', title: '手机接上同一个工作台', description: 'Android 0.1.22 演示项目历史截图，展示手机查看同一会话。', width: 1082, height: 2140, version: '0.1.22', device: 'mobile', capturedAt: '2026-11-25', method: 'Android 正式 APK 的实际 WebView，通过 CDP 截图' },
  { id: 'onboarding', title: '从真实工作台开始上手', description: '0.19.122 隔离欢迎页，可进入引导、稍后恢复或跳过。', width: 3372, height: 1890, version: '0.19.122', device: 'desktop', capturedAt: '2026-11-26', method: 'Mac 0.19.122 验收截图 mac122-welcome.png' },
  { id: 'controls', title: '按自己的习惯整理工作台', description: '0.19.122 功能与侧栏开关实际页面。开关含用途说明，功能启停与入口显隐分别管理。', width: 3372, height: 1890, version: '0.19.122', device: 'desktop', capturedAt: '2026-11-26', method: 'Mac 0.19.122 验收截图 mac122-features.png' },
  { id: 'migration', title: '先预览，再导入已有工作', description: '0.19.122 迁移入口实际空状态；支持格式与导入完整性以版本说明为准，不以空页面证明已迁移。', width: 3372, height: 1890, version: '0.19.122', device: 'desktop', capturedAt: '2026-11-26', method: 'Mac 0.19.122 验收截图 mac122-migration.png' },
  { id: 'relay', title: '把不同 CLI 接成一条工作路线', description: '0.19.122 协作接力入口实际空状态；不是四阶段已运行的截图，链路验收使用回环模型。', width: 3372, height: 1890, version: '0.19.122', device: 'desktop', capturedAt: '2026-11-26', method: 'Mac 0.19.122 验收截图 mac122-relay.png' },
  { id: 'office', title: '开发中：DOCX 编辑与原生批注', description: '0.19.123 分支的 Mac 隔离实际画面；不属于 0.19.122 下载包。', width: 3840, height: 1890, version: '0.19.123', device: 'desktop', capturedAt: '2026-11-26', method: 'Mac 0.19.123 验收截图 mac-packaged-final/office-docx.png' },
]
export const updates = [
  { id: 'v0-19-123-preview', date: '2026-11-26', version: '0.19.123', title: '办公文件与侧栏修复：跨平台验收中', kind: '开发进展', items: ['DOCX 已有段落、PPTX 已有文本及 XLSX 普通单元格结构化编辑。', 'DOCX 段落级、PPTX 幻灯片级原生批注；XLSX 公式只读且不写原生批注。', '修复模式选中态对比度与「更多功能」菜单交互。'], note: 'Mac 实际包与 Android 0.1.26 内网操控已通过；Windows 最终原生安装及公网手机结果待收取，当前下载仍为 0.19.122／0.1.25。' },
  { id: 'v0-19-122', date: '2026-11-26', version: '0.19.122', title: '专家、协作接力与本机记录迁移', kind: '当前 Alpha 基线', items: ['Work／Code／速问三种模式、315 个专家与 8 个团队，支持自定义内容。', '记忆与进化候选、图形化做事方法、Agent 观测台与可配置侧栏。', '桌面 PDF／PNG／Markdown 导出、保存回复、复制分享、归档重开。', '导入本机工具已支持的历史格式，来源只读，预览后确认。', '配置多阶段 CLI 协作接力，手机处理电脑路线的审批与停止。', '首次交互引导、主题命令颜色、开关说明与内网／自定义公网连接。'], note: 'Mac／Windows 各 21/21 外部 CLI 的工具、写文件、续聊、取消和关闭通过；1234 通过、1 平台跳过、0 失败。CLI 与四阶段接力使用回环固定模型，不代表厂商账号或全部线上模型已验收。含 37 条 WorkBuddy 来源内容，非官方全库；迁移与低内存目标仍有明确边界。' },
  { id: 'v0-19-119', date: '2026-11-25', version: '0.19.119', title: '打牢多内核与持续工作的基础', kind: '历史版本', items: ['完善 CLI、适配器、运行时的一键安装链路。', '修复 ACP 终端、Windows 命令、超时、取消及部分内核启动问题。', 'Windows 改为原生构建，并在安装后验证界面和运行时。', '优化长历史恢复、Pi 分叉和悬浮预览的内存保留。'], note: '实际流程覆盖 Mac 22 个、Windows 21 个内核，使用隔离回环模型；不代表所有目录条目与厂商账号都已完成验收。' },
  { id: 'mobile-milestone', date: '2026-11-24', version: '移动生态', title: '让工作区与配置延伸到手机', kind: '研发里程碑', items: ['完善多工作区、文件编辑与会话配置。', '对齐模型、推理档位及动态内核选项的控制。', '改进连接恢复和长结果的完整读取。'], note: '这是研发记录，非独立公开发行版；实际支持范围以当前版本说明为准。' },
  { id: 'interaction-milestone', date: '2026-11-22', version: '交互基础', title: '让过程和成果更容易看清', kind: '研发里程碑', items: ['整合过程展示、导出、任务与批注能力。', '在保留原生排版的基础上接入扩展界面。', '建立 Tervell 电脑与手机的共同视觉语言。'], note: '历史阶段记录，不提供旧测试包下载。' },
]
export const guides = [
  { id: 'kernels', title: '启用一个 Agent 内核', short: '内核', screenshot: 'kernels', text: '内核负责执行任务。Tervell 自带 Pi，也可以接入你熟悉的 ACP 工具。', steps: ['打开左侧「Agent 内核」，先检测电脑上已有的工具。', '已有 Codex 等工具时，按界面提示启用对应入口；没有时选择一键安装，等待 CLI、适配器及运行时验证完成。', '进入「全局模型路由」添加模型渠道或登录支持的官方账号。不是所有内核都允许用第三方模型替代官方登录。', '回到会话，选择内核与模型，按需要调整推理、权限和专属选项。'] },
  { id: 'projects', title: '按工作选择 Work／Code／速问', short: '模式', screenshot: 'controls', text: '三种模式决定工作入口；底层内核与模型仍由你选择。', steps: ['在左侧顶部选择模式：Work 适配综合工作，Code 面向编程，速问用于临时提问。', 'Code 须选择项目路径；Work 未选项目时使用私有收件箱，速问不运行独立团队。', '描述目标、资料与交付物，按提示确认工具权限。', '会话三点或右键可归档；在「已归档对话」查看快照，重新开启后继续原会话。'] },
  { id: 'mobile', title: '按网络选择手机连接方式', short: '手机', screenshot: 'mobile', text: 'Android 0.1.25 配合在线桌面 0.19.122 使用。配图为 0.1.22 历史界面。', steps: ['电脑设置 → 远程连接 → 安卓远程；同网使用内网板块，生成二维码并在手机确认信任。', '公网板块可选默认 Random 入口或自定义 SSH／HTTPS 等目标；Random 入口按实际页面登录授权。', '连接后切换项目、发任务、处理 Ask／审批和继续；协作接力仅控制电脑已创建并授权的路线。', '已验收 Android→Mac 内网、Android→Windows 自定义公网。任意网络和默认官方中转不能据此视为全部验收。'] },
  { id: 'results', title: '把成果保存，再接着推进', short: '成果', screenshot: 'activity', text: '在回复底部保存和继续，在会话头部选择导出。配图为 0.19.119 历史界面。', steps: ['回复下方复制、分叉、保存，或选中文字添加批注；更多功能 → 已保存回复可集中查看。', '会话头部「导出」选择 Markdown、PDF 或 PNG；PDF／PNG 为桌面原生输出，Android 支持 Markdown 保存。', '快速分享复制正文，不会自动上传为公开链接；新建会话可浏览并导入已有记录。', '能确认本轮实际模型时显示三条接续建议；点击「继续」发起新请求，不会无限后台自动重试，建议可能产生额外费用。'] },
  { id: 'tools', title: '把工具与做事方法接进来', short: '方法', screenshot: 'controls', text: 'Skills、MCP、方法与观测台各有职责，按需要启用。', steps: ['Skills 复用任务方法，MCP 连接工具与资料；在项目范围内查看、配置与验证。', '输入框「做事方法」或更多功能 → 做事方法，可编辑步骤和只读 MCP 预读。', '宿主执行已授权的只读预读，其余自然语言步骤交由同一 CLI 遵循，不是任意脚本工作流。', '左栏 Agent 观测台查看任务状态与父子关系；Ask 回答和权限审批分别处理，不展示模型隐藏思维链。'] },
  { id: 'experts', title: '选用或创建自己的专家与团队', short: '专家', screenshot: 'controls', text: '315 个专家、8 个团队可查正文、来源与依赖；包含部分 WorkBuddy 来源，不是官方全库。', steps: ['点击输入框上方「专家」，或更多功能 → 专家与专家团。', '阅读完整内容、来源、所需工具与当前依赖状态，确认适合任务。', '显式选择专家／团队后再开始；独立团队用于 Work／Code，依赖不满足时会阻止召唤。', '在同一页面创建自定义专家和组合团队。不选择专家或方法时，不加入相应角色约定。'] },
  { id: 'memory', title: '由你确认什么进入下一轮', short: '记忆', screenshot: 'controls', text: '记忆与进化是本地事实／偏好管理，不是模型权重训练。', steps: ['更多功能 → 记忆与进化，查看记录及候选内容。', '分别控制提取、使用，并在每个会话决定是否注入；候选确认后才可使用。', '输入框上方可切换记忆、查看候选或选择「原生运行」。', '原生运行从下一轮停止 Tervell 新增角色、记忆、方法和建议；不能清除 CLI 已读历史，也不控制 CLI 自有记忆。'] },
  { id: 'relay', title: '让多个 CLI 按阶段交接', short: '接力', screenshot: 'relay', text: '在同一页面安排路线与审批，不需要来回复制阶段输出。截图为空状态，实际链路另有验收。', steps: ['更多功能 → 协作接力，明确工作空间、目标和各阶段职责。', '配置 1–8 个阶段的 CLI 与实际模型，验证后保存并显式启动；全局最多一条活动路线、同时一个实际 CLI。', '上阶段完成且工具收束后生成带 SHA-256 的完整交接文件，下阶段读取后继续。', '在此处理 Ask、审批与停止，或打开原会话。Android 可控制电脑已创建路线；停止不会自动跳到下一阶段。'] },
  { id: 'migration', title: '先预览，再导入本机历史', short: '迁移', screenshot: 'migration', text: '导入记录快照与来源信息，原始文件保持只读。并非搬迁账号或恢复原 CLI 运行进程。', steps: ['更多功能 → 导入本机工作记录，或「浏览并导入已有对话 → 本机工具导入」。', '选择来源、发现或选择文件，再预览内容。已适配部分 Codex、Claude、Gemini、Qwen、Pi、Paseo 与 WorkBuddy 格式。', '确认后导入完整快照，保留来源摘要和 raw，支持去重与失败回滚。WorkBuddy 支持 Markdown 与已识别消息结构；未知数据库、timeline 和 ZIP 会拒绝。', '不导入密钥、登录态、MCP 凭据或自动授权；原工作路径只作来源信息，继续前另选当前项目及权限。'] },
  { id: 'controls', title: '整理侧栏，了解每个开关', short: '开关', screenshot: 'controls', text: '入口显隐、功能启停和权限是三件事，可分别管理。', steps: ['更多功能／设置 → 功能与侧栏开关。', '点击每项右侧信息图标，查看用途、作用范围、关闭影响、资源与模型用量；查看不会更改设置。', '「侧栏项目显示」决定导航是否可见，隐藏不取消任务或撤销权限。', '设置 → 磁盘管理配合启动缓存回收；只清理可再生内容，不删除唯一正文、附件或归档，低内存目标仍在推进。'] },
  { id: 'onboarding', title: '在真实界面完成第一次上手', short: '引导', screenshot: 'onboarding', text: '核心 7 步及专题引导定位软件的真实入口，可暂停、恢复和跳过。', steps: ['首次欢迎页选择「进入工作台并开始引导」，也可先使用、稍后再学。', '按锚点认识模型与内核、三种模式、输入回复、归档和开关。', '更多功能 → 帮助与上手 → 真实页面交互引导，或设置 → Tervell 新手引导，可恢复或重播。', '引导不会自动安装、登录、授予权限或发送任务。网页步骤浏览只是说明，不控制你的软件。'] },
  { id: 'office', title: '开发进展：办公文件编辑与批注', short: '办公', screenshot: 'office', text: '0.19.123／Android 0.1.26 的能力预览；Mac 与安卓内网已验收，Windows 最终结果待收取，0.19.122 下载不包含它。', steps: ['Work／Code 右侧文件树打开文档；Office 切到「编辑与批注」。手机从工作区 → 项目 → 文件进入。', 'DOCX 修改已有正文／表格段落并加整段原生批注；PPTX 修改已有文本并加幻灯片级批注，保留布局与媒体。', 'XLSX 只改已有普通文本／数字，公式等保持只读，不提供原生批注或公式计算引擎。Markdown 选区批注加入草稿，不自动发送模型。', '保存前核对原文摘要，外部修改则保留草稿并拒绝覆盖。复杂保护／修订结构只读或拒绝，不是完整 Office 排版套件。'] },
]
export const pages = [
  { path: '/', title: '完整的 AI 工作台，从电脑延伸到手机', description: '围绕项目组织模型、Agent、资料与产物。' },
  { path: '/features/', title: '功能与体验', description: '多内核、移动接续、工作台与成果处理，了解当前功能和后续方向。' },
  { path: '/download/', title: '下载 Tervell Alpha', description: '下载 Windows、macOS Apple Silicon 和 Android 版本。' },
  { path: '/updates/', title: '更新与路线', description: '查看版本更新、研发里程碑与正在打磨的体验。' },
  { path: '/guide/', title: '快速上手', description: '从内核、模型和项目开始，让手机接上电脑。' },
  { path: '/opensource/', title: '开源与致谢', description: '了解 Proma、Paseo、Magpie 与 Tervell 的关系，以及相关开源许可。' },
]
