import { describe, expect, test } from 'bun:test';
import { renderToString } from 'react-dom/server';
import { App } from './App';
import { downloads, downloadUrl, features, guides, pages, screenshots, SITE } from './content';
describe('Given 0.19.131 公开 Alpha 内容', () => {
  test('When 生成三平台下载 Then 文件、摘要、版本和镜像对应同一发行', () => {
    expect(downloads).toHaveLength(3);
    expect(downloads.find(x => x.id === 'android')?.version).toBe('0.1.29');
    for (const item of downloads) {
      expect(item.sha256).toMatch(/^[a-f0-9]{64}$/);
      expect(item.bytes).toBeGreaterThan(1_000_000);
      expect(downloadUrl(item, 'github')).toBe(`${SITE.repository}/releases/download/v0.19.131/${item.file}`);
      expect(downloadUrl(item, 'mirror')).toBe(`/downloads/v0.19.131/${item.file}`);
    }
  });
  test('When 浏览发行内容 Then 平台候选状态与截图来源保持真实', () => {
    const office = features.find(x => x.id === 'office');
    expect(office?.state).toBe('available');
    expect(office?.version).toBe('0.19.131');
    const windows = downloads.find(x => x.id === 'windows')!;
    expect(windows.file).toContain('cross-candidate');
    expect(windows.requirements).toContain('尚未在 Windows');
    const downloadPage = renderToString(<App path="/download/" />);
    expect(downloadPage).toContain('候选 · 未原生验收');
    expect(downloads.every(x => x.version === SITE.version || x.version === SITE.androidVersion)).toBe(true);
    for (const id of ['experts', 'work-modes', 'evolution', 'result-actions', 'observatory', 'continuation', 'relay', 'migration']) expect(features.find(x => x.id === id)?.state).toBe('available');
    for (const item of features) {
      if (item.state === 'available') expect(item.version).toBe(SITE.version);
      if (item.help?.startsWith('/guide/#')) expect(guides.some(g => '#'+g.id === item.help!.slice('/guide/'.length))).toBe(true);
      if (item.screenshot) expect(screenshots.some(s => s.id === item.screenshot)).toBe(true);
    }
    expect(screenshots.find(x => x.id === 'workspace')?.version).toBe('0.19.119');
    expect(screenshots.find(x => x.id === 'mobile')?.version).toBe('0.1.22');
    expect(screenshots.find(x => x.id === 'relay')?.version).toBe('0.19.122');
    expect(screenshots.find(x => x.id === 'archive131')?.version).toBe(SITE.version);
  });
  test('When 禁用 JavaScript Then 所有页面具有可读标题与实质内容', () => {
    for (const page of pages) {
      const html = renderToString(<App path={page.path} />);
      expect(html).toMatch(/<h1(?:\s[^>]*)?>/);
      expect(html).toContain('id="main-content"');
      expect(html).not.toContain('undefined');
      expect(html.length).toBeGreaterThan(5000);
    }
    const guide = renderToString(<App path="/guide/" />);
    expect(guide).toContain('检测电脑上已有的工具');
    expect(guide).toContain('官方账号');
  });
  test('When 部署子目录且镜像未就绪 Then 导航与图片同前缀且不提供虚假下载', () => {
    const html = renderToString(<App path="/download/" base="/Tervell" mirrorReady={false} />);
    expect(html).toContain('href="/Tervell/features/"');
    expect(html).toContain('镜像正在准备');
    expect(html).toContain('disabled=""');
    expect(html).toContain('https://github.com/randomartlab/Tervell/releases/download/');
    const home = renderToString(<App base="/tervell" />);
    expect(home).toContain('src="/tervell/media/workspace-1280.webp"');
    expect(home).not.toContain('/tervell/tervell/');
  });
  test('When 首屏展示真实场景 Then 可选择项目、过程和内核且正文不依赖动效', () => {
    const html = renderToString(<App />);
    expect(html).toContain('选择工作台展示场景');
    for (const label of ['项目与资料', '执行过程', '内核与模型']) expect(html).toContain(label);
    expect(html).toContain('data-reveal="stage"');
    expect(html).not.toContain('style="opacity:0');
    expect(html).not.toContain('tone-sand');
    expect(html).not.toContain('tone-lilac');
    expect(html).not.toContain('aria-label="页面动效"');
    expect(html).not.toContain('reading-progress');
    expect(html).toContain('aria-label="外观模式"');
    expect(html).toContain('aria-label="工作流程界面"');
    for (const label of ['项目与资料', '内核与模型', '过程与成果']) expect(html).toContain(`aria-label="展示${label}"`);
    expect(html).toContain('aria-expanded="true"');
    expect(html).toContain('id="story-detail-kernels" hidden=""');
    expect(html).not.toContain('phone-orbit');
    expect(html).toContain('bento-section');
  });
  test('When 打开帮助 Then 可按目标定位并以独立媒体区域查看完整截图', () => {
    const html = renderToString(<App path="/guide/" />);
    expect(html).toContain('role="tablist"');
    expect(html).toContain('aria-label="选择上手目标"');
    expect(html).toContain('aria-controls="guide-panel"');
    expect(html).toContain('role="tabpanel"');
    expect(html).toContain('按步骤浏览');
    expect(html).toContain('在软件中找到这里');
    expect(html).toContain('class="guide-media"');
    expect(html).not.toContain('margin-right:-');
  });
  test('When 读取更新 Then 已验证范围和开发状态保持清楚', () => {
    const html = renderToString(<App path="/updates/" />);
    expect(html).toContain('Mac 22 个、Windows 21 个');
    expect(html).toContain('研发里程碑');
    expect(html).toContain('不承诺上线日期');
    expect(html).not.toContain('完美兼容');
  });
});
