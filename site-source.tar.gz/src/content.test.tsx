import { describe, expect, test } from 'bun:test'
import { renderToString } from 'react-dom/server'
import { App } from './App'
import { downloads, downloadUrl, features, pages, SITE } from './content'

describe('Given 0.19.119 公开 Alpha 内容', () => {
  test('When 生成三平台下载 Then 文件、摘要、版本和镜像对应同一发行', () => {
    expect(downloads).toHaveLength(3)
    expect(downloads.find(x=>x.id==='android')?.version).toBe('0.1.22')
    for (const item of downloads) {
      expect(item.sha256).toMatch(/^[a-f0-9]{64}$/)
      expect(item.bytes).toBeGreaterThan(1_000_000)
      expect(downloadUrl(item,'github')).toBe(`${SITE.repository}/releases/download/v0.19.119/${item.file}`)
      expect(downloadUrl(item,'mirror')).toBe(`/downloads/v0.19.119/${item.file}`)
    }
  })
  test('When 查看当前功能 Then 其他分支能力不能提前升级为可用', () => {
    for (const id of ['experts','work-modes','evolution','result-actions','observatory','continuation']) expect(features.find(x=>x.id===id)?.state).toBe('developing')
    for (const item of features.filter(x=>x.state==='available')) { expect(item.version).toBe('0.19.119'); expect(item.help).toStartWith('/') }
  })
  test('When 禁用 JavaScript Then 所有页面具有可读标题与实质内容', () => {
    for (const page of pages) {
      const html=renderToString(<App path={page.path}/>)
      expect(html).toContain('<h1>')
      expect(html).toContain('id="main-content"')
      expect(html).not.toContain('undefined')
      expect(html.length).toBeGreaterThan(5000)
    }
    const guide=renderToString(<App path="/guide/"/>)
    expect(guide).toContain('检测电脑上已有的工具')
    expect(guide).toContain('官方账号')
  })
  test('When 读取更新 Then 已验证范围和开发状态保持清楚', () => {
    const html=renderToString(<App path="/updates/"/>)
    expect(html).toContain('Mac 22 个、Windows 21 个')
    expect(html).toContain('研发里程碑')
    expect(html).toContain('暂不提供上线日期')
    expect(html).not.toContain('完美兼容')
  })
})
