import { createContext, useContext, useEffect, useRef, useState, useId } from 'react';
import type { AnchorHTMLAttributes, ReactNode } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { ArrowDown, ArrowLeft, ArrowRight, Check, ChevronLeft, ChevronRight, Copy, Download as DownloadIcon, ExternalLink, FileText, Github, Layers3, Menu, Monitor, Plus, Smartphone, Sparkles, Sun, Terminal, X, ZoomIn, ZoomOut } from 'lucide-react';
import { BrandMark } from '@proma/ui/brand';
import { SITE, downloads, downloadUrl, features, guides, screenshots, stateLabels, updates } from './content';
import type { Feature, FeatureState } from './content';
import { InputModality, MotionProvider, MotionControl, ReadingProgress, Reveal, TransitionSurface } from './motion';
interface SiteContextValue {
  base: string;
  mirrorReady: boolean;
}
const SiteContext = createContext<SiteContextValue>({
  base: '',
  mirrorReady: true
});
function SiteLink({
  href = '',
  ...props
}: AnchorHTMLAttributes<HTMLAnchorElement>) {
  const {
    base
  } = useContext(SiteContext);
  return <a href={href.startsWith('/') && !href.startsWith('//') && !href.startsWith('/downloads/') ? base + href : href} {...props} />;
}
function External({
  href,
  children,
  className
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return <SiteLink href={href} target="_blank" rel="noopener noreferrer" className={className}>{children}</SiteLink>;
}
export function Status({
  state
}: {
  state: FeatureState;
}) {
  return <span className={`status ${state}`}>{stateLabels[state]}</span>;
}
function LinkArrow({
  href,
  children
}: {
  href: string;
  children: ReactNode;
}) {
  return <SiteLink className="text-link" href={href}>{children}<ArrowRight size={16} /></SiteLink>;
}
function ThemePicker() {
  const [theme, setTheme] = useState('system');
  useEffect(() => {
    try {
      setTheme(localStorage.getItem('tervell-site-theme') || 'system');
    } catch {}
  }, []);
  useEffect(() => {
    const media = matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      document.documentElement.dataset.theme = theme === 'system' ? media.matches ? 'dark' : 'light' : theme;
    };
    apply();
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [theme]);
  return <label className="theme-picker"><span className="sr-only">外观</span><Sun size={16} /><select aria-label="外观" value={theme} onChange={e => {
      setTheme(e.target.value);
      try {
        localStorage.setItem('tervell-site-theme', e.target.value);
      } catch {}
    }}><option value="system">跟随系统</option><option value="light">浅色</option><option value="dark">深色</option></select></label>;
}
function Header({
  path
}: {
  path: string;
}) {
  const [open, setOpen] = useState(false);
  const items = [{
    href: '/features/',
    label: '功能与体验'
  }, {
    href: '/updates/',
    label: '更新与路线'
  }, {
    href: '/guide/',
    label: '快速上手'
  }];
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);
  return <header className="site-header"><div className="nav-wrap"><SiteLink className="wordmark" href="/" aria-label="Tervell 首页"><BrandMark width={30} height={30} /><span>Tervell</span></SiteLink><nav className="desktop-nav" aria-label="主导航">{items.map(x => <SiteLink key={x.href} href={x.href} aria-current={path === x.href ? 'page' : undefined}>{x.label}</SiteLink>)}</nav><div className="nav-actions"><MotionControl /><External href={SITE.repository} className="github-nav"><Github size={18} /><span>GitHub</span></External><SiteLink className="button small primary" href="/download/"><span>下载 <span className="alpha-label">Alpha</span></span><ArrowDown size={15} /></SiteLink><button className="icon-button menu-toggle" aria-label={open ? '关闭导航' : '打开导航'} aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button></div></div>{open && <nav id="mobile-navigation" className="mobile-nav" aria-label="手机导航">{items.map(x => <SiteLink key={x.href} href={x.href}>{x.label}</SiteLink>)}<SiteLink href="/opensource/">开源与致谢</SiteLink><External href={SITE.repository}>GitHub</External></nav>}<ReadingProgress /></header>;
}
export function ScreenshotView({
  id,
  eager = false,
  className = ''
}: {
  id: string;
  eager?: boolean;
  className?: string;
}) {
  const {
    base
  } = useContext(SiteContext);
  const descriptionId = useId();
  const initial = screenshots.findIndex(x => x.id === id);
  const shot = screenshots[initial];
  const [open, setOpen] = useState(false),
    [index, setIndex] = useState(initial),
    [zoom, setZoom] = useState(false);
  const active = screenshots[index];
  useEffect(() => {
    if (!open) return;
    const key = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight') {
        setIndex(i => (i + 1) % screenshots.length);
        setZoom(false);
      }
      if (event.key === 'ArrowLeft') {
        setIndex(i => (i - 1 + screenshots.length) % screenshots.length);
        setZoom(false);
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [open]);
  if (!shot || !active) return null;
  return <Dialog.Root open={open} onOpenChange={next => {
    setOpen(next);
    if (next) {
      setIndex(initial);
      setZoom(false);
    }
  }}><figure className={`screenshot ${shot.device} ${className}`}><Dialog.Trigger asChild><button className="screenshot-trigger" aria-label={`放大查看：${shot.title}`}><img src={`${base}/media/${shot.id}-1280.webp`} srcSet={shot.device === 'desktop' ? `${base}/media/${shot.id}-800.webp 800w, ${base}/media/${shot.id}-1280.webp 1280w, ${base}/media/${shot.id}.webp 3200w` : undefined} sizes={shot.device === 'mobile' ? '(max-width: 767px) 72vw, 280px' : '(max-width: 767px) 92vw, (max-width: 1199px) 88vw, 1120px'} width={shot.width} height={shot.height} alt={shot.title} loading={eager ? 'eager' : 'lazy'} /><span className="zoom-hint"><ZoomIn size={16} />放大查看</span></button></Dialog.Trigger></figure><Dialog.Portal><Dialog.Overlay className="lightbox-overlay" /><Dialog.Content className="lightbox" aria-describedby={descriptionId}><div className="lightbox-toolbar"><div><Dialog.Title>{active.title}</Dialog.Title><Dialog.Description id={descriptionId}>{active.device === 'desktop' ? '桌面' : 'Android'} {active.version} · 演示项目实际界面</Dialog.Description></div><div className="lightbox-actions"><button className="icon-button" aria-label={zoom ? '适合窗口' : '原尺寸查看'} onClick={() => setZoom(!zoom)}>{zoom ? <ZoomOut /> : <ZoomIn />}</button><External href={`/media/${active.id}.png`} className="icon-button"><ExternalLink aria-label="新窗口查看原图" /></External><Dialog.Close asChild><button className="icon-button" aria-label="关闭大图"><X /></button></Dialog.Close></div></div><div className={`lightbox-image ${zoom ? 'original' : ''}`}><img key={active.id} src={`${base}/media/${active.id}.png`} width={active.width} height={active.height} alt={active.title} /></div><div className="lightbox-bottom"><button className="button ghost" onClick={() => {
            setIndex(i => (i - 1 + screenshots.length) % screenshots.length);
            setZoom(false);
          }}><ChevronLeft size={18} />上一张</button><p>{active.description}</p><button className="button ghost" onClick={() => {
            setIndex(i => (i + 1) % screenshots.length);
            setZoom(false);
          }}>下一张<ChevronRight size={18} /></button></div></Dialog.Content></Dialog.Portal></Dialog.Root>;
}
function PageIntro({
  label,
  title,
  children
}: {
  label?: string;
  title: string;
  children: ReactNode;
}) {
  return <Reveal className="page-intro">{label && <p className="eyebrow">{label}</p>}<h1>{title}</h1><p className="intro-copy">{children}</p></Reveal>;
}
function FeatureItem({
  item
}: {
  item: Feature;
}) {
  return <article className="feature-item"><div className="feature-meta"><span>{item.category}</span><Status state={item.state} /></div><h3>{item.title}</h3><p>{item.description}</p>{item.help && <LinkArrow href={item.help}>了解如何使用</LinkArrow>}</article>;
}
function Author() {
  return <section className="author-section" id="random"><div className="author-symbol" aria-hidden="true"><BrandMark width={76} height={76} /></div><div><p className="eyebrow">由 Random 发起与维护</p><h2>让工具服务于工作本身。</h2><p>我希望有一个自己愿意每天打开的 AI 工作台：能认真做事，也能把资料、过程和成果安放好。Tervell 因此开始，并在实际使用中继续改进。</p><p className="muted">这里也承载着 Random创造集市的探索。软件可以使用你自己的模型与账号，集市是可选的服务入口。</p><div className="inline-links"><External href={SITE.author}>Random 的 GitHub<ExternalLink size={15} /></External><External href={SITE.market}>Random创造集市<ExternalLink size={15} /></External></div></div></section>;
}
function ProductShowcase() {
  const [view, setView] = useState('workspace');
  const options = [{
    id: 'workspace',
    label: '项目与资料',
    icon: Layers3
  }, {
    id: 'activity',
    label: '执行过程',
    icon: Sparkles
  }, {
    id: 'kernels',
    label: '内核与模型',
    icon: Terminal
  }];
  return <div className="hero-preview">
    <div className="showcase-toolbar">
      <div className="showcase-tabs" role="group" aria-label="选择工作台展示场景">
        {options.map(x => <button key={x.id} aria-pressed={view === x.id} onClick={() => setView(x.id)}><x.icon size={15} aria-hidden="true" />{x.label}</button>)}
      </div>
      <span className="showcase-note">Tervell 真实界面</span>
    </div>
    <TransitionSurface id={view} className="showcase-content"><ScreenshotView key={view} id={view} eager /></TransitionSurface>
    <div className="showcase-caption"><span>你的项目，始终是工作的中心。</span><span>点击图片，查看完整界面 <ZoomIn size={13} /></span></div>
  </div>;
}
/** 以内容选择驱动界面示例，保持文字、媒体和容器边界一致。 */
function WorkspaceStory() {
  const [active, setActive] = useState(0);
  const steps = [{
    id: 'workspace',
    label: '项目与资料',
    title: '先把上下文放在一起',
    text: '会话、文件和项目记忆各有位置。下次回来，接着原来的工作继续。',
    icon: Layers3
  }, {
    id: 'kernels',
    label: '内核与模型',
    title: '熟悉的工具，同一个入口',
    text: '启用已有的 Agent，或一键安装新内核。在界面里选择模型、推理与权限。',
    icon: Terminal
  }, {
    id: 'activity',
    label: '过程与成果',
    title: '看清过程，留下成果',
    text: '展开工具调用与思考记录，从回复继续分叉、批注和导出。',
    icon: FileText
  }];
  return <section className="section work-section" id="workspace">
    <Reveal className="section-heading"><p className="section-kicker">在一张工作台上</p><h2>工具很多，<br />工作可以很有条理。</h2><p>从项目出发，把资料、执行过程和成果放回同一条思路。</p></Reveal>
    <div className="story-layout">
      <div className="story-steps" aria-label="工作流程界面">{steps.map((step, index) => <article className={`story-step ${active === index ? 'is-active' : ''}`} key={step.id} id={`story-${step.id}`}>
        <button className="story-step-trigger" aria-label={`展示${step.label}`} aria-expanded={active === index} aria-controls={`story-detail-${step.id}`} onClick={() => setActive(index)}><step.icon size={20} aria-hidden="true" /><span>{step.label}</span><Plus size={18} aria-hidden="true" /></button>
        <div className="story-detail" id={`story-detail-${step.id}`} hidden={active !== index}><h3>{step.title}</h3><p>{step.text}</p><SiteLink className="text-link" href={`/guide/#${step.id === 'workspace' ? 'projects' : step.id === 'activity' ? 'results' : 'kernels'}`}>查看使用方法<ArrowRight size={16} /></SiteLink></div>
      </article>)}</div>
      <div className="story-screen"><TransitionSurface id={steps[active]!.id}><ScreenshotView key={steps[active]!.id} id={steps[active]!.id} /></TransitionSurface><div className="media-caption"><span>{steps[active]!.title}</span><span>实际软件界面</span></div></div>
    </div>
  </section>;
}
function Home() {
  return <>
    <section className="hero" aria-labelledby="hero-title">
      <Reveal className="hero-copy"><p className="eyebrow">Tervell / 个人 AI 工作台</p><h1 id="hero-title">完整的 AI 工作台，<br /><span>从电脑延伸到手机。</span></h1><p className="hero-description">围绕项目组织模型、Agent、资料与产物。<br className="desktop-break" />让复杂工作，更容易推进。</p><div className="hero-buttons"><SiteLink className="button primary" href="/download/">下载 Tervell<ArrowDown size={18} /></SiteLink><SiteLink className="button secondary" href="/guide/">从这里开始<ArrowRight size={18} /></SiteLink></div></Reveal>
      <Reveal className="hero-product" delay={100}><ProductShowcase /></Reveal>
      <div className="platform-strip"><span><Monitor size={16} />Windows / macOS</span><span><Smartphone size={16} />Android 接续</span><External href={SITE.repository}><Github size={16} />开放源码</External></div>
    </section>
    <WorkspaceStory />
    <section className="mobile-story section" id="mobile">
      <Reveal className="mobile-story-copy"><p className="section-kicker">工作，不止一块屏幕</p><h2>电脑继续执行。<br />手机随时接上。</h2><p>看看结果，切到另一个项目，<br className="desktop-break" />或给正在推进的任务补充一句。</p><ul className="check-list"><li><Check />切换项目与会话</li><li><Check />发送任务与处理确认</li><li><Check />调整模型与内核选项</li><li><Check />按授权编辑电脑文件</li></ul><LinkArrow href="/guide/#mobile">了解手机连接</LinkArrow><p className="fine-print">手机连接在线电脑执行任务，具体能力取决于网络与内核支持。</p></Reveal>
      <Reveal className="phone-stage"><div className="phone-media"><ScreenshotView id="mobile" /></div><div className="device-bridge"><Monitor size={17} /><span>电脑执行</span><ArrowRight size={17} /><Smartphone size={17} /><span>手机接续</span></div></Reveal>
    </section>
    <section className="section activity-section" id="process">
      <Reveal className="section-heading"><p className="section-kicker">从过程，到可用的成果</p><h2>每一步看得清。<br />每一次回复，都能继续。</h2><p>保留软件原生排版，让思考、工具调用与最终结果各有位置。</p></Reveal>
      <Reveal className="activity-stage"><ScreenshotView id="activity" /></Reveal>
      <div className="detail-strip"><Reveal><h3>沿着思路分叉</h3><p>保留原来的讨论，另开一条路径。</p></Reveal><Reveal delay={60}><h3>带着成果离开</h3><p>批注、历史导入与导出，衔接下一项工作。</p></Reveal><Reveal delay={120}><h3>常用能力，按需接入</h3><p>通过 Skills、MCP 和扩展，组织自己的工具。</p></Reveal></div><LinkArrow href="/features/">查看全部功能与体验</LinkArrow>
    </section>
    <Reveal><section className="latest-section"><div><p className="section-kicker">持续打磨</p><h2>今天可用。<br />下一步，也有迹可循。</h2><p>已经验证的改进写进版本；专家与专家团、可控记忆和成果处理的新体验，明确列在开发路线。</p><LinkArrow href="/updates/">查看更新与开发路线</LinkArrow></div><article className="release-note"><span className="status available">当前 Alpha 基线</span><div className="release-number">0.19.119</div><time dateTime="2026-11-25">2026 年 11 月 25 日验收</time><h3>让多内核真正跑通任务</h3><p>完善安装、终端调用、续聊与取消，改进长历史恢复与资源释放。</p><LinkArrow href="/updates/#v0-19-119">阅读版本说明</LinkArrow></article></section></Reveal>
    <Reveal><Author /></Reveal>
    <Reveal><section className="download-banner"><BrandMark width={48} height={48} /><div><h2>为重要的工作，留出空间。</h2><p>Windows、macOS Apple Silicon 与 Android。</p></div><SiteLink className="button primary" href="/download/">下载 Tervell<ArrowDown size={18} /></SiteLink></section></Reveal>
  </>;
}
function Features() {
  const [filter, setFilter] = useState<FeatureState>('available');
  return <><PageIntro title="把能力放在一起，把操作变得顺手。">了解当前版本能做什么，也看看 Tervell 正在往哪里走。</PageIntro><div className="segmented feature-filter" role="group" aria-label="功能状态">{(['available', 'developing', 'planned'] as FeatureState[]).map(s => <button key={s} aria-pressed={filter === s} onClick={() => setFilter(s)}>{stateLabels[s]}</button>)}</div><TransitionSurface id={filter} className="feature-grid">{features.filter(x => x.state === filter).map(x => <FeatureItem key={x.id} item={x} />)}</TransitionSurface>{filter === 'planned' && <div className="empty-state"><Sparkles /><h2>先把正在做的事做好。</h2><p>新的方向确认后，会在这里说明。当前开发内容已列在「开发中」。</p></div>}{filter === 'available' && <section className="section"><ScreenshotView id="kernels" /><p className="caption">0.19.119 实际界面。内核目录与一键安装不等于所有厂商账号和业务都已完成验收。</p></section>}<section className="note-box"><h2>体验保持可控。</h2><p>不使用专家、记忆等能力时，应保留原生模型体验。开发中的自动化与建议能力会明确区分入口启用、上下文注入和自动执行，不提前作为本版承诺。</p><LinkArrow href="/updates/#roadmap">了解开发方向</LinkArrow></section></>;
}
function CopyValue({
  value,
  label = '复制校验值'
}: {
  value: string;
  label?: string;
}) {
  const [state, setState] = useState(''),
    timer = useRef<ReturnType<typeof setTimeout>>();
  useEffect(() => () => clearTimeout(timer.current), []);
  return <button className="copy-button" onClick={async () => {
    try {
      await navigator.clipboard.writeText(value);
      setState('已复制');
    } catch {
      setState('复制失败，请手动选择下方内容');
    }
    ;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setState(''), 3000);
  }}><Copy size={14} /><span aria-live="polite">{state || label}</span></button>;
}
function Downloads() {
  const {
    mirrorReady
  } = useContext(SiteContext);
  const [channel, setChannel] = useState<'mirror' | 'github'>(mirrorReady ? 'mirror' : 'github'),
    [recommended, setRecommended] = useState('');
  useEffect(() => {
    const ua = navigator.userAgent;
    setRecommended(/Android/i.test(ua) ? 'android' : /Mac/i.test(ua) ? 'mac' : /Windows/i.test(ua) ? 'windows' : '');
  }, []);
  return <><PageIntro label="公开 Alpha" title="选择你的工作台。">桌面负责执行，手机负责接续。安装前请阅读系统要求与测试版说明。</PageIntro><div className="download-top"><div className="segmented" role="group" aria-label="下载来源"><button disabled={!mirrorReady} aria-pressed={channel === 'mirror'} onClick={() => setChannel('mirror')}>Random 镜像</button><button aria-pressed={channel === 'github'} onClick={() => setChannel('github')}>GitHub Releases</button></div><p>{mirrorReady ? '两个来源使用相同文件与 SHA-256。' : '镜像正在准备，当前请使用 GitHub Releases。'}</p></div><div className="download-grid">{downloads.map(x => <article key={x.id} className={`download-card ${recommended === x.id ? 'recommended' : ''}`} id={x.id}><div className="download-card-top">{x.id === 'android' ? <Smartphone /> : <Monitor />}{recommended === x.id && <span className="status available">按当前设备推荐</span>}</div><h2>{x.name}</h2><p className="download-platform">{x.platform}</p><p className="download-version">v{x.version}<span>{(x.bytes / 1024 / 1024).toFixed(1)} MiB</span></p><SiteLink className="button primary" href={downloadUrl(x, channel)} download={channel === 'mirror' ? x.file : undefined}>下载 {x.name}<DownloadIcon size={17} /></SiteLink><p className="requirements">{x.requirements}</p><p className="fine-print">{x.signing}</p><details className="checksum"><summary>校验文件 SHA-256</summary><code>{x.sha256}</code><CopyValue value={x.sha256} /></details></article>)}</div><section className="note-box"><h2>开始前，了解这几个区别。</h2><div className="two-columns"><div><h3>软件、模型与远程服务</h3><p>软件下载不包含模型额度。可配置自己的模型渠道或支持的官方账号；Random创造集市是可选入口。公网远程连接需要相应服务授权，内网无需经过公网服务。</p></div><div><h3>这是测试版</h3><p>Windows 尚未签名，Mac 尚未公证，系统可能提示来源未验证。请核对下载地址与摘要；我们不建议关闭系统安全功能。重要资料应先备份。</p></div></div><LinkArrow href="/guide/">打开快速上手</LinkArrow></section><section className="section compact"><h2>源码与发行说明</h2><p>桌面与安卓有独立版本号。安卓 0.1.22 的源码未因本次桌面内核修复发生变化，保留真实版本号。</p><div className="inline-links"><External href={`${SITE.repository}/releases/tag/v${SITE.version}`}>GitHub 发行页<ExternalLink size={15} /></External><SiteLink href="/releases.json">发行清单 JSON</SiteLink><SiteLink href="/SHA256SUMS.txt">SHA256SUMS.txt</SiteLink><SiteLink href="/opensource/">源码与许可</SiteLink></div></section></>;
}
function Updates() {
  return <><PageIntro title="持续改进，每一步有迹可循。">已经验证的变化写进版本；还在打磨的体验，明确列在开发路线。</PageIntro><div className="timeline">{updates.map(x => <article className="timeline-entry" id={x.id} key={x.id}><div className="timeline-date"><time>{x.date}</time><span>{x.version}</span></div><div className="timeline-body"><span className={`status ${x.kind === '当前 Alpha 基线' ? 'available' : 'milestone'}`}>{x.kind}</span><h2>{x.title}</h2><ul>{x.items.map(t => <li key={t}>{t}</li>)}</ul><p className="fine-print">{x.note}</p>{x.version === SITE.version && <div className="inline-links"><SiteLink href="/download/">下载这个版本</SiteLink><External href={`${SITE.repository}/releases/tag/v${SITE.version}`}>GitHub 发行说明<ExternalLink size={14} /></External></div>}</div></article>)}</div><section className="section roadmap" id="roadmap"><div className="section-heading"><h2>正在推进的体验优化</h2><p>以下为其他分支的开发方向，不属于 0.19.119 的交付承诺，也暂不提供上线日期。</p></div><div className="roadmap-list">{features.filter(x => x.state !== 'available').map(x => <article key={x.id}><div><Status state={x.state} /><span className="muted">{x.category}</span></div><h3>{x.title}</h3><p>{x.description}</p></article>)}</div></section></>;
}
function Guide() {
  const [step, setStep] = useState(0);
  const [walking, setWalking] = useState(false);
  const [instruction, setInstruction] = useState(0);
  const [verticalTabs, setVerticalTabs] = useState(true);
  useEffect(() => {
    const media = matchMedia('(min-width: 900px)');
    const sync = () => setVerticalTabs(media.matches);
    sync();
    media.addEventListener('change', sync);
    return () => media.removeEventListener('change', sync);
  }, []);
  const choose = (index: number) => {
    setStep(index);
    setWalking(false);
    setInstruction(0);
    history.replaceState(null, '', '#' + guides[index]!.id);
  };
  useEffect(() => {
    const sync = () => {
      const index = guides.findIndex(x => '#' + x.id === location.hash);
      if (index >= 0) {
        setStep(index);
        setWalking(false);
        setInstruction(0);
      }
    };
    sync();
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  const guide = guides[step]!;
  return <><PageIntro label="快速上手" title="从一件想做的事开始。">先启用内核、连接模型，再建立一个项目。你不需要一次配置所有功能。</PageIntro>
    <div className="guide-workspace">
      <div className="guide-tabs" role="tablist" aria-label="选择上手目标" aria-orientation={verticalTabs ? 'vertical' : 'horizontal'}>{guides.map((x, i) => <button role="tab" id={`guide-tab-${x.id}`} key={x.id} aria-selected={step === i} aria-controls="guide-panel" tabIndex={step === i ? 0 : -1} onClick={() => choose(i)} onKeyDown={event => {
          let next = i;
          if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (i + 1) % guides.length;else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = (i - 1 + guides.length) % guides.length;else if (event.key === 'Home') next = 0;else if (event.key === 'End') next = guides.length - 1;else return;
          event.preventDefault();
          choose(next);
          document.getElementById(`guide-tab-${guides[next]!.id}`)?.focus();
        }}><span>{x.short}</span><ArrowRight size={16} aria-hidden="true" /></button>)}</div>
      <section className="guide-panel" id="guide-panel" role="tabpanel" aria-labelledby={`guide-tab-${guide.id}`} tabIndex={0}>
        <div className="guide-copy"><h2>{guide.title}</h2><p>{guide.text}</p></div>
        <div className="guide-instructions"><ol className={walking ? 'is-walking' : ''}>{guide.steps.map((text, index) => <li key={text} hidden={walking && index !== instruction} value={index + 1}>{text}</li>)}</ol>
          {walking ? <div className="walk-controls"><p className="walk-progress" aria-live="polite">第 {instruction + 1} 项，共 {guide.steps.length} 项</p><button className="text-link" disabled={instruction === 0} onClick={() => setInstruction(i => i - 1)}>上一步</button>{instruction < guide.steps.length - 1 ? <button className="text-link" onClick={() => setInstruction(i => i + 1)}>下一步<ArrowRight size={16} /></button> : <button className="text-link" onClick={() => setWalking(false)}>完成浏览<Check size={16} /></button>}<button className="text-link muted" onClick={() => setWalking(false)}>查看全部</button></div> : <button className="text-link guide-walk-start" onClick={() => {
            setInstruction(0);
            setWalking(true);
          }}>按步骤浏览<ArrowRight size={16} /></button>}
        </div>
        <div className="guide-media"><div className="media-caption"><span>在软件中找到这里</span><span>点击截图可放大</span></div><TransitionSurface id={guide.id}><ScreenshotView key={guide.id} id={guide.screenshot} /></TransitionSurface></div>
      </section>
    </div>
    <section className="section faq"><h2>常见问题</h2>{[{
        q: '需要先买模型才能打开软件吗？',
        a: '不需要。可以先浏览工作台和安装内核；实际生成内容需要可用的模型渠道或相应官方账号，相关费用按供应商规则。'
      }, {
        q: '电脑上已经装了 Codex 等工具怎么办？',
        a: '先在 Agent 内核页检测已有工具，选择对应的启用或配置方式。适配器、CLI 与账号是不同部分，界面验证完成后再开始任务。'
      }, {
        q: '手机能独立运行桌面内核吗？',
        a: '手机是连接电脑的工作台。任务由在线电脑执行；手机提供项目、会话和受支持配置的操作入口，不内置所有桌面 CLI。'
      }, {
        q: '内网和公网连接有什么区别？',
        a: '同一网络可直接连接电脑。跨公网需要电脑能访问相应连接服务；Random 入口需登录授权。更清晰的自定义隧道配置正在开发。'
      }, {
        q: '能安装任意 Paseo 插件吗？',
        a: 'Tervell 使用部分原始 SDK 与运行机制，并适配工作台中的贡献位置；当前不能保证任意插件或所有 API 完全兼容。'
      }, {
        q: '怎样反馈问题？',
        a: '到 GitHub Issues 描述操作步骤、系统、Tervell 与内核版本，并提供已去除密钥和私人内容的日志。不要上传配对二维码、账号凭据或完整私人会话。'
      }].map(x => <details key={x.q}><summary>{x.q}<Plus size={17} /></summary><p>{x.a}</p></details>)}</section></>;
}
function OpenSource() {
  return <><PageIntro title="站在开源工作的基础上，继续打磨。">Tervell 是独立维护的二次开发项目。感谢上游，也清楚说明我们使用了什么、改变了什么。</PageIntro><div className="upstream-list">{[{
        name: 'Proma',
        license: 'AGPL-3.0',
        url: 'https://github.com/proma-ai/Proma',
        description: 'Tervell 的桌面工作台基础。沿用并改造会话、项目、工具和界面体系，保留许可与上游署名。',
        changes: '在此基础上扩展多内核、移动工作台、模型路由与交互能力。'
      }, {
        name: 'Paseo',
        license: 'Apache-2.0（所用组件）',
        url: 'https://github.com/getpaseo/paseo',
        description: '使用已记录版本的插件 SDK、客户端与相关运行组件，并参考多内核和移动接续的契约及交互。',
        changes: '将贡献位置、生命周期、状态和权限接入 Tervell；不宣称任意插件或完整移动端 1:1 兼容。'
      }, {
        name: 'Magpie',
        license: 'MIT',
        url: 'https://github.com/yetone/magpie',
        description: '内置模型网关与供应商管理基础，支撑全局模型路由与支持的账号接入。',
        changes: '记录随包版本及必要补丁，保留来源和第三方许可；不等同于提供免费模型额度。'
      }].map(x => <article key={x.name}><div><h2>{x.name}</h2><span className="status milestone">{x.license}</span></div><p>{x.description}</p><p className="muted">{x.changes}</p><External href={x.url} className="text-link">查看上游项目<ExternalLink size={15} /></External></article>)}</div><section className="section compact"><h2>不仅是致谢，也是可追溯的源码。</h2><p>公开发行包对应的源码、构建材料、第三方许可与修改说明放在产品仓库和发行标签中。Tervell 保留 Proma 的 AGPL-3.0 许可；所用第三方组件按各自许可提供。</p><div className="inline-links"><External href={SITE.repository}>产品源码<Github size={16} /></External><External href={`${SITE.repository}/tree/v${SITE.version}`}>本版对应源码<ExternalLink size={15} /></External><External href={`${SITE.repository}/blob/main/LICENSE`}>许可证<ExternalLink size={15} /></External></div></section><section className="note-box"><h2>扩展作者，也值得被看见。</h2><p>内置的部分导出、任务、过程展示、连接与批注能力参考或使用了 Conversation Exporter、Paseo Direct、Better Paseo、Codex Style Annotations 和 Vivid Activity 等项目的源码。各项目的版本、来源、许可与改造方式在第三方清单中保留。</p><External href={`${SITE.repository}/tree/main/apps/electron/resources/third-party/default-features`} className="text-link">查看原始来源与许可<ExternalLink size={15} /></External><p className="fine-print">Tervell 与上述项目及模型供应商无官方合作或背书关系。项目名称与标志归各自权利人所有。</p></section><Author /></>;
}
function Footer() {
  return <footer className="site-footer"><div className="footer-top"><SiteLink href="/" className="wordmark"><BrandMark width={28} height={28} /><span>Tervell</span></SiteLink><p>Make room for meaningful work.</p><ThemePicker /></div><div className="footer-bottom"><span>由 Random 发起与维护</span><nav aria-label="页脚导航"><SiteLink href="/opensource/">开源与致谢</SiteLink><External href={SITE.repository + '/issues'}>反馈问题</External><External href={SITE.market}>Random创造集市</External></nav></div></footer>;
}
export function App({
  path = '/',
  base = '',
  mirrorReady = true
}: {
  path?: string;
  base?: string;
  mirrorReady?: boolean;
}) {
  const normalized = path === '/' ? '/' : path.replace(/\/+$/, '') + '/';
  return <MotionProvider><SiteContext.Provider value={{
      base,
      mirrorReady
    }}><SiteLink href="#main-content" className="skip-link">跳到主要内容</SiteLink><InputModality /><Header path={normalized} /><main id="main-content" className={normalized === '/' ? 'home-main' : 'inner-main'}>{normalized === '/' ? <Home /> : normalized === '/features/' ? <Features /> : normalized === '/download/' ? <Downloads /> : normalized === '/updates/' ? <Updates /> : normalized === '/guide/' ? <Guide /> : normalized === '/opensource/' ? <OpenSource /> : <><PageIntro title="这个页面不在这里。">你可以回到首页，或从导航找到下载和帮助。</PageIntro><SiteLink href="/" className="button primary"><ArrowLeft size={16} />返回首页</SiteLink></>}</main><Footer /></SiteContext.Provider></MotionProvider>;
}
