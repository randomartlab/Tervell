import React, { useEffect, useRef, useState, type ReactNode, type Ref } from "react";
import { Animated, Platform, Pressable, View, type LayoutRectangle, type TextInput as NativeTextInput } from "react-native";
import { Icon } from "@getpaseo/plugin/client/ui";
import type { PluginTheme } from "@getpaseo/plugin";
import { TaskText as Text, HOST_FONT as F, useTasksFontScale, taskControlHeight } from "../typography";
import { tipProps } from "../cards/card-hints";
import { taskTokens } from "../cards/tokens";
import { liftStyle, surfaceLift } from "../cards/surface-lift";
import { CornerBadge, HoverPressable, RollingTotal, SlashMark } from "./board-parts";
import { useReducedMotion } from "../../ui/use-reduced-motion";
import { HAIRLINE, MOTION } from "./board-style";
import { laneWidthMenuSections, sortMenuSections } from "./board-menus";
import { CascadeMenu, type MenuSection } from "./menu";
import { menuChrome, menuWidth } from "./menu-model";
import { activeFilterCount, resolveBoardParams } from "./params";
import type { BoardController } from "./use-board";
import { FullConversationSwitch, SearchCancelToggle, SearchInput, SearchStatusMark, useSearchStatusText } from "./search-loading";
import { SearchCoverageItems } from "./search-coverage";
import { PanelMark, SearchQueryChip } from "./filter-bar";
import { TASK_TOOLBAR_METRICS } from "../toolbar-metrics";
import { LANES } from "./navigation";
import { tasksSettingsOpener } from "./enabled";
import { useUpdateIndicator } from "./update-indicator";
import { UPDATE_INDICATOR_COLOR } from "../../ui/update-indicator";
import { SETTINGS_STRINGS } from "../../i18n/settings-page-strings";
import { useTasksLanguage } from "../i18n";

type ViewPage = "view" | "sort";

/** Keep menu geometry and hit targets in sync, including nested choices. */
function touchSections(sections: MenuSection[]): MenuSection[] {
  return sections.map((section) => ({ ...section, items: section.items.map((item) => ({ ...item, minHeight: 44, ...(item.submenu ? { submenu: touchSections(item.submenu) } : {}) })) }));
}

/** Tablets keep board actions in one row and open compact search below it. */
export function TabletToolbar(props: {
  board: BoardController;
  theme: PluginTheme;
  width: number;
  laneWidth: number;
  searchRef: Ref<NativeTextInput>;
  onFilters(): void;
  filters?: { content: ReactNode; height: number; onClose(): void };
  sidebar: { open: boolean; sheet: boolean; onToggle(): void };
  emptyLanes: { collapsed: boolean; disabled: boolean; onToggle(): void };
}) {
  const { board, theme } = props;
  const colors = theme.colors;
  const strings = board.strings;
  const openSettings = tasksSettingsOpener();
  const updateAvailable = useUpdateIndicator(board.hostId, board.visible) && !!openSettings;
  const updateLabel = SETTINGS_STRINGS[useTasksLanguage()].versionBadge;
  const scale = useTasksFontScale();
  const compact = props.width < 680 * Math.max(1, scale);
  const target = taskControlHeight(TASK_TOOLBAR_METRICS.touch.button, scale);
  const height = taskControlHeight(40, scale);
  const inlineSearch = props.width >= 960 * Math.max(1, scale);
  const [page, setPage] = useState<ViewPage | null>(null);
  const [trail, setTrail] = useState<string[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const searching = Boolean(board.params.query.trim());
  const narrowSummary = props.width < 480 * Math.max(1, scale);
  const [toolbarWidth, setToolbarWidth] = useState<number | null>(null);
  const [actionLayout, setActionLayout] = useState<LayoutRectangle | null>(null);
  const [viewLayout, setViewLayout] = useState<LayoutRectangle | null>(null);
  const [filterLayout, setFilterLayout] = useState<LayoutRectangle | null>(null);
  const actionWidth = actionLayout?.width ?? 0;
  // Keep the subtask shortcut visible alongside filters and view on narrow boards.
  const minimumActionsWidth = 4 * target;
  // The count gives its slot to search. Reserve room for editing and its inline controls.
  const minimumSearchWidth = taskControlHeight(searching ? 320 : 200, scale);
  const searchInToolbar = inlineSearch || (searchOpen && props.width >= minimumActionsWidth + minimumSearchWidth + 2 * LANES.edge + 18);
  const expandedSearch = searchOpen && !searchInToolbar;
  const fieldVisible = searchInToolbar || expandedSearch;
  // Narrow split views cannot fit a centered count between two equally wide slots.
  const centered = props.width >= 2 * minimumActionsWidth + taskControlHeight(120, scale);
  const separateFilters = compact || actionWidth === 0 || actionWidth >= 2 * target;
  const menuAnchor = toolbarWidth !== null && actionLayout && viewLayout ? {
    right: toolbarWidth - actionLayout.x - viewLayout.x - viewLayout.width,
    top: actionLayout.y + viewLayout.y + target + 6,
  } : null;
  const filterAnchor = separateFilters ? filterLayout : viewLayout;
  const filterRight = toolbarWidth !== null && actionLayout && filterAnchor
    ? Math.min(props.width - menuWidth(320, scale, props.width - 24) - 12, Math.max(12, toolbarWidth - actionLayout.x - filterAnchor.x - filterAnchor.width))
    : 12;
  const resolved = resolveBoardParams(board.params, board.defaults);
  const count = activeFilterCount(board.params, board.defaults);
  const textStyle = { fontSize: F.base, fontWeight: "600" as const, color: colors.foreground, fontVariant: ["tabular-nums" as const] };
  const openPage = (next: ViewPage | null) => { setTrail([]); setPage(next); };
  const closeEmptySearch = () => { if (!board.params.query) setSearchOpen(false); };
  const close = () => { openPage(null); closeEmptySearch(); props.filters?.onClose(); };
  const sections: MenuSection[] = page === "sort" ? [
    { key: "back", items: [{ key: "back", label: strings.back, icon: "ChevronLeft", keepOpen: true, onSelect: () => openPage("view") }] },
    ...sortMenuSections(board.params.sort, strings, (sort) => board.setParams((p) => ({ ...p, sort }))),
  ] : [
    { key: "layout", items: [
      ...(!separateFilters ? [{ key: "filters", label: strings.filters, icon: "Filter", onSelect: () => { close(); props.onFilters(); } }] : []),
      { key: "sort", label: strings.sort, icon: "ArrowUpDown", hint: "›", keepOpen: true, onSelect: () => openPage("sort") },
      { key: "width", label: strings.laneWidth.label, icon: "Columns3", submenu: laneWidthMenuSections(board.laneWidth, theme, strings, board.setLaneWidth) },
    ] },
    { key: "visibility", items: [
      { key: "subtasks", label: strings.showSubtasks, icon: resolved.filters.hideSubtasks ? "List" : "Network", checked: !resolved.filters.hideSubtasks, keepOpen: true, onSelect: () => board.setParams((p) => ({ ...p, hideSubtasks: !(p.hideSubtasks ?? board.defaults.hideSubtasks) })) },
      { key: "empty-lanes", label: props.emptyLanes.collapsed ? strings.emptyLanes.expand : strings.emptyLanes.collapse, icon: props.emptyLanes.collapsed ? "UnfoldHorizontal" : "FoldHorizontal", checked: props.emptyLanes.collapsed, disabled: props.emptyLanes.disabled, keepOpen: true, onSelect: props.emptyLanes.onToggle },
      { key: "archived", label: strings.archivedLane.row, icon: "Archive", checked: board.showArchived, keepOpen: true, onSelect: () => board.setShowArchived(!board.showArchived) },
    ] },
    ...(openSettings ? [{ key: "settings", items: [{ key: "settings", label: strings.openSettings, accessibilityLabel: updateAvailable ? `${strings.openSettings}, ${updateLabel}` : undefined, icon: "Bolt", onSelect: openSettings, trailing: updateAvailable ? <View testID="tablet-settings-update-dot" pointerEvents="none" style={{ width: 4, height: 4, borderRadius: 2, alignSelf: "center", backgroundColor: UPDATE_INDICATOR_COLOR }} /> : undefined }] }] : []),
  ];
  // Touch drill-down stays inside the same panel, including in iPad split view.
  const level = trail.reduce((current, key) => current.flatMap((section) => section.items).find((item) => item.key === key)?.submenu ?? current, sections);
  const visibleSections: MenuSection[] = [
    ...(trail.length ? [{ key: "back", items: [{ key: "back", label: strings.back, icon: "ChevronLeft", keepOpen: true, onSelect: () => setTrail(trail.slice(0, -1)) }] }] : []),
    ...level.map((section) => ({ ...section, items: section.items.map((item) => item.submenu ? { ...item, submenu: undefined, hint: "›", keepOpen: true, onSelect: () => setTrail([...trail, item.key]) } : item) })),
  ];
  const compactLabels = compact ? undefined : { stopped: strings.searchStoppedShort, failed: strings.historyFailedShort };
  const editSearch = () => { props.filters?.onClose(); setPage(null); setSearchOpen(true); };
  const querySummary = (
    <View testID="tablet-search-summary" style={{ flex: 1, flexBasis: 0, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 6 }}>
      {narrowSummary ? <StatusQueryChip board={board} theme={theme} onEdit={editSearch} /> : <SearchQueryChip board={board} theme={theme} onEdit={editSearch} />}
      {!narrowSummary ? <>
        <SearchCoverageItems theme={theme} compact compactLabels={compactLabels} />
        <SearchCancelToggle theme={theme} iconSize={16} />
      </> : null}
    </View>
  );
  const search = (
    <TabletSearchReveal persistent={inlineSearch}>
    <View testID="tablet-toolbar-search" style={{ ...(inlineSearch ? { width: props.laneWidth, flexShrink: 1 } : { flex: 1, flexBasis: 0 }), minWidth: 0, height: height - 8, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, borderRadius: 7, borderWidth: HAIRLINE, borderColor: searchFocused ? colors.foregroundMuted : colors.border, backgroundColor: colors.surface0 }}>
      <SearchInput theme={theme} staticIcon iconSize={16} iconColor={colors.foregroundMuted}
        ref={props.searchRef}
        value={board.params.query}
        onChangeText={(query) => board.setParams((p) => ({ ...p, query }))}
        onFocus={() => setSearchFocused(true)}
        onBlur={() => setSearchFocused(false)}
        placeholder={strings.search}
        placeholderTextColor={colors.foregroundMuted}
        accessibilityLabel={strings.search}
        autoFocus={!inlineSearch}
        autoCorrect={false}
        autoCapitalize="none"
        returnKeyType="search"
        onSubmitEditing={() => setSearchOpen(false)}
        beforeCancel={<SearchCoverageItems theme={theme} part="badge" />}
        style={{ flex: 1, minWidth: 0, padding: 0, fontSize: Math.round(F.sm * scale), color: colors.foreground }}
      />
      {board.params.query ? <ToolbarButton icon="X" label={strings.menuSearch.clear} theme={theme} onPress={() => board.setParams((p) => ({ ...p, query: "" }))} testID="tablet-search-clear" /> : null}
    </View>
    <FullConversationSwitch theme={theme} iconSize={18} />
    {searchInToolbar && !inlineSearch ? <ToolbarButton icon="X" label={strings.closeMenu} theme={theme} onPress={() => setSearchOpen(false)} testID="tablet-search-close" /> : null}
    <SearchCoverageItems theme={theme} part="notice" compact compactLabels={compactLabels} />
    </TabletSearchReveal>
  );
  return (
    <>
      {page || props.filters || (searchOpen && !inlineSearch && !board.params.query) ? <Pressable accessibilityLabel={strings.closeMenu} testID="tablet-toolbar-backdrop" onPress={close} style={{ position: "absolute", top: 0, bottom: 0, left: 0, right: 0, zIndex: page || props.filters ? 20 : 9 }} /> : null}
      <View pointerEvents="box-none" testID="tablet-toolbar" onLayout={(event) => setToolbarWidth(event.nativeEvent.layout.width)} style={{ height, flexShrink: 0, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: LANES.edge, borderBottomWidth: HAIRLINE, borderBottomColor: colors.border, zIndex: 10 }}>
        {/* Match both side slots' minimums: native flex otherwise shifts the title towards the search. */}
        <View testID="tablet-toolbar-start" style={{ flex: 1, flexBasis: 0, minWidth: !searching && !searchInToolbar && compact && centered ? minimumActionsWidth : 0, marginLeft: searchInToolbar || (searching && !fieldVisible && narrowSummary) ? 0 : -8, marginRight: searchInToolbar ? 0 : 8, flexDirection: "row", alignItems: "center", gap: 6 }}>
          {searchInToolbar ? search : <>
            {!(searching && !fieldVisible && narrowSummary) ? <ToolbarButton icon="Search" label={strings.searchButton} selected={searchOpen || searching} hideSelectedBackground theme={theme} testID="tablet-search-toggle" onPress={() => { props.filters?.onClose(); setPage(null); setSearchOpen(!searchOpen); }} /> : null}
            {!fieldVisible ? querySummary : null}
          </>}
        </View>
        {!fieldVisible ? <View accessible pointerEvents="none" accessibilityLabel={strings.total(board.total)} testID="tablet-toolbar-total" style={{ flexDirection: "row", alignItems: "center", gap: 6, flexShrink: 0 }}>
          <View testID="tablet-total-slot" style={{ flexShrink: 0, alignItems: "center", justifyContent: "center" }}>
            {/* Reserve the complete localised phrase, so count changes never move the search. */}
            <Text testID="tablet-total-reserve" accessible={false} accessibilityElementsHidden importantForAccessibility="no-hide-descendants" numberOfLines={1} style={[textStyle, { opacity: 0 }]}>{strings.total(Number("8".repeat(Math.max(3, String(board.total).length))))}</Text>
            <View pointerEvents="none" style={{ position: "absolute", left: 0, right: 0, alignItems: "center" }}>
              <RollingTotal board={board} style={textStyle} />
            </View>
          </View>
        </View> : null}
        <View testID="tablet-toolbar-end" pointerEvents="box-none" onLayout={(event) => setActionLayout(event.nativeEvent.layout)} style={{ flex: searching || searchInToolbar || !centered ? 0 : 1, flexBasis: searching || searchInToolbar || !centered ? "auto" : 0, minWidth: compact && centered ? minimumActionsWidth : 0, marginLeft: 6, marginRight: -6, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: TASK_TOOLBAR_METRICS.touch.gap }}>
        <ToolbarButton icon={resolved.filters.hideSubtasks ? "List" : "Network"} label={strings.showSubtasks} selected={!resolved.filters.hideSubtasks} toggle badge={board.hiddenSubtasks} badgeTestID="subtasks-toggle-count" theme={theme} testID="subtasks-toggle" onPress={() => { closeEmptySearch(); board.setParams((p) => ({ ...p, hideSubtasks: !resolved.filters.hideSubtasks })); }} />
        {separateFilters ? <View testID="tablet-filter-anchor" onLayout={(event) => setFilterLayout(event.nativeEvent.layout)}><ToolbarButton icon="Filter" label={strings.filters} badge={count} expanded={Boolean(props.filters)} theme={theme} testID="toolbar-filters" onPress={() => { close(); if (!props.filters) props.onFilters(); }} /></View> : null}
        <View testID="tablet-view-container" pointerEvents="box-none" onLayout={(event) => setViewLayout(event.nativeEvent.layout)} style={{ zIndex: 20 }}>
          <ToolbarButton icon="MoreVertical" label={updateAvailable ? `${strings.view}, ${updateLabel}` : strings.view} badge={separateFilters ? undefined : count} badgeTop expanded={page !== null} theme={theme} testID="tablet-view" onPress={() => { props.filters?.onClose(); closeEmptySearch(); openPage(page ? null : "view"); }} />
          {updateAvailable ? <View testID="tablet-view-update-dot" pointerEvents="none" style={{ position: "absolute", bottom: target / 2 - 12, right: target / 2 - 11, width: 4, height: 4, borderRadius: 2, backgroundColor: UPDATE_INDICATOR_COLOR }} /> : null}
        </View>
        <ToolbarButton icon={<PanelMark open={props.sidebar.open} side={props.sidebar.sheet ? "bottom" : "right"} color={colors.foreground} />} label={props.sidebar.open ? strings.sidebar.hide : strings.sidebar.show} selected={props.sidebar.open} hideSelectedBackground theme={theme} testID="sidebar-switch" onPress={() => { closeEmptySearch(); props.sidebar.onToggle(); }} />
        </View>
      </View>
      {expandedSearch ? <View testID="tablet-search-row" onAccessibilityEscape={() => setSearchOpen(false)} style={{ flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: LANES.edge, paddingVertical: 8, borderBottomWidth: HAIRLINE, borderBottomColor: colors.border, zIndex: 10 }}>
        {search}
        <ToolbarButton icon="X" label={strings.closeMenu} theme={theme} onPress={() => setSearchOpen(false)} testID="tablet-search-close" />
      </View> : null}
      {props.filters ? (
        <View testID="tablet-filter-popover" onAccessibilityEscape={props.filters.onClose} style={{ position: "absolute", top: height + 6, right: filterRight, width: menuWidth(320, scale, props.width - 24), height: Math.min(600, Math.max(0, props.filters.height * 0.8)), borderRadius: 12, borderWidth: HAIRLINE, borderColor: colors.border, backgroundColor: colors.surface1, boxShadow: menuChrome(theme).shadow, elevation: 8, paddingBottom: 16, overflow: "hidden", zIndex: 30 }}>
          <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, height: taskControlHeight(48, scale), borderBottomWidth: HAIRLINE, borderBottomColor: colors.border }}>
            <Text accessibilityRole="header" style={{ flex: 1, fontSize: F.base, fontWeight: "600", color: colors.foreground }}>{strings.filters}</Text>
            <ToolbarButton size={compact ? 28 : 44} icon="X" label={strings.closeMenu} theme={theme} testID="tablet-filter-close" onPress={props.filters.onClose} />
          </View>
          {props.filters.content}
        </View>
      ) : null}
      {page && menuAnchor ? (
        // Keep Android AX bounds inside a board-height parent instead of the short toolbar.
        <View pointerEvents="box-none" testID="tablet-view-overlay" style={{ position: "absolute", top: 0, bottom: 0, left: 0, right: menuAnchor.right, zIndex: 30 }}>
          <CascadeMenu key={`${page}:${trail.join("/")}`} sections={touchSections(visibleSections)} theme={theme} width={menuWidth(220, scale, props.width - 24)} top={menuAnchor.top} align="right" onClose={() => openPage(null)} testID="tablet-view-menu" />
        </View>
      ) : null}
    </>
  );
}

/** Animate each opened search field without replaying on typing or coverage updates. */
function TabletSearchReveal(props: { persistent: boolean; children: ReactNode }) {
  const reduced = useReducedMotion();
  const immediate = reduced || props.persistent;
  const progress = useRef(new Animated.Value(immediate ? 1 : 0)).current;
  useEffect(() => {
    if (immediate) {
      progress.setValue(1);
      return;
    }
    const animation = Animated.timing(progress, {
      toValue: 1,
      duration: 180,
      easing: MOTION.ease,
      useNativeDriver: Platform.OS !== "web",
      isInteraction: false,
    });
    animation.start();
    return () => animation.stop();
  }, [immediate, progress]);
  return <Animated.View testID="tablet-toolbar-search-group" style={{ minWidth: 0, maxWidth: "100%", flex: 1, flexBasis: 0, flexDirection: "row", alignItems: "center", gap: 8, opacity: immediate ? 1 : progress, transform: immediate ? undefined : [{ translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [-4, 0] }) }] }}>
    {props.children}
  </Animated.View>;
}

/**
 * The narrow pill shows its search state only as a mark, so its edit button
 * also speaks that state. Kept apart so count updates re-render the pill alone.
 */
function StatusQueryChip(props: { board: BoardController; theme: PluginTheme; onEdit(): void }) {
  const hint = useSearchStatusText();
  return <SearchQueryChip board={props.board} theme={props.theme} lead={<SearchStatusMark theme={props.theme} />} editHint={hint} onEdit={props.onEdit} />;
}

function ToolbarButton(props: { icon: string | React.ReactElement; label: string; theme: PluginTheme; onPress(): void; testID: string; selected?: boolean; toggle?: boolean; hideSelectedBackground?: boolean; expanded?: boolean; badge?: number; badgeTop?: boolean; badgeTestID?: string; slashed?: boolean; size?: number }) {
  const colors = props.theme.colors;
  const scale = useTasksFontScale();
  const target = taskControlHeight(props.size ?? TASK_TOOLBAR_METRICS.touch.button, scale);
  const iconSize = TASK_TOOLBAR_METRICS.touch.icon;
  return (
    <HoverPressable hoverTheme={props.theme} lift="toolbar" accessibilityRole="button" accessibilityLabel={props.label} accessibilityState={{ ...(props.selected === undefined ? {} : { selected: props.selected }), ...(props.expanded === undefined ? {} : { expanded: props.expanded }) }} {...tipProps(props.label)} onPress={props.onPress} testID={props.testID} style={(hovered, pressed, input) => ({ width: target, height: target, flexShrink: 0, borderRadius: target / 2, backgroundColor: props.expanded || (props.selected && !props.toggle && !props.hideSelectedBackground) ? colors.surface1 : "transparent", ...liftStyle(() => taskTokens(props.theme), surfaceLift(hovered, pressed, undefined, "toolbar", input)), flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 })}>
      <View style={{ width: iconSize, height: iconSize, alignItems: "center", justifyContent: "center" }}>
        {typeof props.icon === "string" ? <Icon name={props.icon} size={iconSize} color={colors.foreground} /> : props.icon}
        {props.slashed ? <SlashMark size={iconSize} color={colors.foreground} gap={colors.surface0} /> : null}
        <CornerBadge count={props.badge ?? 0} theme={props.theme} style={props.badgeTop ? { top: -4, right: -4 } : { bottom: -4, right: -4 }} testID={props.badgeTestID ?? "tablet-filter-count"} />
      </View>
    </HoverPressable>
  );
}
