import { PixelRatio, Platform, StyleSheet, type ViewStyle } from "react-native";
import type { PluginTheme } from "@getpaseo/plugin";
import { mix } from "../../components/theme-tokens";
import { themeKey } from "../../ui/tokens/theme-key";
import { cubicBezier } from "../../ui/tokens/motion";

export { cubicBezier } from "../../ui/tokens/motion";

/**
 * The board's own palette, after Linear's board (page #f9f9fa, lanes
 * #f6f6f7 in its light theme): the page is `surface0` and each lane a
 * rounded panel a small step off it. Paseo's light `surface1` (#fafafa)
 * is too close to white to read, so a light panel sits halfway between
 * `surface1` and `surface2` (#f7f7f8); a dark one is `surface1`. Cards keep
 * `surface0`. The hex values are calibration against Paseo's default light
 * theme only: every colour here is derived from the host theme.
 */
/** Every line the board draws (borders, dividers, pills) is one device pixel, as Linear's are. */
export const HAIRLINE = StyleSheet.hairlineWidth;

/**
 * One device pixel, on the web too: react-native-web's `hairlineWidth` is a
 * whole CSS pixel, two device pixels on a retina screen. Read at render, as
 * the window can move to a screen of another density.
 */
export function devicePixel(): number {
  return Platform.OS === "web" ? 1 / Math.max(1, PixelRatio.get()) : StyleSheet.hairlineWidth;
}

/** An action button's outline: 0.5 pt, on the desktop and the web too. */
export const BUTTON_LINE = 0.5;

type Side = "top" | "right" | "bottom" | "left";
const SIDES: readonly Side[] = ["top", "right", "bottom", "left"];
const CAP = { top: "Top", right: "Right", bottom: "Bottom", left: "Left" } as const;
const INSET = { top: `0 ${BUTTON_LINE}px`, right: `-${BUTTON_LINE}px 0`, bottom: `0 -${BUTTON_LINE}px`, left: `${BUTTON_LINE}px 0` } as const;

/**
 * An action button's 0.5 pt outline in `color`; `sides` gives one side its
 * own colour, or none. Chrome rounds any border under 1 CSS px up to a whole
 * one, two device pixels at 2x, so on the web the line is an inset box-shadow
 * instead, which keeps its half pixel. Read at render, as the platform is.
 */
export function buttonOutline(color: string, sides: Partial<Record<Side, string | null>> = {}, shadow?: string): ViewStyle {
  const colorOf = (side: Side) => (side in sides ? sides[side]! : color);
  const uniform = SIDES.every((side) => colorOf(side) === color);
  if (Platform.OS !== "web") {
    const border = uniform
      ? { borderWidth: BUTTON_LINE, borderColor: color }
      : Object.fromEntries(
          SIDES.flatMap((side) => {
            const c = colorOf(side);
            return c === null ? [[`border${CAP[side]}Width`, 0]] : [[`border${CAP[side]}Width`, BUTTON_LINE], [`border${CAP[side]}Color`, c]];
          }),
        ) as ViewStyle;
    return shadow ? { ...border, boxShadow: shadow } : border;
  }
  const shadows = uniform
    ? [`inset 0 0 0 ${BUTTON_LINE}px ${color}`]
    : SIDES.flatMap((side) => (colorOf(side) === null ? [] : [`inset ${INSET[side]} 0 0 ${colorOf(side)}`]));
  return { borderWidth: 0, boxShadow: [...shadows, ...(shadow ? [shadow] : [])].join(", ") } as ViewStyle;
}

/** Letter-avatar outlines are part of the glyph, not a divider: a full point keeps them legible. */
export const GLYPH_LINE = 1;

/** Linear's lane panel corner: a 10 device px arc at 2x. */
export const PANEL_RADIUS = 5;

export interface BoardPalette {
  page: string;
  panel: string;
  /** `surface2`. The lane panel stays `panel`; collapse buttons do not paint this. */
  panelHover: string;
}

const palettes = new Map<string, BoardPalette>();

function isDark(color: string): boolean {
  const value = color.trim();
  const hex = /^#([0-9a-f]{6})/i.exec(value)?.[1];
  let rgb: number[] | null = hex ? [0, 2, 4].map((at) => Number.parseInt(hex.slice(at, at + 2), 16)) : null;
  if (!rgb) {
    const match = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i.exec(value);
    rgb = match ? [Number(match[1]), Number(match[2]), Number(match[3])] : null;
  }
  if (!rgb) return false;
  return (0.299 * rgb[0]! + 0.587 * rgb[1]! + 0.114 * rgb[2]!) / 255 < 0.5;
}

export function boardPalette(theme: PluginTheme): BoardPalette {
  const key = themeKey(theme);
  let palette = palettes.get(key);
  if (!palette) {
    if (palettes.size >= 8) palettes.delete(palettes.keys().next().value as string);
    const colors = theme.colors;
    const panel = isDark(colors.surface0) ? colors.surface1 : mix(colors.surface1, colors.surface2, 0.5);
    palette = { page: colors.surface0, panel, panelHover: colors.surface2 };
    palettes.set(key, palette);
  }
  return palette;
}

/**
 * The board's motion (prototype 6.4).
 */

export const MOTION = {
  /** Every board transition: cubic-bezier(.2, 0, 0, 1), no overshoot. */
  ease: cubicBezier(0.2, 0, 0, 1),
  /** The phone's lane switch: underline and incoming content. */
  laneMs: 200,
  /** The outgoing lane's fade. */
  laneOutMs: 120,
  /** How far lane content travels on a switch. */
  laneShift: 24,
  /**
   * A card that came into a lane from out of view (a new task, a card that
   * was out of view) enters: it rises `enterShift` into its place and grows
   * from `enterScale` as it fades in, a beat after the cards below start to
   * make room. Transform and opacity only, so native runs it on the UI thread.
   */
  enterMs: 260,
  enterDelayMs: 60,
  enterShift: 10,
  enterScale: 0.985,
  /** A card moved within its lane (one above it left or came in) slides to its new place. */
  slideMs: 240,
  /** A card that changed lanes travels from its old place to its new one. */
  flyMs: 300,
  /** A lane's count rolls to its new value while a card flies between lanes: the old number leaves, the new one comes in. */
  countMs: 300,
  /** How far the old and new counts travel, up when the count grows and down when it shrinks. */
  countShift: 6,
  /** A card that left the board fades where it was. */
  leaveMs: 160,
  /** A desktop lane collapsed, expanded or switched to another width eases to its new width. */
  resizeMs: 220,
  /** The strip or list swapped in as a lane collapses or expands fades in. */
  swapMs: 160,
  /** The skeleton breathes from 1 to 0.5 and back. */
  skeletonMs: 1200,
  highlightMs: 1000,
} as const;
