import { PreferenceSyncSlot } from "../../state/preference-sync-slot";
import { TranslationSettingsParentCloseContext } from "../../translation/navigation";
import { UPDATE_INDICATOR_COLOR } from "../../ui/update-indicator";
import { HoverControl } from "../hover-control";
import React, { memo, useCallback, useDeferredValue, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, type RefObject } from "react";
import {
  Animated,
  Platform,
  Pressable,
  RefreshControl,
  View,
  type FlatList as NativeFlatList,
  type ScrollView as NativeScrollView,
  type LayoutChangeEvent,
  useWindowDimensions,
} from "react-native";
import { FlatList, Icon, Modal, ScrollView } from "@getpaseo/plugin/client/ui";
import type { PluginScreenProps } from "@getpaseo/plugin/client";
import type { PluginTheme } from "@getpaseo/plugin";
import { TaskText as Text, HOST_FONT as F, HOST_LINE, TasksTypography, taskControlHeight } from "../typography";
import { EdgeActionBar, StatusIcon, TaskDetailCards, createDetailChrome, requestInSection, taskTokens, type CardCallbacks } from "../cards";
import { panelChrome } from "../cards/panel";
import { cardStrings } from "../cards/strings";
import { ActionPressable } from "../cards/action-pressable";
import { LANE_STATUS, isHistoryLane, turnRunning, type LaneId, type LaneModel, type TaskCard } from "../model";
import { activeStopChildren } from "../actions/stop-targets";
import { useReducedMotion } from "../../ui/use-reduced-motion";
import { holdHostGestures } from "../../ui/hold-host-gestures";
import { findHostHorizontalScroll } from "../../ui/host-horizontal-scroll";
import { HAIRLINE, MOTION, boardPalette } from "./board-style";
import { BoardEmptyState } from "./empty-state";
import { CardCell, HoverPressable, NewCardsDot, NewCardsPill, RollingCount, RoundButton, LaneFilterHint, LoadMoreRow, SkeletonCard, WindowSegments, laneHue, useBreathing, useFreshIds } from "./board-parts";
import { liftStyle, surfaceLift } from "../cards/surface-lift";
import { pillDirection, useSeenCards, useTrackNewCards, useUnseenCards, useUnseenLanes } from "./new-cards";
import { LaneMotionLayer, LaneMotionProvider, scrollNode, useLaneCovered, useLaneMotion, useLaneTarget } from "./lane-motion";
import { buildFilterOptions, clearedParams } from "./filter-options";
import { useUpdateIndicator } from "./update-indicator";
import { tasksSettingsOpener } from "./enabled";
import { SETTINGS_STRINGS } from "../../i18n/settings-page-strings";
import { useTasksLanguage } from "../i18n";
import { FilterSheetBody } from "./filter-sheet";
import { SearchCoverageItems } from "./search-coverage";
import { SearchQueryChip } from "./filter-bar";
import { PhoneSearch } from "./phone-search";
import { defaultLane, laneAfter, swallowsTap, swipeStep, tabsOverflow, type TabBox } from "./navigation";
import { activeFilterCount, rememberLane, rememberedLane, rememberPhoneLaneOffset, rememberedPhoneLaneOffset, rememberPhoneTabsOffset, rememberedPhoneTabsOffset, resolveBoardParams } from "./params";
import { sameDetailsBoard, useDetailReads, useParentTitle } from "./details-sidebar";
import { LANE_EMPTY_ICON, sortLabel } from "./strings";
import { sortsLoadedOnly } from "./sort";
import { findCard, type BoardController, type BoardLayoutHandlers } from "./use-board";
import { NO_SELECTION, SIDEBAR, selectionReducer, type SelectionAction, type SidebarSelection } from "./sidebar-model";
import type { DetailScrollOffsets } from "../cards/detail-cards";

const nativeDriver = Platform.OS !== "web";
/** iOS and Android page the lanes natively; web swipes them with pointer events. */
const isNative = () => Platform.OS === "ios" || Platform.OS === "android";
const ModalContent = Modal.Content as React.ComponentType<React.ComponentProps<typeof Modal.Content> & { footer?: React.ReactNode }>;
const Separator = () => <View style={{ height: 12 }} />;
/** A lane list's end space without the scroll shortcuts. */
const LANE_END_SPACE = 46;
const SCROLL_ACTION = { size: 48, bottom: 24 } as const;
/** With the shortcuts shown, the list ends this far down, so its last card and Load more scroll clear of them. */
const LANE_END_SPACE_WITH_ACTIONS = SCROLL_ACTION.bottom + SCROLL_ACTION.size + 12;

/** A touch (native) or pointer (web) event; both carry page coordinates. */
type PointEvent = { nativeEvent: { pageX: number; pageY: number } };
const point = (event: PointEvent) => ({ x: event.nativeEvent.pageX, y: event.nativeEvent.pageY });

// The sheet's safe area is the host's; the bodies pad themselves.
const SHEET_BODY = { paddingHorizontal: 0, paddingTop: 0, paddingBottom: 16, gap: 0 } as const;
// The filters bound their own scroll so their button stays pinned (FilterSheetBody).
const SHEET_FILTER_BODY = { ...SHEET_BODY, flex: 1, minHeight: 0 } as const;

type Sheet = { kind: "filters"; focus?: "sort" } | { kind: "details"; selection: SidebarSelection; scrollBack: DetailScrollOffsets[]; initialScroll?: DetailScrollOffsets } | null;
type DetailNavigation = Exclude<SelectionAction, { type: "jump" }> | { type: "jump"; id: string; offsets: DetailScrollOffsets };

/** The phone board (prototype 04): one lane at a time behind a tab bar, swiped or tapped. */
export function PhoneBoard(props: {
  screen: PluginScreenProps;
  board: BoardController;
  rootRef: RefObject<View | null>;
  handlers: RefObject<BoardLayoutHandlers | null>;
}) {
  const { screen, board, rootRef } = props;
  const theme = screen.theme;
  const colors = theme.colors;
  const hostId = screen.host.id;
  const { lanes, tasks, strings, laneOrder } = board;
  const reduced = useReducedMotion();
  const palette = boardPalette(theme);
  const cardLook = taskTokens(theme).card;

  const [picked, setChosen] = useState<LaneId | null>(() => rememberedLane(hostId));
  // The archived tab picked before the lane was turned off: back to the default lane.
  const chosen = picked && laneOrder.includes(picked) ? picked : null;
  const lane = defaultLane(lanes.needs_input.cards.length, chosen);
  const laneIndex = laneOrder.indexOf(lane);
  const [searchOpen, setSearchOpen] = useState(false);
  const [sheet, setSheet] = useState<Sheet>(null);
  // Counted only while the sheet shows them: a filter pressed on the board does not count every card again.
  const filtersOpen = sheet?.kind === "filters";
  const options = useMemo(() => (filtersOpen ? buildFilterOptions(tasks, board.params) : null), [filtersOpen, tasks, board.params]);
  const updateAvailable = useUpdateIndicator(hostId, board.visible) && !!tasksSettingsOpener();
  const updateLabel = SETTINGS_STRINGS[useTasksLanguage()].versionBadge;
  const badge = activeFilterCount(board.params, board.defaults);
  const { doneWindow, filters } = resolveBoardParams(board.params, board.defaults);

  // The tabs: a quarter of the bar each (a fifth with the archived lane), or
  // as wide as their content when a large system font outgrows that share,
  // the bar then scrolling sideways. The active tab is raised as a card.
  const [barWidth, setBarWidth] = useState(0);
  const [boxes, setBoxes] = useState<Partial<Record<LaneId, TabBox>>>({});
  const measureTab = useCallback((id: LaneId, part: keyof TabBox, layout: { x: number; width: number }) => {
    setBoxes((current) => {
      const box = current[id] ?? {};
      const was = box[part];
      if (was && was.x === layout.x && was.width === layout.width) return current;
      return { ...current, [id]: { ...box, [part]: { x: layout.x, width: layout.width } } };
    });
  }, []);
  const overflowing = tabsOverflow(boxes, barWidth, laneOrder.length);
  const tabsRef = useRef<NativeScrollView | null>(null);
  const [initialTabsOffset] = useState(() => isNative() ? rememberedPhoneTabsOffset(hostId) : undefined);
  const initialTab = useRef(lane);
  const positionedTab = useRef<LaneId | null>(null);
  const activeTabX = boxes[lane]?.tab?.x;
  useEffect(() => {
    if (!overflowing || activeTabX === undefined) return;
    if (!isNative()) {
      tabsRef.current?.scrollTo?.({ x: Math.max(0, activeTabX - 16), animated: !reduced });
      return;
    }
    if (positionedTab.current === lane) return;
    if (positionedTab.current === null && initialTabsOffset !== undefined && lane === initialTab.current) {
      positionedTab.current = lane;
      return;
    }
    const animated = positionedTab.current !== null && !reduced;
    positionedTab.current = lane;
    tabsRef.current?.scrollTo?.({ x: Math.max(0, activeTabX - 16), animated });
  }, [overflowing, activeTabX, reduced, lane, initialTabsOffset]);

  // The content switch: the old lane fades out moving 24 (120 ms) while the new one comes in from the other side (200 ms).
  const enterOpacity = useRef(new Animated.Value(1)).current;
  const enterX = useRef(new Animated.Value(0)).current;
  const leaveOpacity = useRef(new Animated.Value(0)).current;
  const leaveX = useRef(new Animated.Value(0)).current;
  const [leaving, setLeaving] = useState<{ lane: LaneId; cards: TaskCard[] } | null>(null);
  // The native pager's page turn, started before the render that shows the lane is drawn.
  const turnPager = useRef<((index: number) => void) | null>(null);
  const select = useCallback(
    (next: LaneId) => {
      const from = defaultLane(board.lanes.needs_input.cards.length, chosen);
      turnPager.current?.(laneOrder.indexOf(next));
      rememberLane(hostId, next);
      setChosen(next);
      if (next === from || reduced || isNative()) return;
      const direction = laneOrder.indexOf(next) > laneOrder.indexOf(from) ? 1 : -1;
      setLeaving({ lane: from, cards: board.lanes[from].cards.slice(0, 6) });
      leaveOpacity.setValue(1);
      leaveX.setValue(0);
      enterOpacity.setValue(0);
      enterX.setValue(direction * MOTION.laneShift);
      Animated.parallel([
        Animated.timing(leaveOpacity, { toValue: 0, duration: MOTION.laneOutMs, easing: MOTION.ease, useNativeDriver: nativeDriver }),
        Animated.timing(leaveX, { toValue: -direction * MOTION.laneShift, duration: MOTION.laneOutMs, easing: MOTION.ease, useNativeDriver: nativeDriver }),
        Animated.timing(enterOpacity, { toValue: 1, duration: MOTION.laneMs, easing: MOTION.ease, useNativeDriver: nativeDriver }),
        Animated.timing(enterX, { toValue: 0, duration: MOTION.laneMs, easing: MOTION.ease, useNativeDriver: nativeDriver }),
      ]).start(() => setLeaving(null));
    },
    [board.lanes, chosen, laneOrder, hostId, reduced, enterOpacity, enterX, leaveOpacity, leaveX],
  );

  // Swipes. On iOS and Android the lanes are pages of a native horizontal
  // pager: its pan takes a horizontal drag at the platform's touch slop,
  // natively, before the host's agent-list swipe activates at 15, which a
  // claim from JS could not (it lands a frame late on a fast swipe). The
  // vertical lists inside keep their own drags. On web a horizontal travel
  // of 56 that beats 1.5x the vertical switches the lane. Taps right after a
  // swipe are swallowed. A long press that opens a card's menu claims the
  // touch from the host's pans and locks the pager: the drag that follows
  // must not open the drawer, nor switch the lane under the menu.
  const swipeStart = useRef<{ x: number; y: number } | null>(null);
  const swipedAt = useRef<number | null>(null);
  const claimed = useRef<(() => void) | null>(null);
  const heldForMenu = useRef(false);
  const [pagerLocked, setPagerLocked] = useState(false);
  const gridRef = useRef<View>(null);
  const latest = useRef({ lane, select, laneOrder });
  latest.current = { lane, select, laneOrder };
  const claim = useCallback(() => {
    if (!isNative() || claimed.current) return;
    claimed.current = holdHostGestures(gridRef.current);
    setPagerLocked(true);
  }, []);
  const release = useCallback(() => {
    const letGo = claimed.current;
    claimed.current = null;
    letGo?.();
    setPagerLocked(false);
  }, []);
  useEffect(() => release, [release]);
  const onStart = useCallback((event: PointEvent) => {
    swipeStart.current = point(event);
    heldForMenu.current = false;
  }, []);
  const onMove = useCallback((event: PointEvent) => {
    const start = swipeStart.current;
    if (!start) return;
    const at = point(event);
    if (!heldForMenu.current && swipeStep(at.x - start.x, at.y - start.y) !== 0) swipedAt.current = Date.now();
  }, []);
  const onEnd = useCallback((event: PointEvent) => {
    const start = swipeStart.current;
    swipeStart.current = null;
    release();
    if (!start || heldForMenu.current || isNative()) return;
    const at = point(event);
    const step = swipeStep(at.x - start.x, at.y - start.y);
    if (step === 0) return;
    swipedAt.current = Date.now();
    const next = laneAfter(latest.current.lane, step, latest.current.laneOrder);
    if (next) latest.current.select(next);
  }, [release]);
  const onCancel = useCallback(() => {
    swipeStart.current = null;
    release();
  }, [release]);
  const markSwiped = useCallback(() => {
    swipedAt.current = Date.now();
  }, []);
  const settle = useCallback((next: LaneId) => {
    swipedAt.current = Date.now();
    if (next !== latest.current.lane) latest.current.select(next);
  }, []);
  const gesture = isNative()
    ? { onTouchStart: onStart, onTouchEnd: onEnd, onTouchCancel: onCancel }
    : { onPointerDown: onStart, onPointerMove: onMove, onPointerUp: onEnd, onPointerCancel: onCancel };

  // Android delivers a fast swipe's first move already past the 15 at which
  // the host's agent-list pan activates, and Gesture Handler sees each move
  // before the pager does. Past the first lane the board therefore tells the
  // host it is scrolled sideways, as Paseo's diff scroller does; the pan then
  // fails on its first move and a right swipe is the pager's. On the first
  // lane a right swipe may open the agent list as anywhere else.
  const scrollId = useId();
  const pagedAway = Platform.OS === "android" && laneIndex > 0 && board.visible;
  useEffect(() => {
    if (!pagedAway) return;
    const host = findHostHorizontalScroll(gridRef.current);
    if (!host) return;
    const id = `better-paseo:tasks-lanes:${scrollId}`;
    host.registerScrollOffset(id, 100);
    return () => host.unregisterScrollOffset(id);
  }, [pagedAway, scrollId]);

  const callbacks = useMemo<CardCallbacks>(() => {
    const base = board.callbacks;
    const guard =
      <Args extends unknown[]>(run: ((...args: Args) => void) | undefined) =>
      (...args: Args) => {
        if (!swallowsTap(swipedAt.current, Date.now())) run?.(...args);
      };
    return {
      titleUpdates: base.titleUpdates,
      onSearchPromptRetry: base.onSearchPromptRetry,
      onOpen: base.onOpen ? guard(base.onOpen) : undefined,
      onReveal: guard(base.onReveal),
      // Absent without the host's CLI: a guarded no-op would still draw Stop on every card.
      onStop: base.onStop ? guard(base.onStop) : undefined,
      onCancelStop: base.onCancelStop,
      onRead: base.onRead ? guard(base.onRead) : undefined,
      onUnread: base.onUnread ? guard(base.onUnread) : undefined,
      onUnarchive: base.onUnarchive ? guard(base.onUnarchive) : undefined,
      onArchive: base.onArchive ? guard(base.onArchive) : undefined,
      onFilter: base.onFilter,
      filterState: base.filterState,
      onPermission: guard(base.onPermission),
      // A tap shows the details sheet; the card's arrow still opens the tab.
      onSelect: guard((card: TaskCard) => setSheet({ kind: "details", selection: selectionReducer(NO_SELECTION, { type: "click", id: card.id }), scrollBack: [] })),
      onLongPress: () => {
        if (swallowsTap(swipedAt.current, Date.now())) return false;
        // A long press: the finger is still down.
        if (swipeStart.current) {
          heldForMenu.current = true;
          claim();
        }
        return true;
      },
    };
  }, [board.callbacks, claim]);

  const listRef = useRef<NativeFlatList<TaskCard> | null>(null);
  const scrollToTop = useRef<(() => void) | null>(null);
  props.handlers.current = {
    reveal(agentId) {
      const location = findCard(board.lanes, agentId);
      if (!location) {
        if (tasks.byId.has(agentId)) board.toastMessage(strings.hiddenByFilters);
        else tasks.resolveParent(agentId);
        return;
      }
      const switching = location.lane !== lane;
      if (switching) select(location.lane);
      setTimeout(
        () => {
          try {
            listRef.current?.scrollToIndex({ index: location.index, viewPosition: 0, viewOffset: 12, animated: true });
          } catch {
            // Laid out later; the highlight still marks it.
          }
          board.highlight(agentId);
        },
        switching && !reduced ? MOTION.laneMs + 20 : 0,
      );
    },
    details(card, _preview, parent) {
      setSheet({ kind: "details", selection: selectionReducer(NO_SELECTION, { type: "click", id: card.id, parent }), scrollBack: [] });
    },
  };

  useLayoutEffect(() => {
    if (isNative()) return;
    const node = gridRef.current as unknown as HTMLElement | null;
    // Vertical scrolling stays the browser's; horizontal travel is the lane swipe.
    if (node?.style) node.style.touchAction = "pan-y";
  }, []);
  const breathing = useBreathing(!tasks.ready && board.visible);
  // One lane on screen: its cards close the gap a card leaves, and the card fades where it was.
  const motion = useLaneMotion(lanes, { enabled: board.visible && tasks.ready && !reduced, scope: board.scope, flights: false });
  useTrackNewCards(board.hostId, lanes, tasks.ready);
  // A lane not shown with new tasks in it: its tab says so.
  const unseenLanes = useUnseenLanes(board.hostId);
  const renderCopy = useCallback(
    (card: TaskCard) => <CardCell board={board} card={card} theme={theme} compact fresh={false} copy callbacks={callbacks} />,
    [board, theme, callbacks],
  );
  const selection = sheet?.kind === "details" ? sheet.selection : NO_SELECTION;
  const detailsCard = selection.id ? board.cardById(selection.id) : undefined;
  const backId = selection.back[selection.back.length - 1]?.id;
  const backCard = backId ? board.cardById(backId) : undefined;
  // The details' neighbours in their lane, for the sheet's stepper: the body itself draws again only for its card.
  const detailsList = detailsCard ? board.lanes[detailsCard.lane]?.cards ?? [] : [];
  const detailsIndex = detailsCard ? detailsList.findIndex((item) => item.id === detailsCard.id) : -1;
  const showDetails = useCallback((id: string) => setSheet({ kind: "details", selection: selectionReducer(NO_SELECTION, { type: "click", id }), scrollBack: [] }), []);
  const closeDetailsSheet = useCallback(() => setSheet(null), []);
  const navigateDetails = useCallback((action: DetailNavigation) => setSheet((current) => {
    if (current?.kind !== "details") return current;
    const selection = selectionReducer(current.selection, action);
    if (selection === current.selection) return current;
    if (action.type === "jump") return { ...current, selection, scrollBack: [...current.scrollBack, action.offsets].slice(-SIDEBAR.history), initialScroll: undefined };
    if (action.type === "back") return { ...current, selection, initialScroll: current.scrollBack[current.scrollBack.length - 1], scrollBack: current.scrollBack.slice(0, -1) };
    return { ...current, selection };
  }), []);
  const openFromDetails = useMemo(() => {
    const onOpen = board.callbacks.onOpen;
    return onOpen ? (agentId: string) => {
      setSheet(null);
      onOpen(agentId);
    } : undefined;
  }, [board.callbacks.onOpen]);
  const warning = taskTokens(theme).status.warning;

  return (
    <View ref={rootRef} collapsable={false} style={{ flex: 1, backgroundColor: colors.surface0 }}>
      <View style={{ minHeight: 52, flexDirection: "row", alignItems: "center", gap: 6, paddingLeft: 6, paddingRight: 6 }}>
        <RoundButton
          icon="Search"
          iconSize={22}
          borderless
          label={strings.searchButton}
          active={searchOpen || board.params.query !== ""}
          theme={theme}
          onPress={() => setSearchOpen((open) => !open)}
        />
        <Text pointerEvents="none" numberOfLines={1} style={{ flexShrink: 1, marginLeft: -10, fontSize: F.lg, fontWeight: "600", color: colors.foreground, fontVariant: ["tabular-nums"] }}>
          {strings.total(board.total)}
        </Text>
        {board.params.sort ? (
          // A non-default sort says so, as the desktop sort button's label does; it opens the sheet.
          <HoverPressable hoverTheme={theme}
            lift="toolbar"
            accessibilityRole="button"
            accessibilityLabel={`${strings.sort}: ${sortLabel(board.params.sort, strings)}`}
            onPress={() => setSheet({ kind: "filters", focus: "sort" })}
            testID="phone-sort-hint"
            style={(hovered, pressed, input) => ({
              flexShrink: 1,
              minHeight: 28,
              marginLeft: 4,
              paddingHorizontal: 10,
              borderRadius: 14,
              borderWidth: HAIRLINE,
              borderColor: colors.border,
              ...liftStyle(() => taskTokens(theme), surfaceLift(hovered, pressed, undefined, "toolbar", input), { border: colors.border }),
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
            })}
          >
            <Icon name="ArrowUpDown" size={13} color={colors.foregroundMuted} />
            <Text numberOfLines={1} style={{ flexShrink: 1, fontSize: F.base, fontWeight: "500", color: colors.foreground }}>
              {sortLabel(board.params.sort, strings)}
            </Text>
          </HoverPressable>
        ) : null}
        <View style={{ flex: 1 }} />
        <View style={{ flexDirection: "row" }}>
          <RoundButton
            icon={filters.hideSubtasks ? "List" : "Network"}
            iconSize={22}
            borderless
            label={strings.showSubtasks}
            selected={!filters.hideSubtasks}
            toggle
            cornerBadge={board.hiddenSubtasks}
            theme={theme}
            onPress={() => board.setParams((params) => ({ ...params, hideSubtasks: !(params.hideSubtasks ?? board.defaults.hideSubtasks) }))}
            testID="phone-subtasks"
          />
          <RoundButton
            icon="Archive"
            iconSize={22}
            borderless
            style={{ marginLeft: -6 }}
            label={strings.archivedLane.row}
            selected={board.showArchived}
            toggle
            slashed={!board.showArchived}
            theme={theme}
            onPress={() => board.setShowArchived(!board.showArchived)}
            testID="phone-archived"
          />
          <View testID="phone-more-container" style={{ width: 44, height: 44, marginLeft: -6 }}>
            <RoundButton icon="MoreVertical" iconSize={22} iconContent={<View style={{ alignItems: "center", gap: 3.5 }}>{[0, 1, 2].map((dot) => <View key={dot} testID="phone-more-dot" style={{ width: 3, height: 3, borderRadius: 1.5, backgroundColor: colors.foreground }} />)}</View>} borderless label={updateAvailable ? `${strings.more}, ${updateLabel}` : strings.more} theme={theme} badge={badge} onPress={() => setSheet({ kind: "filters" })} testID="phone-more" />
            {updateAvailable ? <View testID="phone-more-update-dot" pointerEvents="none" style={{ position: "absolute", bottom: 10, right: 11, width: 4, height: 4, borderRadius: 2, backgroundColor: UPDATE_INDICATOR_COLOR }} /> : null}
          </View>
        </View>
      </View>
      <PhoneSearch
        visible={searchOpen || board.params.query !== ""}
        autoFocus={searchOpen && !board.params.query}
        query={board.params.query}
        onChange={(query) => board.setParams((params) => ({ ...params, query }))}
        placeholder={strings.search}
        clear={strings.menuSearch.clear}
        theme={theme}
      />
      {board.params.query.trim() ? <ScrollView testID="phone-search-summary" horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, flexShrink: 0 }} contentContainerStyle={{ paddingHorizontal: 16, flexDirection: "row", alignItems: "center", gap: 8 }}>
        <SearchQueryChip board={board} theme={theme} scrollable={false} />
        <SearchCoverageItems theme={theme} phone />
      </ScrollView> : null}
      <View
        onLayout={(event: LayoutChangeEvent) => setBarWidth(event.nativeEvent.layout.width)}
        style={{ borderBottomWidth: HAIRLINE, borderBottomColor: colors.border, zIndex: 5, backgroundColor: palette.panel }}
      >
        <ScrollView
          ref={tabsRef}
          horizontal
          contentOffset={initialTabsOffset === undefined ? undefined : { x: initialTabsOffset, y: 0 }}
          onScroll={(event) => { if (isNative()) rememberPhoneTabsOffset(hostId, event.nativeEvent.contentOffset.x); }}
          scrollEventThrottle={16}
          scrollEnabled={overflowing}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ flexGrow: 1, minWidth: barWidth, paddingHorizontal: 8, paddingVertical: 4, gap: 4 }}
        >
          {laneOrder.map((id) => {
            const on = id === lane;
            const count = lanes[id].cards.length;
            const warn = id === "needs_input" && count > 0;
            // The status counts as the lane switch, one line each: a segmented
            // control on the panel's track, the shown lane's cell raised as a card.
            return (
              <HoverControl base={on ? cardLook.background : palette.panel} foreground={colors.foreground} rest={on ? cardLook.background : "transparent"}
                key={id}
                accessibilityRole="tab"
                accessibilityState={{ selected: on }}
                accessibilityLabel={`${strings.lanes[id]} ${count}${!on && unseenLanes.has(id) ? `, ${strings.newTasksIn(strings.lanes[id])}` : ""}`}
                onPress={() => id === lane ? scrollToTop.current?.() : select(id)}
                onLayout={(event: LayoutChangeEvent) => measureTab(id, "tab", event.nativeEvent.layout)}
                testID={`phone-stat-${id}`}
                style={{
                  flexGrow: 1,
                  flexBasis: 0,
                  minWidth: overflowing ? undefined : (barWidth - 16 - 4 * (laneOrder.length - 1)) / laneOrder.length,
                  minHeight: 36,
                  paddingHorizontal: overflowing ? 10 : 4,
                  borderRadius: 8,
                  borderWidth: HAIRLINE,
                  borderColor: on ? cardLook.border : "transparent",
                  backgroundColor: on ? cardLook.background : "transparent",
                  boxShadow: on ? cardLook.shadow : undefined,
                  alignItems: "center",
                  justifyContent: "center",
                } as object}
              >
                <View
                  onLayout={(event: LayoutChangeEvent) => measureTab(id, "row", event.nativeEvent.layout)}
                  style={{ flexDirection: "row", alignItems: "center", gap: 5 }}
                >
                  <StatusIcon kind={LANE_STATUS[id]} size={13} theme={theme} animated={board.visible} />
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                    <Text numberOfLines={1} style={{ fontSize: F.base, fontWeight: on ? "600" : "500", color: on ? colors.foreground : colors.foregroundMuted }}>
                      {strings.tabs[id]}
                    </Text>
                    {tasks.ready ? (
                      <View>
                        <RollingCount
                          value={count}
                          scope={board.scope}
                          style={{ fontSize: F.base, fontWeight: warn || on ? "600" : "400", fontVariant: ["tabular-nums"], color: warn ? warning : on ? colors.foreground : colors.foregroundMuted }}
                        />
                        {/* Out of the row's flow, so the labels do not move for it. */}
                        <View pointerEvents="none" style={{ position: "absolute", top: 1, right: -8 }}>
                          <NewCardsDot on={!on && unseenLanes.has(id)} hue={laneHue(theme, id)} testID={`phone-new-dot-${id}`} />
                        </View>
                      </View>
                    ) : null}
                  </View>
                </View>
              </HoverControl>
            );
          })}

        </ScrollView>
      </View>
      {isHistoryLane(lane) ? (
        <View style={{ minHeight: 48, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, borderBottomWidth: HAIRLINE, borderBottomColor: colors.border }}>
          <Text style={{ fontSize: F.sm, color: colors.foregroundMuted }}>{strings.timeRange}</Text>
          <WindowSegments value={doneWindow} onChange={(value) => board.setParams((params) => ({ ...params, doneWindow: value }))} theme={theme} strings={strings} large />
        </View>
      ) : null}
      <View ref={gridRef} collapsable={false} style={{ flex: 1, minHeight: 0, overflow: "hidden", backgroundColor: palette.panel }} {...gesture}>
        <LaneMotionProvider value={motion}>
          {isNative() ? (
            <LanePager
              lane={lane}
              board={board}
              theme={theme}
              callbacks={callbacks}
              listRef={listRef}
              scrollToTop={scrollToTop}
              breathing={breathing}
              reduced={reduced}
              locked={pagerLocked}
              onDrag={markSwiped}
              onSettle={settle}
              turn={turnPager}
            />
          ) : (
          <Animated.View style={{ flex: 1, opacity: enterOpacity, transform: [{ translateX: enterX }] }}>
            <PhoneLane
              key={lane}
              lane={lanes[lane]}
              board={board}
              theme={theme}
              callbacks={callbacks}
              listRef={listRef}
              scrollToTop={scrollToTop}
              breathing={breathing}
            />
          </Animated.View>
          )}
          {!isNative() && leaving ? (
            <Animated.View
              pointerEvents="none"
              style={{ position: "absolute", top: 0, left: 0, right: 0, padding: 12, gap: 12, opacity: leaveOpacity, transform: [{ translateX: leaveX }] }}
            >
              {leaving.cards.map((card) => (
                <CardCell
                  board={board}
                  key={card.id}
                  card={card}
                  theme={theme}
                  compact
                  callbacks={callbacks}
                  fresh={false}
                  copy
                />
              ))}
            </Animated.View>
          ) : null}
          <LaneMotionLayer store={motion} renderCard={renderCopy} />
        </LaneMotionProvider>
      </View>
      {board.notice ? (
        // The board's messages sit at its bottom: the host's toast, at the
        // top, covered the header's task count for seconds.
        <View pointerEvents="box-none" style={{ position: "absolute", left: 12, right: 12, bottom: 16, alignItems: "center", zIndex: 30 }}>
          <Pressable
            key={board.notice.id}
            accessibilityRole="alert"
            accessibilityLiveRegion="polite"
            onPress={board.dismissNotice}
            testID="phone-board-notice"
            style={{
              ...panelChrome(theme),
              elevation: 6,
              maxWidth: 480,
              minHeight: 44,
              paddingHorizontal: 14,
              paddingVertical: 10,
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Icon
              name={board.notice.tone === "error" ? "CircleAlert" : "Info"}
              size={16}
              color={board.notice.tone === "error" ? taskTokens(theme).danger : colors.foregroundMuted}
            />
            <Text style={{ flexShrink: 1, fontSize: F.base, lineHeight: HOST_LINE.base, color: colors.foreground }}>{board.notice.message}</Text>
          </Pressable>
        </View>
      ) : null}
      {/* The host draws a sheet in its own portal, outside the board's type scale: each sheet carries its own. */}
      <Modal title={strings.more} open={sheet?.kind === "filters"} onOpenChange={(open) => !open && setSheet(null)}>
        <Modal.Content contentContainerStyle={SHEET_FILTER_BODY} scrollable={false}>
          <TasksTypography theme={theme}>
            {sheet?.kind === "filters" && options ? <FilterSheetBody board={board} theme={theme} options={options} updateAvailable={updateAvailable} phone hideSubtasksToggle showEmptyGroupsToggle focus={sheet.focus} onDone={() => setSheet(null)} /> : null}
          </TasksTypography>
        </Modal.Content>
      </Modal>
      <Modal title={strings.details} open={detailsCard !== undefined} onOpenChange={(open) => !open && setSheet(null)}>
        <DetailsSheetContent
          card={detailsCard}
          board={board}
          theme={theme}
          index={detailsIndex}
          count={detailsList.length}
          previousId={detailsList[detailsIndex - 1]?.id ?? null}
          nextId={detailsList[detailsIndex + 1]?.id ?? null}
          onShow={showDetails}
          selection={selection}
          initialScroll={sheet?.kind === "details" ? sheet.initialScroll : undefined}
          backTitle={backId ? backCard?.title ?? cardStrings(board.language).parentUnknown : undefined}
          navigate={navigateDetails}
          onOpen={openFromDetails}
          onCloseSheet={closeDetailsSheet}
        />
      </Modal>
    </View>
  );
}

/**
 * The phone's details sheet: the sidebar's details card at touch sizes,
 * under a bar that steps to the previous and next card of the same lane. The
 * card scrolls; its actions stay pinned at the bottom, at thumb height.
 */
interface DetailsSheetBodyProps {
  card: TaskCard;
  board: BoardController;
  theme: PluginTheme;
  /** The card's place in its lane and the lane's length, for the stepper; -1 when the filters leave it out. */
  index: number;
  count: number;
  previousId: string | null;
  nextId: string | null;
  onShow(id: string): void;
  selection: SidebarSelection;
  initialScroll?: DetailScrollOffsets;
  backTitle?: string;
  navigate(action: DetailNavigation): void;
  onOpen?(agentId: string): void;
  onCloseSheet(): void;
  edge: ReturnType<typeof createDetailChrome>;
  inlineFooter: boolean;
}

function DetailsSheetContent(props: Omit<DetailsSheetBodyProps, "card" | "edge" | "inlineFooter"> & { card?: TaskCard }) {
  const [edge] = useState(createDetailChrome);
  // Hosts before the footer slot keep the original inline action bar.
  const footerSlot = Platform.OS === "android" && (Modal as typeof Modal & { supportsFooter?: boolean }).supportsFooter === true;
  const footer = props.card && !requestInSection(props.card, props.board.buttonsFor(props.card))
    ? <DetailsSheetFooter card={props.card} board={props.board} theme={props.theme} onOpen={props.onOpen} edge={edge} />
    : null;
  const separateFooter = footerSlot && footer !== null;
  return (
    <ModalContent
      contentContainerStyle={Platform.OS === "ios" || separateFooter ? { ...SHEET_FILTER_BODY, paddingBottom: 0 } : SHEET_FILTER_BODY}
      scrollable={false}
      footer={separateFooter ? <TasksTypography theme={props.theme}><View style={{ paddingBottom: SHEET_BODY.paddingBottom }}>{footer}</View></TasksTypography> : undefined}
    >
      <TasksTypography theme={props.theme}>
        {props.card ? <DetailsSheetBody {...props} card={props.card} edge={edge} inlineFooter={!footerSlot} /> : null}
      </TasksTypography>
    </ModalContent>
  );
}

/** Every running agent's update changes the board; the body draws again only for its own card (`sameDetailsBoard`). */
const DetailsSheetBody = memo(DetailsSheetBodyView, (last: DetailsSheetBodyProps, next: DetailsSheetBodyProps) => {
  const keys = Object.keys(next) as (keyof DetailsSheetBodyProps)[];
  return keys.length === Object.keys(last).length && keys.every((key) => key === "board" ? sameDetailsBoard(last.board, next.board) : last[key] === next[key]);
});

function DetailsSheetBodyView(props: DetailsSheetBodyProps) {
  const { card, board, theme, index } = props;
  const colors = theme.colors;
  useParentTitle(board, card);
  const { firstPrompt, humanMessage, lastMessage, sessionTokens, questionContext } = useDetailReads(board, card);
  const step = (delta: number) => {
    const next = delta < 0 ? props.previousId : props.nextId;
    if (next) props.onShow(next);
  };
  const stopAvailable = !!board.callbacks.onStop && (card.stoppable || activeStopChildren(card).length > 0);
  const stop = stopAvailable ? { phase: board.stop.phase(card.id), onPress: () => board.callbacks.onStop?.(card, { withChildren: !card.stoppable }) } : null;
  const onPermission = (button: Parameters<NonNullable<typeof board.callbacks.onPermission>>[1]) => board.callbacks.onPermission?.(card, button);
  // Whether the card's content runs under the action bar: only the bar draws again when it changes.
  const noteEdge = useCallback((under: boolean) => props.edge.set({ headerUnderBar: under }), [props.edge]);
  return (
    <View style={{ flex: 1, minHeight: 0 }}>
      <PreferenceSyncSlot />
      {index >= 0 && props.count > 1 ? (
        <View style={{ minHeight: 40, paddingHorizontal: 12, flexDirection: "row", alignItems: "center" }} testID="sheet-stepper">
          <SheetStep icon="ChevronLeft" label={board.strings.sidebar.previous} disabled={index <= 0} onPress={() => step(-1)} theme={theme} />
          <Text style={{ flex: 1, textAlign: "center", fontSize: F.sm, color: colors.foregroundMuted, fontVariant: ["tabular-nums"] }}>
            {`${board.strings.lanes[card.lane]} · ${index + 1} / ${props.count}`}
          </Text>
          <SheetStep icon="ChevronRight" label={board.strings.sidebar.next} disabled={index >= props.count - 1} onPress={() => step(1)} theme={theme} />
        </View>
      ) : null}
      {/* Keyed by the card: a jump to the parent or a step starts on its messages. */}
      <View style={{ flex: 1, minHeight: 0, paddingHorizontal: 12, paddingTop: 4, paddingBottom: 12 }}>
        <TranslationSettingsParentCloseContext.Provider value={props.onCloseSheet}>
        <TaskDetailCards
          key={card.id}
          translationAgentId={card.subagent ? card.parent?.id : card.id}
          searchQuery={board.params.query}
          card={card}
          theme={theme}
          language={board.language}
          strings={board.strings.sidebar}
          touch
          compact
          tabs
          initialTab={props.selection.tab}
          initialScrollOffsets={props.initialScroll}
          onTabChange={(tab) => props.navigate({ type: "tab", tab })}
          back={props.backTitle ? { title: props.backTitle, onPress: () => props.navigate({ type: "back" }) } : null}
          scrollHeader
          indicatorOutside
          actions={false}
          questionActionsInHeader
          clock={board.clock}
          onOpen={props.onOpen}
          stop={stop}
          questionDialog={board.questionDialog}
          submitQuestions={board.submitQuestions}
          permissionButtons={board.buttonsFor(card)}
          onPermission={onPermission}
          onJumpWithScroll={(id, offsets) => props.navigate({ type: "jump", id, offsets })}
          titleUpdates={board.callbacks.titleUpdates}
          firstPrompt={firstPrompt}
          humanMessage={humanMessage}
          lastMessage={lastMessage}
          questionContext={questionContext}
          sessionTokens={sessionTokens}
          unarchive={board.unarchive.available ? board.unarchive : null}
          archive={board.archive}
          markRead={board.read.available ? board.read : null}
          markUnread={board.unread ?? null}
          onScrollEdge={noteEdge}
        />
        </TranslationSettingsParentCloseContext.Provider>
      </View>
      {props.inlineFooter && !requestInSection(card, board.buttonsFor(card)) ? <DetailsSheetFooter card={card} board={board} theme={theme} onOpen={props.onOpen} edge={props.edge} /> : null}
    </View>
  );
}

function DetailsSheetFooter(props: Pick<DetailsSheetBodyProps, "card" | "board" | "theme" | "onOpen" | "edge">) {
  const { card, board, theme } = props;
  const stopAvailable = !!board.callbacks.onStop && (card.stoppable || activeStopChildren(card).length > 0);
  const stop = stopAvailable ? { phase: board.stop.phase(card.id), onPress: () => board.callbacks.onStop?.(card, { withChildren: !card.stoppable }) } : null;
  const onPermission = (button: Parameters<NonNullable<typeof board.callbacks.onPermission>>[1]) => board.callbacks.onPermission?.(card, button);
  return <EdgeActionBar
        chrome={props.edge}
        scrollHeader
        flushBottom={Platform.OS === "ios"}
        card={card}
        theme={theme}
        language={board.language}
        strings={board.strings.sidebar}
        onOpen={props.onOpen}
        stop={stop}
        permissionButtons={board.buttonsFor(card)}
        onPermission={onPermission}
        unarchive={board.unarchive.available ? board.unarchive : null}
        archive={board.archive}
        markRead={board.read.available ? board.read : null}
        markUnread={board.unread ?? null}
      />;
}

function SheetStep(props: { icon: string; label: string; disabled: boolean; onPress(): void; theme: PluginTheme }) {
  return (
    <HoverControl base={props.theme.colors.surface0} foreground={props.theme.colors.foreground}
      accessibilityRole="button"
      accessibilityLabel={props.label}
      accessibilityState={{ disabled: props.disabled }}
      disabled={props.disabled}
      onPress={props.onPress}
      hitSlop={4}
      style={{ width: 44, height: 40, alignItems: "center", justifyContent: "center", opacity: props.disabled ? 0.35 : 1 }}
    >
      <Icon name={props.icon} size={20} color={props.theme.colors.foreground} />
    </HoverControl>
  );
}


/**
 * The phone's lanes on iOS and Android: one page each in a native paging
 * ScrollView, so a horizontal drag is the pager's from the platform's touch
 * slop on and the host's agent-list pan never starts (a UIScrollView pan
 * begins first and fails it on iOS; on Android the scroller asks its parents
 * not to intercept, which cancels Gesture Handler's pans). Only the lane
 * shown and its neighbours mount; a tab more than one lane away jumps.
 */
// Sheet state belongs to PhoneBoard; opening it must not redraw the pages behind it.
export const LanePager = memo(function LanePager(props: {
  lane: LaneId;
  board: BoardController;
  theme: PluginTheme;
  callbacks: CardCallbacks;
  listRef: RefObject<NativeFlatList<TaskCard> | null>;
  scrollToTop: RefObject<(() => void) | null>;
  breathing: Animated.Value;
  reduced: boolean;
  /** A long press holds the touch: the pager stays where it is. */
  locked: boolean;
  onDrag(): void;
  /** The pager came to rest on another lane. */
  onSettle(lane: LaneId): void;
  /** Set to a function that turns the pager to a page at once, before the board draws the lane. */
  turn?: RefObject<((index: number) => void) | null>;
}) {
  const { lane, board, theme, onSettle } = props;
  // The pages beside the shown one take a board update in a later render
  // that React may split across frames: a filter's new cards there do not
  // mount in the frame that starts its motion. A page shown is never behind.
  const besideBoard = useDeferredValue(board);
  const window = useWindowDimensions();
  // Only width affects paging; native layout follows height changes without redrawing every lane.
  const [size, setSize] = useState<{ width: number } | null>(null);
  const width = size?.width || window.width;
  const order = board.laneOrder;
  const index = order.indexOf(lane);
  // Native offset prop updates jump immediately; later turns and resizes use scrollTo.
  const [initialOffset] = useState(() => ({ x: index * width, y: 0 }));
  const pagerRef = useRef<NativeScrollView | null>(null);
  // The page the pager rests on, and the width it was placed at; -1 until
  // laid out, when it is placed once more without animating.
  const resting = useRef({ index, width: -1 });
  const measured = size !== null;
  useLayoutEffect(() => {
    const was = resting.current;
    const at = measured ? width : -1;
    if (was.index === index && was.width === at) return;
    const animated = !props.reduced && was.width === at && Math.abs(was.index - index) === 1;
    resting.current = { index, width: at };
    pagerRef.current?.scrollTo?.({ x: index * width, y: 0, animated });
  }, [index, width, measured, props.reduced]);
  // A tab next to the shown one: the page turns natively from the press, while the board
  // draws the lane, instead of after that render (some 200 ms on a slow phone). Its page is
  // already mounted beside the shown one; the render then finds the pager resting there.
  const { turn, reduced } = props;
  useLayoutEffect(() => {
    if (!turn) return;
    const go = (next: number) => {
      const was = resting.current;
      if (reduced || !measured || was.width !== width || Math.abs(was.index - next) !== 1) return;
      resting.current = { index: next, width };
      pagerRef.current?.scrollTo?.({ x: next * width, y: 0, animated: true });
    };
    turn.current = go;
    return () => { if (turn.current === go) turn.current = null; };
  }, [turn, reduced, measured, width]);
  // A page that comes beside the shown one mounts in a later, interruptible render, so the
  // render that settles on a lane only draws what was already on screen.
  const near = useDeferredValue(index);
  const settleAt = useCallback(
    (x: number) => {
      if (width <= 0) return;
      const page = Math.max(0, Math.min(order.length - 1, Math.round(x / width)));
      resting.current = { index: page, width };
      const next = order[page]!;
      if (next !== lane) onSettle(next);
    },
    [width, lane, order, onSettle],
  );
  return (
    <ScrollView
      ref={pagerRef}
      horizontal
      pagingEnabled
      scrollEnabled={!props.locked}
      directionalLockEnabled
      nestedScrollEnabled
      showsHorizontalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      contentOffset={initialOffset}
      onLayout={(event: LayoutChangeEvent) => {
        const next = event.nativeEvent.layout;
        setSize((was) => (was && was.width === next.width ? was : { width: next.width }));
      }}
      onScrollBeginDrag={props.onDrag}
      onScrollEndDrag={(event: { nativeEvent: { contentOffset: { x: number } } }) => {
        // A release exactly on a page has no momentum to end.
        const x = event.nativeEvent.contentOffset.x;
        if (width > 0 && Math.abs(x - Math.round(x / width) * width) < 1) settleAt(x);
      }}
      onMomentumScrollEnd={(event: { nativeEvent: { contentOffset: { x: number } } }) => settleAt(event.nativeEvent.contentOffset.x)}
      style={{ flex: 1 }}
      contentContainerStyle={{ height: "100%" }}
      testID="phone-lane-pager"
    >
      {order.map((id, at) => (
        <View key={id} testID={`phone-lane-${id}`} style={{ width, height: "100%" }}>
          {at === index || Math.abs(at - index) === 1 && Math.abs(at - near) <= 1 ? (
            <PhoneLane
              lane={(at === index ? board : besideBoard).lanes[id]}
              board={at === index ? board : besideBoard}
              theme={theme}
              callbacks={props.callbacks}
              listRef={at === index ? props.listRef : undefined}
              scrollToTop={at === index ? props.scrollToTop : undefined}
              breathing={props.breathing}
              active={at === index}
            />
          ) : null}
        </View>
      ))}
    </ScrollView>
  );
});

// Memoized so a page beside the shown one, given the board it already had, skips the render.
// Also covers the web's single lane and pager layout changes with unchanged lane props.
const PhoneLane = memo(function PhoneLane(props: {
  lane: LaneModel;
  board: BoardController;
  theme: PluginTheme;
  callbacks: CardCallbacks;
  listRef?: RefObject<NativeFlatList<TaskCard> | null>;
  scrollToTop?: RefObject<(() => void) | null>;
  breathing: Animated.Value;
  /** The lane on screen; a neighbour in the pager loads no more. */
  active?: boolean;
}) {
  const { lane, board, theme } = props;
  const [refreshing, setRefreshing] = useState(false);
  const [viewportHeight, setViewportHeight] = useState(0);
  // The list's content height without the end space it was measured with. Each batch of
  // mounted rows changes it, so it is kept off render: only whether the list is taller
  // than two screens (the scroll actions show) draws the lane again.
  const contentHeight = useRef(0);
  const [tall, setTall] = useState(false);
  const [initialOffset] = useState(() => isNative() ? rememberedPhoneLaneOffset(board.hostId, lane.id) : 0);
  // iOS sets a mount's contentOffset before the list can emit events, so the list would lay out its
  // window and report the cards on screen from 0. It is restored by a scroll after mount instead,
  // whose event the list reads; until that event, what the list reports on screen is from 0.
  const [restoring, setRestoring] = useState(() => Platform.OS === "ios" && initialOffset > 0);
  const restoreSent = useRef(false);
  const offset = useRef(initialOffset);
  const [atBottom, setAtBottom] = useState(false);
  const updateEdges = (y: number, height: number, viewport: number) => {
    offset.current = y;
    setAtBottom(y + viewport >= height - 1);
  };
  const reduced = useReducedMotion();
  const colors = theme.colors;
  const strings = board.strings;
  const ready = board.tasks.ready;
  const count = lane.cards.length;
  const loadingCards = !ready || (lane.initialLoading && count === 0);
  const isFresh = useFreshIds(
    lane.cards.map((card) => card.id),
    ready,
    board.scope,
  );
  // New tasks: seen once on screen in the lane shown; until then its pill says so.
  const unseen = useUnseenCards(board.hostId, lane.id);
  const seen = useSeenCards(board.hostId, lane.id, board.visible && props.active !== false && !restoring);
  // Hidden under copies of its cards while they move (native lane motion).
  const covered = useLaneCovered(lane.id);
  // Its list is what the lane shows: a card that leaves its end lets the list scroll back.
  const listRef = useRef<NativeFlatList<TaskCard> | null>(null);
  const scrollRetry = useRef<{ params: Parameters<NativeFlatList<TaskCard>["scrollToIndex"]>[0]; attempts: number } | null>(null);
  const scrollTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelScroll = useCallback(() => {
    if (scrollTimer.current !== null) clearTimeout(scrollTimer.current);
    scrollTimer.current = null;
    scrollRetry.current = null;
  }, []);
  useEffect(() => cancelScroll, [cancelScroll, count]);
  useLayoutEffect(() => {
    if (!props.scrollToTop) return;
    const ref = props.scrollToTop;
    const scroll = () => {
      cancelScroll();
      listRef.current?.scrollToOffset({ offset: 0, animated: !reduced });
    };
    ref.current = scroll;
    return () => { if (ref.current === scroll) ref.current = null; };
  }, [props.scrollToTop, cancelScroll, reduced]);
  useLaneTarget(lane.id, () => scrollNode(listRef.current), (offset) => listRef.current?.scrollToOffset({ offset, animated: false }));
  const { listRef: shared } = props;
  const setList = useCallback(
    (list: NativeFlatList<TaskCard> | null) => {
      listRef.current = list;
      if (shared) shared.current = list;
    },
    [shared],
  );
  useLayoutEffect(() => {
    if (!restoring || restoreSent.current || loadingCards) return;
    restoreSent.current = true;
    if (count > 0) {
      listRef.current?.scrollToOffset({ offset: initialOffset, animated: false });
      return;
    }
    // An emptied lane has nothing to come back to: it stays at its top.
    offset.current = 0;
    rememberPhoneLaneOffset(board.hostId, lane.id, 0);
    setRestoring(false);
  }, [restoring, loadingCards, count, initialOffset, board.hostId, lane.id]);
  // No clock in here: a tick reaches the timer texts, not the list and its rows.
  const { callbacks } = props;
  const { highlighted, stop, read, fields } = board;
  const extraData = useMemo(() => ({ highlighted, stop, read, fields, callbacks }), [highlighted, stop, read, fields, callbacks]);
  const renderItem = useCallback(
    ({ item }: { item: TaskCard }) => <CardCell board={board} card={item} theme={theme} compact callbacks={callbacks} fresh={isFresh(item.id)} />,
    [board, theme, callbacks, isFresh],
  );
  if (loadingCards) {
    return (
      <View style={{ padding: 12, gap: 12 }}>
        {[0, 1, 2].map((index) => (
          <SkeletonCard key={index} index={index} theme={theme} opacity={props.breathing} />
        ))}
      </View>
    );
  }
  const filtered = activeFilterCount(board.params, board.defaults) > 0;
  const scrollActions = props.active !== false && viewportHeight > 0 && tall;
  const endSpace = scrollActions ? LANE_END_SPACE_WITH_ACTIONS : LANE_END_SPACE;
  // A history lane with more pages ends at its loaded cards, and reaching them loads one more page as scrolling there does.
  const loadedEnd = isHistoryLane(lane.id) && (lane.hasMore || lane.loading);
  const onRefresh = () => {
    if (refreshing) return;
    setRefreshing(true);
    void Promise.resolve().then(board.tasks.refresh).catch(() => "failed").finally(() => setRefreshing(false));
  };
  return (
    <View style={{ flex: 1, minHeight: 0 }} onLayout={(event: LayoutChangeEvent) => {
      const height = event.nativeEvent.layout.height;
      setViewportHeight(height);
      setTall(contentHeight.current > height * 2);
      updateEdges(offset.current, contentHeight.current + endSpace, height);
    }}>
    <FlatList<TaskCard>
      ref={setList}
      // Android reports this offset with a scroll event once it applies it.
      contentOffset={Platform.OS === "android" ? { x: 0, y: initialOffset } : undefined}
      onContentSizeChange={(_width, height) => {
        contentHeight.current = height - endSpace;
        setTall(height - endSpace > viewportHeight * 2);
        updateEdges(offset.current, height, viewportHeight);
      }}
      onScroll={(event) => {
        const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
        if (isNative()) rememberPhoneLaneOffset(board.hostId, lane.id, contentOffset.y);
        if (restoring) setRestoring(false);
        updateEdges(contentOffset.y, contentSize.height, layoutMeasurement.height);
      }}
      scrollEventThrottle={16}
      refreshing={refreshing}
      refreshControl={Platform.OS === "android" ? (
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          progressBackgroundColor={colors.surface1}
          colors={[colors.foregroundMuted]}
        />
      ) : undefined}
      onRefresh={onRefresh}
      alwaysBounceVertical
      style={covered ? { opacity: 0 } : undefined}
      viewabilityConfigCallbackPairs={seen.viewabilityConfigCallbackPairs}
      data={lane.cards}
      keyExtractor={(card) => card.id}
      extraData={extraData}
      renderItem={renderItem}
      ItemSeparatorComponent={Separator}
      contentContainerStyle={{ paddingTop: 12, paddingHorizontal: 12, paddingBottom: endSpace }}
      initialNumToRender={6}
      maxToRenderPerBatch={6}
      windowSize={7}
      onScrollToIndexFailed={({ index, averageItemLength, highestMeasuredFrameIndex }) => {
        if (scrollTimer.current !== null) clearTimeout(scrollTimer.current);
        scrollTimer.current = null;
        const retry = scrollRetry.current?.params.index === index ? scrollRetry.current : {
          params: { index, viewPosition: 0, viewOffset: 12, animated: !reduced },
          attempts: 0,
        };
        scrollRetry.current = retry;
        if (retry.attempts >= 50) return;
        retry.attempts += 1;
        // Advance the measured window before retrying variable-height cards.
        listRef.current?.scrollToOffset({ offset: averageItemLength * Math.max(0, highestMeasuredFrameIndex), animated: false });
        scrollTimer.current = setTimeout(() => {
          scrollTimer.current = null;
          listRef.current?.scrollToIndex(retry.params);
          if (scrollTimer.current === null) scrollRetry.current = null;
        }, 100);
      }}
      // Two screens ahead: on a slow phone the list mounts its rows for most of a fling, so the
      // next page is asked while there are still rows to show, not once the fling reached the end.
      onEndReachedThreshold={2}
      onEndReached={() => {
        if (!board.params.query.trim() && props.active !== false && isHistoryLane(lane.id) && lane.hasMore && !lane.loading) board.tasks.loadMoreDone();
      }}
      ListEmptyComponent={
        <BoardEmptyState
          theme={theme}
          icon={LANE_EMPTY_ICON[lane.id]}
          title={strings.laneEmpty[lane.id]}
          hint={strings.laneEmptyHint[lane.id]}
          style={{ marginTop: 36 }}
        >
          {filtered ? (
            <HoverControl base={boardPalette(theme).panel} foreground={colors.foreground}
              accessibilityRole="button"
              onPress={() => board.setParams(clearedParams)}
              style={{ marginTop: 6, height: 36, paddingHorizontal: 16, borderRadius: 18, borderWidth: HAIRLINE, borderColor: colors.border, justifyContent: "center" }}
            >
              <Text style={{ fontSize: F.base, fontWeight: "500", color: colors.foreground }}>{strings.clearFilters}</Text>
            </HoverControl>
          ) : null}
        </BoardEmptyState>
      }
      ListFooterComponent={
        <View testID="phone-lane-footer">
          {!board.params.query.trim() && isHistoryLane(lane.id) && (lane.hasMore || lane.loading) ? (
            <LoadMoreRow shown={count} sortedLoadedOnly={sortsLoadedOnly(board.params.sort)} loading={lane.loading} onPress={board.tasks.loadMoreDone} theme={theme} strings={strings} large />
          ) : null}
          <LaneFilterHint board={board} lane={lane.id} count={board.hidden[lane.id]} theme={theme} />
        </View>
      }
    />
    <NewCardsPill
      count={props.active === false ? 0 : unseen.length}
      direction={pillDirection(lane.cards, unseen, seen.firstShown())}
      inset={pillDirection(lane.cards, unseen, seen.firstShown()) === "up" ? 10 : 16}
      hue={laneHue(theme, lane.id)}
      theme={theme}
      strings={strings}
      onPress={() => {
        const index = lane.cards.findIndex((card) => card.id === unseen[0]);
        if (index < 0) return;
        cancelScroll();
        try {
          listRef.current?.scrollToIndex({ index, viewPosition: 0.5, animated: !reduced });
        } catch {
          // Not laid out yet: `onScrollToIndexFailed` gets it there.
        }
      }}
      testID={`phone-new-pill-${lane.id}`}
    />
    {scrollActions ? (
      <View testID="phone-scroll-actions" style={{ position: "absolute", right: 12, bottom: SCROLL_ACTION.bottom }}>
        {!atBottom ? <ActionPressable motion pressedScale={isNative() ? 1.1 : 1.03} testID="phone-scroll-bottom" accessibilityRole="button" accessibilityLabel={loadedEnd ? strings.scrollLoadedEnd : strings.scrollBottom} onPress={() => {
          cancelScroll();
          if (count === 0) return;
          listRef.current?.scrollToOffset({ offset: Math.max(0, contentHeight.current + endSpace - viewportHeight), animated: !reduced });
        }} style={{ width: SCROLL_ACTION.size, height: SCROLL_ACTION.size, borderRadius: SCROLL_ACTION.size / 2, borderWidth: HAIRLINE, borderColor: colors.border, backgroundColor: colors.surface0, alignItems: "center", justifyContent: "center", ...(Platform.OS === "web" ? { boxShadow: "0 3px 10px rgba(0, 0, 0, 0.2)" } : { elevation: 8, shadowColor: "#000", shadowOpacity: 0.3, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } }) }}>
          <Icon name="ArrowDownToLine" size={22} color={colors.foreground} />
        </ActionPressable> : null}
      </View>
    ) : null}
    </View>
  );
});
