import React, { useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Platform, View, Text, Pressable, StyleSheet } from "react-native";
import type { TextStyle, ViewStyle } from "react-native";
import { Glyph } from "./glyph";
import { surfaceProps } from "./view-props";
import { radiusV2, space } from "./theme-tokens";
import type { ExtendedThemeTokens } from "./theme-tokens";
import { HubCallout } from "./hub-callout";
import { PaseoToolCallout, AgentStatusView } from "./paseo-tool-callouts";
import { SubAgentView } from "./agent-operation-views";
import { AgentRowTarget, useAgentRowTarget } from "./agent-row-target";
import { permissionBorder } from "./agent-card-content";
import { SyntaxHighlightBlock, renderTerminalOutput, terminalLines } from "./syntax-highlight";
import { ToolOutput, DiffPreview } from "./tool-output";
import { ImageMeta, ImagePreview } from "./image-preview";
import { formatImageBytes } from "./image-format";
import { ImageViewer } from "./image-viewer";
import { GitHubBody } from "./github-body";
import { MarkdownView } from "./markdown/markdown-view";
import { ReasoningSections } from "./reasoning-trace";
import { isImagePath } from "../image-file";
import type { ImageFile } from "../image-file";
import { selectableSurface, unselectable } from "./selection";
import { selectionCodeText, selectionSurface } from "./selection-actions";
import { useToast } from "@getpaseo/plugin/client/ui";
import { DISCLOSURE_HEADER, DisclosureHeader, RowIcon, RowPaletteContext, RowText } from "../ui/disclosure-header";
import { STICKY_SUPPORTED, StickyCard } from "../ui/sticky-header";
import { useScrollAnchor } from "../ui/scroll-anchor";
import { PathContext, PathText } from "../ui/path-text";
import { RunningDot } from "../ui/running-dot";
import { exitMark, parseExitMeta } from "../ui/exit-mark";
import { useCopy } from "../ui/use-copy";
import { useInputCapabilities } from "../ui/use-input-capabilities";
import { AlwaysWrapPreview, HoverPreviewBody, HoverPreviewHeader } from "../ui/hover-preview";
import { ToolPager } from "../ui/tool-pager";
import { readUserQuestions } from "../tools/user-questions";
import { UserQuestions } from "./user-questions";
import { PreviewLines } from "../ui/preview-lines";
import { CommandBand, PreviewPath } from "../ui/command-band";
import { CommandFontProbe } from "../debug/font-probe";
import { FadeIn } from "../ui/fade-in";
import { SelectableSpan, SelectableText } from "../ui/prose-text";
import { formatPath } from "../paths/format-path";
import { lineRangeLabel, summarizeTool } from "../tools/summarize";
import { TYPE, UI_SCALE, blockProseBase } from "../ui/tokens/typography";
import { codeSurface } from "./host-font-escape";
import { toolCopyPlan, type ResolvePath } from "../tools/copy";
import type { CopyAction, CopyActionId, CopyPlan } from "../copy/content";
import { ToolbarButton, ToolbarCopyButton, TooltipAlignContext } from "../ui/toolbar-button";
import { readMcpName, stringifyValue, type ToolCallView, type ToolKind } from "../tools/classify";
import { summarizeToolCall, summarizeToolGroup } from "../tools/group";
import { toolHasDetail } from "../tools/detail";
import { mcpServiceIcon } from "../tools/mcp-service-icon";
import { commandIcon } from "../tools/command-icon";
import type { CopyItem } from "../details/contracts";
import { useZoomedTokens } from "../ui/text-zoom";
import { toolbarLabel } from "../i18n/toolbar-strings";
import { useHostLanguageVersion } from "../i18n/host-language";
import { useEnhancerPreferences } from "../preferences";
import { bindSelectionScopeElement, selectionScopeDataSet, SelectionTranslationContext } from "../translation/selection";

/**
 * The muted icon a settled call shows in the row's status slot: one Lucide
 * family drawn by the host (S7 design spec §2.5), except the two brand marks
 * Lucide does not carry, which stay `Glyph` bitmaps.
 */
export function toolIconName(tool: ToolKind): string {
  switch (tool) {
    case "git":
    case "worktree_setup":
      return "GitBranch";
    case "github":
      return "brand:GitHub";
    case "paseo":
      return "brand:Paseo";
    case "bash":
    case "shell":
      return "SquareTerminal";
    case "read":
      return "FileText";
    case "edit":
    case "write":
      return "Pencil";
    case "thinking":
      return "Lightbulb";
    case "mcp":
      return "Plug";
    case "sub_agent":
      return "Bot";
    case "hub":
      return "Radio";
    case "search":
      return "Search";
    case "fetch":
      return "Globe";
    case "plan":
      return "ListChecks";
    case "plain_text":
      return "MessageSquare";
    default:
      return "Wrench";
  }
}

/** The icon a settled call shows: a question's, its MCP service's or shell program's, else its kind's. */
export function toolCallIconName(call: ToolCallView): string {
  if (call.activity) return call.activity.icon;
  if (readUserQuestions(call)) return "MessageCircleQuestion";
  // An explicit MCP name identifies its service even without a typed MCP body.
  const mcp = call.mcp ?? (call.name?.startsWith("mcp__") ? readMcpName(call.name, "", undefined) : undefined);
  const shell = call.tool === "bash" || call.tool === "shell";
  return (mcp && mcpServiceIcon(mcp.server, mcp.tool))
    || (shell && call.command && commandIcon(call.command))
    || toolIconName(call.tool);
}

/** A row icon by name: the host's Lucide set, or a brand bitmap for `brand:*`. */
export { RowIcon };

/** The host's plan-card titles (`agentStream.permission.*Plan`). */
const PLAN_OUTCOME_TITLE: Record<NonNullable<ToolCallView["planOutcome"]>, string> = {
  approved: "Approved plan",
  rejected: "Rejected plan",
  canceled: "Canceled plan",
};

/** `exit 1`, `failed`: the meta entries a failure colours (S7: only these and the icon turn danger). */
const FAILURE_META = /^(exit [1-9]\d*|failed|error|timed out)$/;

/**
 * `+12 −3`: the diff counts, as success and danger spans of the meta Text,
 * quieted with the row at rest.
 */
function diffCountSpans(entry: string): React.ReactNode {
  const match = /^\+(\d+) \u2212(\d+)$/.exec(entry);
  if (!match) return entry;
  return (
    <>
      <RowText part="diffAdd">{`+${match[1]}`}</RowText>
      {" "}
      <RowText part="diffDel">{`−${match[2]}`}</RowText>
    </>
  );
}

interface ToolCalloutProps {
  data: ToolCallView;
  /** The call's name across remounts (its disclosure key), for its preview. */
  previewKey?: string;
  /** Consecutive calls sharing this file-operation header, in timeline order. */
  groupCalls?: readonly ToolCallView[];
  tokens: ExtendedThemeTokens;
  /** `layout.compact`: 28px header and shorter truncation budgets. */
  compact?: boolean;
  /** Uncontrolled start state. The live renderer passes `expanded` instead. */
  defaultExpanded?: boolean;
  /** Controlled open state (the disclosure store's value). */
  expanded?: boolean;
  onExpandedChange?(expanded: boolean): void;
  /** Shows an absolute path in the machine's own file manager. */
  onRevealPath?: (path: string) => void;
  /**
   * The image this call read, when it read one. `undefined` keeps the code
   * block, so a harness with no daemon still renders the card; `null` means
   * the read is in flight.
   */
  imageFile?: ImageFile | null;
  /**
   * Asks for the image: the row's preview opened, or a long press on a phone
   * wants the viewer. The live renderer reads an image only for an open card
   * or after this, so this is where a collapsed read asks for it.
   */
  requestImage?(): void;
}

/**
 * One tool call (plan §3.3, BC-01).
 *
 * Collapsed it is a bare single row — `[status] Verb target … meta ›` — with
 * no frame and no fill, so consecutive calls read as a compact list. Expanded
 * it gains a 1px border on `surface0` and the body below a subtle divider.
 * The body is mounted only while expanded. The only looping animation is the
 * `RunningDot`, and only while the call runs.
 *
 * A failure adds one danger-coloured line under the header with the first
 * line of the error, so it can be read without opening the card.
 */
export function ToolCallout({
  data,
  previewKey,
  groupCalls,
  tokens,
  compact = false,
  defaultExpanded = false,
  expanded: controlledExpanded,
  onExpandedChange,
  onRevealPath,
  imageFile,
  requestImage,
}: ToolCalloutProps) {
  const selectionScope = useContext(SelectionTranslationContext);
  const scopeData = Platform.OS === "web" ? selectionScopeDataSet(selectionScope) : null;
  const bindSelectionScope = useCallback((node: View | Text | null) => {
    if (!node || !selectionScope) return;
    bindSelectionScopeElement(node, selectionScope);
    return () => bindSelectionScopeElement(node, null);
  }, [selectionScope]);
  const [localExpanded, setLocalExpanded] = useState(defaultExpanded);
  // A body that would only repeat the row is never shown, whatever the store says.
  const budget = compact ? DISCLOSURE_HEADER.targetBudget.compact : DISCLOSURE_HEADER.targetBudget.desktop;
  const hasDetail = useMemo(
    () => (groupCalls ?? [data]).some((call) => toolHasDetail(call, budget)),
    [data, groupCalls, budget],
  );
  const expanded = hasDetail && (controlledExpanded ?? localExpanded);
  const setExpanded = onExpandedChange ?? setLocalExpanded;
  const onToggle = useCallback(() => setExpanded(!expanded), [setExpanded, expanded]);
  // Owned here, not by the row: an opened card moves the row into `StickyCard`.
  const scrollAnchor = useScrollAnchor(expanded);

  const summary = useMemo(() => groupCalls ? summarizeToolGroup(groupCalls) : summarizeTool(data), [data, groupCalls]);
  const { language } = useEnhancerPreferences();
  useHostLanguageVersion();
  const compaction = data.name === "compaction" && data.tool === "activity";
  const verb = summary.agent || data.tool === "activity" ? toolbarLabel(summary.verb, language) : summary.verb;
  const summaryMeta = compaction ? summary.meta.map((entry) => toolbarLabel(entry, language)) : summary.meta;
  const iconName = useMemo(() => toolCallIconName(data), [data]);
  const agentTarget = useAgentRowTarget(summary);
  const pathContext = useContext(PathContext);
  const capabilities = useInputCapabilities(compact);
  const touchFirst = capabilities.touch && !capabilities.hover;
  const { copy } = useCopy();

  const resolvePath = useCallback(
    (path: string) => formatPath(path, pathContext).absolutePath,
    [pathContext],
  );
  // Built on demand: a running shell's output is stripped of ANSI only when
  // someone actually copies it, not on every chunk.
  const onLongPress = useCallback(() => {
    const primary = toolCopyPlan(data, resolvePath).primary;
    if (primary) void copy(primary.text, { feedback: "toast", label: primary.label });
  }, [data, resolvePath, copy]);

  const running = groupCalls ? groupCalls.some((call) => call.status === "running") : data.status === "running";
  const failed = (data.status === "failed" && !data.rejected) || summary.tone === "danger";
  // An agent row colours its icon, verb and meta together (agent cards design 5.5).
  const agentTone = summary.agent ? summary.tone === "danger" ? tokens.danger : summary.tone === "warning" ? tokens.warning :
    summary.agent.iconTone === "success" ? tokens.success : undefined : undefined;
  const agentStateColor = summary.agent && summary.tone !== "default" ? agentTone : undefined;
  // A finished call steps behind the prose.
  const tone = running ? "active" : "quiet";
  // On a phone a created agent's row shows its harness as the grey mark, not as words.
  const provider = compact ? summary.agent?.provider : undefined;
  const statusIcon = running ? (
    <RunningDot color={tokens.accent} />
  ) : (
    <RowIcon name={provider ? `provider:${provider}` : summary.agent?.icon ?? iconName}
      color={agentTone ?? (failed ? tokens.danger : summary.iconTone === "success" ? tokens.success : undefined)} />
  );

  const target =
    summary.agent ? (
      <AgentRowTarget summary={summary} tokens={tokens} />
    ) : summary.targetIsPath && summary.target ? (
      <PathText
        path={summary.target}
        tokens={tokens}
        compact={compact}
        copyOnHover={false}
        fit={!groupCalls}
        grow={!groupCalls}
        style={{
          fontSize: tokens.typography.block.target.size,
          lineHeight: tokens.typography.block.target.lineHeight,
        }}
      />
    ) : (
      summary.target
    );
  const meta = (provider ? [] : summaryMeta).map((entry) => {
    const exitCode = parseExitMeta(entry);
    const shown = exitCode === undefined ? diffCountSpans(entry) : exitMark(exitCode);
    if (agentStateColor) return <Text style={{ color: agentStateColor }}>{entry}</Text>;
    return failed && FAILURE_META.test(entry) ? <Text style={{ color: tokens.danger }}>{shown}</Text> : shown;
  });
  const metaLead = summary.metaPath ? (
    <MetaPath path={summary.metaPath} tokens={tokens} compact={compact} />
  ) : undefined;

  // Mounted only while the row shows its actions, so the plan is built then.
  const actions = <ToolCopyButtons call={data} resolvePath={resolvePath} tokens={tokens} />;

  // A read of an image is drawn as the picture, which has no lines to wrap.
  const drawsImage =
    (data.tool === "read" || data.tool === "write") && imageFile !== undefined && isImagePath(data.filePath);

  // A path in the body reveals the file on a pointer device; on touch it
  // copies, because `file.reveal` would open a window on the daemon's machine.
  const filePath = data.filePath;
  const reveal = onRevealPath ?? pathContext.reveal;
  const revealFile = useMemo(() => {
    if (!filePath) return undefined;
    const absolutePath = resolvePath(filePath);
    if (touchFirst) return () => void copy(absolutePath, { feedback: "toast", label: "Copy path" });
    return reveal ? () => reveal(absolutePath) : undefined;
  }, [filePath, resolvePath, touchFirst, copy, reveal]);
  const displayPath = filePath ? formatPath(filePath, pathContext).displayPath : undefined;

  // On a phone a long press on an image read opens the picture in the viewer,
  // as a press on the picture does, rather than a preview of the card. The
  // bytes may not be read yet; the viewer opens once they arrive.
  const viewsImage = drawsImage && capabilities.native;
  const [viewerWanted, setViewerWanted] = useState(false);
  const toast = useToast();
  const openViewer = useCallback(() => {
    requestImage?.();
    setViewerWanted(true);
  }, [requestImage]);
  const closeViewer = useCallback(() => setViewerWanted(false), []);
  const unreadable = viewerWanted && imageFile ? imageFile.dataUri === null : false;
  useEffect(() => {
    if (!unreadable) return;
    setViewerWanted(false);
    toast.error(imageFile?.error ?? "The image could not be read.");
  }, [unreadable, imageFile, toast]);
  const viewer = viewerWanted && imageFile?.dataUri ? (
    <ImageViewer
      open={viewerWanted}
      onClose={closeViewer}
      uri={imageFile.dataUri}
      width={imageFile.width}
      height={imageFile.height}
      label={filePath ?? ""}
      tokens={tokens}
      path={filePath ? resolvePath(filePath) : undefined}
      onReveal={revealFile}
    />
  ) : null;

  // No frame (S7 design spec §3.1): the row, then — only when there is one —
  // the error line, the copy menu and the opened body as its siblings. A
  // collapsed call is the row alone, and the row keeps its place in the tree
  // when the body opens, so hover and press state survive the toggle.
  const header = (
    <DisclosureHeader
      expanded={expanded}
      onToggle={onToggle}
      scrollAnchor={scrollAnchor}
      tokens={tokens}
      compact={compact}
      tone={tone}
      inert={!hasDetail}
      icon={statusIcon}
      iconIsStatus={running || failed}
      verb={verb}
      keepVerb={Boolean(summary.agent)}
      verbColor={agentStateColor}
      metaFont={summary.agent ? "ui" : "mono"}
      target={target}
      targetTruncation={!groupCalls && readUserQuestions(data) ? "tail" : "middle"}
      count={groupCalls?.length}
      meta={meta}
      metaLead={metaLead}
      actions={actions}
      onLongPress={viewsImage ? openViewer : capabilities.touch ? onLongPress : undefined}
      accessibilityLabel={[verb, summary.target, ...summaryMeta].filter(Boolean).join(" ")}
      onPreviewOpen={requestImage}
      previewWraps={!drawsImage}
      pressPreview={!viewsImage}
      previewKey={previewKey}
      detailsTitle={{ text: summary.agent ? [verb, agentTarget.text].filter(Boolean).join(" · ")
        : groupCalls ? [summary.verb, summary.target].filter(Boolean).join(" ")
        : data.shell?.command || data.command || (summary.targetIsPath ? data.filePath : undefined) || summary.target || verb,
        mono: !summary.agent && Boolean(summary.targetIsPath || data.command || data.shell?.command) }}
      detailsSubtitle={drawsImage ? imageMenuSubtitle(imageFile, filePath) : [data.status, ...summaryMeta]}
      detailsTone={running ? "accent" : failed ? "danger" : summary.tone === "warning" ? "warning" : "muted"}
      detailsIcon={summary.agent?.icon ?? iconName}
      copyItems={() => toolRowCopyItems(data, resolvePath)}
      readsImage={drawsImage}
      onViewImage={openViewer}
      previewContent={() => (
        groupCalls ? (
          <GroupedPreview calls={groupCalls} resolvePath={resolvePath} tokens={tokens} compact={compact} imageFile={imageFile}
            path={filePath ? resolvePath(filePath) : undefined} revealFile={revealFile} displayPath={displayPath} onViewImage={openViewer} />
        ) : (
          <ToolPreviewContent key={data.callId ?? data.id} data={data} resolvePath={resolvePath} tokens={tokens} compact={compact}
            imageFile={imageFile} drawsImage={drawsImage} revealFile={revealFile} displayPath={displayPath}
            onViewImage={openViewer} />
        )
      )}
    />
  );
  const body = expanded ? (
    <FadeIn style={[styles.body, { backgroundColor: tokens.row.outputBg },
      summary.tone === "warning" && { borderWidth: 1, borderColor: permissionBorder(tokens) }]}>
      <View ref={scopeData ? bindSelectionScope : undefined}
        {...(scopeData ? surfaceProps(selectionSurface, { dataSet: scopeData } as never) : selectionSurface)} style={styles.bodyInner}>
        {groupCalls ? (
          <GroupedToolDetails calls={groupCalls} tokens={tokens} compact={compact} imageFile={imageFile}
            revealFile={revealFile} displayPath={displayPath} />
        ) : (
          <ToolBody
            data={data}
            tokens={tokens}
            compact={compact}
            imageFile={imageFile}
            revealFile={revealFile}
            displayPath={displayPath}
          />
        )}
        {!groupCalls && data.error && !drawsOwnError(data) ? <CallError text={data.error} tokens={tokens} quiet={data.rejected} /> : null}
      </View>
    </FadeIn>
  ) : null;

  // An opened card on a host with the sticky header API pins its row while it
  // scrolls past (S6). Collapsed rows never reach the hook.
  if (expanded && STICKY_SUPPORTED) {
    return (
      <StickyCard tokens={tokens} compact={compact} header={header}>
        {viewer}
        {body}
      </StickyCard>
    );
  }

  return (
    <>
      {header}
      {viewer}
      {summary.errorLine && !expanded ? (
        <Text
          ref={scopeData ? bindSelectionScope : undefined}
          {...(surfaceProps(selectionSurface, codeSurface, ...(scopeData ? [{ dataSet: scopeData } as never] : [])) as object)}
          selectable
          numberOfLines={1}
          style={[
            styles.errorLine,
            {
              color: tokens.row.meta,
              fontFamily: tokens.fontMono,
              fontSize: tokens.typography.block.meta.size,
              lineHeight: tokens.typography.block.target.lineHeight,
            },
          ]}
        >
          {summary.errorLine}
        </Text>
      ) : null}
      {body}
    </>
  );
}

/**
 * The page of a merged row on view: one call at a time, in timeline order.
 * It stays in range when the run shrinks.
 */
function useGroupPage(count: number): [number, (index: number) => void] {
  const [index, setIndex] = useState(0);
  return [Math.min(index, count - 1), setIndex];
}

interface GroupedBodyProps {
  calls: readonly ToolCallView[];
  tokens: ExtendedThemeTokens;
  compact: boolean;
  imageFile?: ImageFile | null;
  revealFile?: () => void;
  displayPath?: string;
}

/** An opened merged row: the pager, then the body of the call on view. */
function GroupedToolDetails({ calls, ...rest }: GroupedBodyProps) {
  const [index, setIndex] = useGroupPage(calls.length);
  return (
    <>
      {/* At the body's left edge: names open rightwards. */}
      <TooltipAlignContext.Provider value="start">
        <ToolPager index={index} count={calls.length} onChange={setIndex} tokens={rest.tokens} />
      </TooltipAlignContext.Provider>
      <GroupedCallBody key={calls[index]!.callId} call={calls[index]!} {...rest} />
    </>
  );
}

/** Agent cards put a failure's first line under their identity strip. */
function drawsOwnError(data: ToolCallView): boolean {
  return Boolean(data.paseo?.createAgent || data.paseo?.sendAgentPrompt || data.paseo?.agentOperation || data.paseo?.catalog);
}

function isMarkdownWrite(data: ToolCallView): boolean {
  return data.tool === "write" && data.language === "markdown" && Boolean(data.code) && !data.diff;
}

/**
 * What a single call's preview panel holds: the toolbar, then the path, the
 * body and the error. Also drawn outside a panel's layer by the settings page
 * (`PreviewPanelSample`), so a reader sees the panel options take effect.
 */
export function ToolPreviewContent({ data, resolvePath, drawsImage = false, pager, ...rest }: Omit<ToolBodyProps, "preview"> & {
  resolvePath: ResolvePath;
  drawsImage?: boolean;
  pager?: React.ReactNode;
}) {
  const { tokens, imageFile } = rest;
  const [raw, setRaw] = useState(false);
  const createAgent = data.tool === "paseo" && data.paseo?.tool === "create_agent" && Boolean(data.paseo.createAgent);
  const agentTool = createAgent || Boolean(data.paseo?.sendAgentPrompt || data.paseo?.agentOperation || data.paseo?.catalog);
  const subAgent = data.tool === "sub_agent" && Boolean(data.subAgent);
  const markdown = isMarkdownWrite(data) || agentTool || subAgent || Boolean(data.agentStatus);
  const streaming = data.status === "running";
  const questions = useMemo(() => readUserQuestions(data), [data]);
  if (questions) {
    return <UserQuestions key={data.callId ?? data.id} questions={questions} tokens={tokens}
      rawBody={<ToolBody data={data} {...rest} preview raw />}
      renderHeader={(controls) => <ToolPreviewActions call={data} resolvePath={resolvePath} tokens={tokens}
        title={data.name ?? "Questions"} streaming={streaming} pager={controls} fitControls />}>
      {data.error ? <PreviewError text={data.error} tokens={tokens} /> : null}
    </UserQuestions>;
  }
  const content = (
    <>
      <ToolPreviewActions call={data} resolvePath={resolvePath} tokens={tokens} streaming={streaming} fitControls={agentTool || subAgent || Boolean(data.agentStatus)}
        pager={<>{pager}{markdown ? <ToolbarButton icon={raw ? "FileText" : "Code"}
          label={raw ? "Render Markdown" : "Show raw text"} onPress={() => setRaw((value) => !value)} tokens={tokens} /> : null}</>}
        meta={drawsImage ? <ImageMeta file={imageFile ?? null} tokens={tokens} /> : undefined} />
      <HoverPreviewBody key={markdown && !raw ? "markdown" : "raw"} streaming={streaming}>
        {data.filePath ? <PreviewPath path={resolvePath(data.filePath)} tokens={tokens} /> : null}
        {data.agentStatus ? <AgentStatusView data={data.agentStatus} tokens={tokens} raw={raw} compact={rest.compact} /> :
          subAgent ? <SubAgentView data={data} tokens={tokens} raw={raw} compact={rest.compact} /> :
          agentTool ? <PaseoToolCallout data={data.paseo!} tokens={tokens} raw={raw} compact={rest.compact} error={data.error} /> :
          markdown && !raw ? <MarkdownView text={data.code!} tokens={tokens} variant="document"
          streaming={streaming} size={blockProseBase(tokens.typography)} /> : <ToolBody data={data} {...rest} preview />}
        {data.error && !drawsOwnError(data) ? <PreviewError text={data.error} tokens={tokens} quiet={data.rejected} /> : null}
      </HoverPreviewBody>
    </>
  );
  return markdown && !raw ? <AlwaysWrapPreview keepControl>{content}</AlwaysWrapPreview> : content;
}

/** A merged row's preview: the pager sits in the panel's toolbar, so it stays put while the body scrolls. */
function GroupedPreview({ calls, resolvePath, path, onViewImage, ...rest }: GroupedBodyProps & {
  resolvePath: ResolvePath;
  path?: string;
  onViewImage(): void;
}) {
  const [index, setIndex] = useGroupPage(calls.length);
  const { tokens, imageFile } = rest;
  const call = calls[index]!;
  const streaming = call.status === "running";
  const drawsImage = (call.tool === "read" || call.tool === "write") && imageFile !== undefined && isImagePath(call.filePath);
  if (isMarkdownWrite(call)) {
    return <ToolPreviewContent key={call.callId ?? call.id} data={call} resolvePath={resolvePath} {...rest}
      onViewImage={onViewImage}
      pager={<ToolPager index={index} count={calls.length} onChange={setIndex} tokens={tokens} />} />;
  }
  return (
    <>
      <ToolPreviewActions call={call} resolvePath={resolvePath} tokens={tokens} streaming={streaming}
        pager={<ToolPager index={index} count={calls.length} onChange={setIndex} tokens={tokens} />}
        meta={drawsImage ? <ImageMeta file={imageFile ?? null} tokens={tokens} /> : undefined} />
      <HoverPreviewBody streaming={streaming}>
        {path ? <PreviewPath path={path} tokens={tokens} /> : null}
        <GroupedCallBody key={calls[index]!.callId} call={calls[index]!} {...rest} preview onViewImage={onViewImage} />
      </HoverPreviewBody>
    </>
  );
}

/** Keyed by call at the call site, so a page's own state (folded lines) does not carry over to the next. */
function GroupedCallBody({ call, preview, onViewImage, ...rest }: Omit<GroupedBodyProps, "calls"> & {
  call: ToolCallView;
  preview?: boolean;
  onViewImage?: () => void;
}) {
  const errorLine = summarizeToolCall(call).errorLine;
  return (
    <>
      <ToolBody data={call} {...rest} preview={preview} onViewImage={onViewImage} />
      {errorLine ? preview ? <PreviewError text={call.error ?? errorLine} tokens={rest.tokens} /> :
        <CallError text={call.error ?? errorLine} tokens={rest.tokens} /> : null}
    </>
  );
}

/** Each copy a toolbar offers has its own icon, so two copies side by side are told apart. */
const COPY_ICON: Record<CopyActionId, string> = {
  path: "Link",
  url: "Link",
  command: "SquareTerminal",
  "command-output": "ClipboardCopy",
  query: "Search",
  summary: "MessageSquareText",
  files: "List",
  patch: "FileDiff",
  args: "Braces",
  code: "Code",
  log: "ScrollText",
  description: "MessageSquareText",
  prompt: "FileText",
  // File and text bodies use Copy; command output has its own document icon.
  content: "Copy",
  "new-content": "Copy",
  output: "FileOutput",
  result: "Copy",
  text: "Copy",
};

/**
 * A call's copies as one row of buttons: the header's own object first, then
 * the rest of the plan. An entry with the same id or text as an earlier one
 * is dropped, so no two buttons copy the same thing.
 */
export function previewCopyActions(plan: CopyPlan): CopyAction[] {
  const seen = new Set<string>();
  return [plan.primary, ...plan.menu].filter((action): action is CopyAction => {
    if (!action || seen.has(action.id) || seen.has(`text:${action.text}`)) return false;
    seen.add(action.id);
    seen.add(`text:${action.text}`);
    return true;
  });
}

/** The row menu uses the preview's copy order, including Paseo's prompt-only card. */
export function toolRowCopyItems(call: ToolCallView, resolvePath: ResolvePath): CopyItem[] {
  const plan = toolCopyPlan(call, resolvePath);
  const prompt = call.paseo?.sendAgentPrompt?.prompt;
  const create = call.tool === "paseo" ? call.paseo?.createAgent : undefined;
  const actions: CopyAction[] = prompt
    ? [{ id: "prompt", label: "Copy prompt", text: prompt }, ...previewCopyActions(plan)]
    : create ? [{ id: "prompt", label: "Copy prompt", text: create.initialPrompt }]
    : previewCopyActions(plan);
  const seen = new Set<string>();
  return actions.filter((action) => {
    if (!action.text || seen.has(action.text)) return false;
    seen.add(action.text);
    return true;
  }).map((action) => ({ ...action, icon: COPY_ICON[action.id] }));
}

function imageMenuSubtitle(file: ImageFile | null | undefined, path: string | undefined): string[] {
  const parts: string[] = [];
  if (file?.width && file.height) parts.push(`${file.width} × ${file.height}`);
  const format = path?.split(".").pop()?.toUpperCase();
  if (format) parts.push(format);
  if (file?.bytes != null) parts.push(formatImageBytes(file.bytes));
  return parts;
}

/**
 * Every copy of a call as a row of buttons, the same on the row's header and
 * in its preview's toolbar. A merged row's header offers its first call's,
 * as its preview opens on that call.
 */
function ToolCopyButtons({ call, resolvePath, tokens }: {
  call: ToolCallView;
  resolvePath: ResolvePath;
  tokens: ExtendedThemeTokens;
}) {
  const actions = useMemo(() => previewCopyActions(toolCopyPlan(call, resolvePath)), [call, resolvePath]);
  return (
    <>
      {actions.map((action) => (
        <ToolbarCopyButton key={action.id} text={action.text} icon={COPY_ICON[action.id]} label={action.label} tokens={tokens} />
      ))}
    </>
  );
}

/**
 * The preview's toolbar: a merged row's pager at the left, the tool's icon
 * and name or picture size in the middle, and copies at the right.
 */
function ToolPreviewActions({ call, resolvePath, tokens, title, pager, meta, streaming = false, fitControls = false }: {
  call: ToolCallView;
  resolvePath: ResolvePath;
  tokens: ExtendedThemeTokens;
  /** Question text belongs in the body, so question previews use the tool name. */
  title?: string;
  /** A merged row's pager, after the line-wrap button at the left. */
  pager?: React.ReactNode;
  /** A picture's size and weight, centred in the toolbar. */
  meta?: React.ReactNode;
  /** The call on view is still writing. */
  streaming?: boolean;
  fitControls?: boolean;
}) {
  const summary = useMemo(() => summarizeTool(call), [call]);
  const { language } = useEnhancerPreferences();
  useHostLanguageVersion();
  const agentTarget = useAgentRowTarget(summary);
  const agent = summary.agent;
  // An agent card's preview is named in words: "Finished - tasks B" (design 3).
  const agentLabel = agent ? [toolbarLabel(summary.verb, language), agentTarget.text].filter(Boolean).join(" · ") : undefined;
  const agentColor = agent ? summary.tone === "danger" ? tokens.danger : summary.tone === "warning" ? tokens.warning :
    agent.iconTone === "success" ? tokens.success : tokens.foregroundMuted : undefined;
  return (
    <HoverPreviewHeader tokens={tokens} streaming={streaming} icon={meta ? "Image" : <RowIcon
      name={agent?.icon ?? toolCallIconName(call)} color={agentColor ?? tokens.foregroundMuted} />}
      iconLabel={title ?? agentLabel ?? (call.tool === "activity" ? toolbarLabel(summary.verb, language) : summary.verb)}
      left={pager} center={meta} fitControls={fitControls}>
      <View style={styles.previewActions}>
        {call.paseo?.sendAgentPrompt ? <>
          <ToolbarCopyButton text={call.paseo.sendAgentPrompt.prompt} label="Copy prompt" tokens={tokens} />
          <ToolCopyButtons call={call} resolvePath={resolvePath} tokens={tokens} />
        </> : call.tool === "paseo" && call.paseo?.createAgent ?
          <ToolbarCopyButton text={call.paseo.createAgent.initialPrompt} label="Copy prompt" tokens={tokens} /> :
          <ToolCopyButtons call={call} resolvePath={resolvePath} tokens={tokens} />}
      </View>
    </HoverPreviewHeader>
  );
}

/** A path among the header's meta (a shell's cwd, a worktree's directory).
 * Shown only for a directory inside a known root: the root itself says
 * nothing, and an absolute path outside every root would crowd out the
 * command on a phone-width row.
 */
function MetaPath({
  path,
  tokens,
  compact,
}: {
  path: string;
  tokens: ExtendedThemeTokens;
  compact: boolean;
}) {
  const context = useContext(PathContext);
  const palette = useContext(RowPaletteContext);
  const formatted = useMemo(() => formatPath(path, context), [path, context]);
  if (!formatted.projectRoot || formatted.displayPath === "./" || formatted.displayPath === ".") {
    return null;
  }
  return (
    <PathText
      path={path}
      tokens={tokens}
      compact={compact}
      copyOnHover={false}
      budget={compact ? 20 : 32}
      style={{ fontSize: tokens.typography.block.meta.size, color: palette?.meta ?? tokens.foregroundMuted }}
    />
  );
}

const styles = StyleSheet.create({
  previewActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    gap: space.xs,
  },
  // The first line of a failure, under the verb (the row's text column).
  errorLine: {
    fontSize: TYPE.caption.size,
    lineHeight: 18,
    paddingLeft: DISCLOSURE_HEADER.textColumn,
    marginTop: -2,
    paddingBottom: 2,
    ...selectableSurface,
  },
  // An opened call: one surface1 slab under the row, full width, no frame.
  // Nothing clips it: the padding keeps its content off the rounded corners,
  // and a path's hover tooltip has to rise out over the row above.
  body: {
    marginTop: 2,
    marginBottom: 6,
    borderRadius: radiusV2.block,
  },
  bodyInner: {
    paddingVertical: space.sm,
    paddingHorizontal: space.md,
    gap: space.sm,
    ...selectableSurface,
  },
});

/* ------------------------------------------------------------------ bodies */

interface ToolBodyProps {
  data: ToolCallView;
  tokens: ExtendedThemeTokens;
  compact: boolean;
  imageFile?: ImageFile | null;
  revealFile?: () => void;
  /** `filePath` relative to the workspace. */
  displayPath?: string;
  preview?: boolean;
  /** Keeps the existing tool body for the raw-data view. */
  raw?: boolean;
  /** Opens the full-screen viewer for an image drawn in a preview panel. */
  onViewImage?: () => void;
}

/** Search results beyond this many rows collapse into a count. */
const MAX_FILE_ROWS = 50;

/**
 * The expanded body: the details the card always had — arguments, content
 * and logs, nothing trimmed — without the nested frames and shadows.
 */
/**
 * The path in a read, write or edit code header (plan §3.9 item 5): a
 * `PathText` (relative, middle-truncated, press to reveal or copy on touch)
 * and, for a read of part of a file, its line window as a muted suffix.
 */
function CodeHeaderPath({
  path,
  suffix,
  tokens,
  compact,
  onReveal,
}: {
  path: string;
  suffix?: string;
  tokens: ExtendedThemeTokens;
  compact: boolean;
  onReveal?: () => void;
}) {
  return (
    <View style={codeHeaderStyles.row}>
      <PathText
        path={path}
        tokens={tokens}
        compact={compact}
        onReveal={onReveal ? () => onReveal() : undefined}
        style={{ fontSize: tokens.typography.block.meta.size }}
      />
      {suffix ? (
        <Text
          {...(codeSurface as object)}
          selectable={false}
          style={[
            codeHeaderStyles.suffix,
            unselectable,
            {
              color: tokens.foregroundMuted,
              fontFamily: tokens.fontMono,
              fontSize: tokens.typography.block.meta.size,
            },
          ]}
        >
          {suffix}
        </Text>
      ) : null}
    </View>
  );
}

const codeHeaderStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: space.xs, flexShrink: 1, minWidth: 0 },
  suffix: { fontSize: UI_SCALE.base, fontVariant: ["tabular-nums"], flexShrink: 0 },
});

/** A file or diff in a preview, line by line as the file has it. */
function PreviewFile({ text, ...rest }: Omit<React.ComponentProps<typeof PreviewLines>, "lines">) {
  const lines = useMemo(() => text.replace(/\n+$/, "").split("\n"), [text]);
  return <PreviewLines text={text} lines={lines} {...rest} />;
}

function useErrorStyle(tokens: ExtendedThemeTokens, quiet = false): TextStyle {
  return useMemo<TextStyle>(() => ({
    fontFamily: tokens.fontMono,
    fontSize: tokens.typography.mono.size,
    lineHeight: tokens.typography.mono.lineHeight,
    color: quiet ? tokens.foregroundMuted : tokens.danger,
  }), [tokens, quiet]);
}

/** A call's error in an opened card, set as its output is, in the danger colour; a rejection is muted. */
function CallError({ text, tokens, quiet }: { text: string; tokens: ExtendedThemeTokens; quiet?: boolean }) {
  return <SelectableText {...selectionCodeText} style={useErrorStyle(useZoomedTokens(tokens), quiet)}>{text}</SelectableText>;
}

/** A call's error in a preview: line by line as its output is, all in the danger colour; a rejection is muted. */
function PreviewError({ text, tokens, quiet }: { text: string; tokens: ExtendedThemeTokens; quiet?: boolean }) {
  const style = useErrorStyle(tokens, quiet);
  const lines = useMemo(() => terminalLines(text), [text]);
  return <PreviewLines text={text} lines={lines} style={style} tokens={tokens} />;
}

function ToolBody({ data, tokens: given, compact, imageFile, revealFile, displayPath, preview = false, raw = false, onViewImage }: ToolBodyProps) {
  // In the phone drawer, its pinch zoom: the styles and every child below read these.
  const tokens = useZoomedTokens(given);
  const styles = useBodyStyles(tokens, compact);
  const isRunning = data.status === "running";
  const questions = useMemo(() => raw ? undefined : readUserQuestions(data), [data, raw]);
  if (data.tool === "sub_agent" && data.subAgent) return <SubAgentView data={data} tokens={tokens} compact={compact} raw={raw} />;
  if (data.agentStatus) return <AgentStatusView data={data.agentStatus} tokens={tokens} compact={compact} raw={raw} />;
  if (questions) {
    return <UserQuestions key={data.callId ?? data.id} questions={questions} tokens={tokens}
      rawBody={<ToolBody data={data} tokens={tokens} compact={compact} preview={preview} raw />} />;
  }
  if (raw && data.questionData) {
    return <SyntaxHighlightBlock code={stringifyValue(data.questionData) ?? ""} language="json" tokens={tokens} compact bare />;
  }

  // Every branch below needs a payload. A tool that carries none — a hub op
  // with no parsed record — would otherwise draw an empty panel, so the raw
  // output takes over.
  const hasTypedBody =
    data.tool === "bash" ||
    data.tool === "shell" ||
    data.tool === "git" ||
    data.tool === "github" ||
    data.tool === "thinking" ||
    data.tool === "read" ||
    data.tool === "write" ||
    data.tool === "edit" ||
    data.tool === "search" ||
    data.tool === "fetch" ||
    data.tool === "worktree_setup" ||
    data.tool === "sub_agent" ||
    data.tool === "plan" ||
    data.tool === "plain_text" ||
    data.tool === "unknown" ||
    (data.tool === "activity" && Boolean(data.activity)) ||
    (data.tool === "mcp" && Boolean(data.mcp)) ||
    (data.tool === "hub" && Boolean(data.hub)) ||
    (data.tool === "paseo" && Boolean(data.paseo));

  // Only a real shell call can "complete without output". A git op that
  // prints nothing is not a silent command, so it does not inherit the
  // shell sentence.
  const isShellCall = data.tool === "bash" || data.tool === "shell";
  const command = data.shell?.command || data.command;

  // A hover preview must expose the whole file without another disclosure.
  // The regular code block deliberately batches and folds long files.
  if (preview && (data.tool === "read" || data.tool === "write" || data.tool === "edit") &&
      !(imageFile !== undefined && isImagePath(data.filePath))) {
    const content = data.diff || data.code;
    if (!content) {
      return <SelectableText {...selectionCodeText} style={styles.commandLine}>
        {isRunning ? "Waiting for content…" : "No content."}
      </SelectableText>;
    }
    if (data.diff) return <DiffPreview text={content} filename={displayPath} style={styles.commandLine} tokens={tokens}
      numbered={!data.diffFromText} running={isRunning} />;
    return <PreviewFile text={content} diff={Boolean(data.diff)} numbered={!data.diffFromText}
      firstLine={data.tool === "read" && data.offset !== undefined && data.offset > 0 ? Math.floor(data.offset) : 1}
      style={styles.commandLine} tokens={tokens} />;
  }

  return (
    <>
      {(data.tool === "bash" || data.tool === "shell" || data.tool === "git") && (
        <View style={styles.terminalWindow}>
          {command ? (
            // One line on the code surface, not a nested code card: its own
            // band, ruled at the left, apart from the output.
            <CommandBand tokens={tokens} style={styles.commandBand}>
              <SelectableText {...selectionCodeText} style={[styles.commandLine, styles.clear]}>
                <SelectableSpan style={styles.promptColor}>{"$ "}</SelectableSpan>
                {command}
              </SelectableText>
              <CommandFontProbe tokens={tokens} style={[styles.commandLine, styles.clear]} />
            </CommandBand>
          ) : null}
          {data.shell?.stdout ? (
            <ToolOutput text={data.shell.stdout} style={styles.terminalOutput} tokens={tokens} preview={preview} running={isRunning} />
          ) : null}
          {data.shell?.stderr ? (
            preview ? <PreviewError text={data.shell.stderr} tokens={tokens} /> :
            <SelectableText {...(codeSurface as object)} style={[styles.terminalOutput, { color: tokens.danger }]}>
              {data.shell.stderr}
            </SelectableText>
          ) : null}
          {data.output && !data.shell?.stdout ? (
            <ToolOutput text={data.output} style={styles.terminalOutput} tokens={tokens} preview={preview} running={isRunning} />
          ) : null}
          {/* A failed call's error follows the body; it is not "no output". */}
          {!data.shell?.stdout && !data.shell?.stderr && !data.output && !(data.error && !isRunning) ? (
            <SelectableText style={styles.silentText}>
              {isRunning
                ? "Waiting for command output…"
                : isShellCall
                  ? "Command completed without output."
                  : "The call returned no output."}
            </SelectableText>
          ) : null}
        </View>
      )}

      {data.tool === "github" && <GitHubBody data={data.github} tokens={tokens} running={isRunning} />}

      {data.tool === "thinking" && (
        preview ? <MarkdownView text={data.thinking?.text || data.code || data.output || ""} tokens={tokens} variant="compact" quiet streaming={isRunning} size={blockProseBase(tokens.typography)} /> :
        <ReasoningSections
          text={data.thinking?.text || data.code || data.output || ""}
          tokens={tokens}
          storeKey={`tool-thinking:${data.callId ?? data.id}`}
          streaming={isRunning}
          compact={compact}
        />
      )}

      {data.tool === "mcp" && data.mcp && (
        <View style={styles.section}>
          {data.mcp.transport ? <Text style={styles.sectionTitle}>{data.mcp.transport}</Text> : null}
          <Text style={styles.sectionTitle}>Input parameters</Text>
          <SyntaxHighlightBlock
            bare
            code={JSON.stringify(data.mcp.arguments, null, 2)}
            language="json"
            tokens={tokens}
            compact
          />
          {data.mcp.result !== undefined && (
            <>
              <Text style={styles.sectionTitle}>Response</Text>
              <SyntaxHighlightBlock
            bare
                code={
                  typeof data.mcp.result === "string"
                    ? data.mcp.result
                    : JSON.stringify(data.mcp.result, null, 2)
                }
                language={typeof data.mcp.result === "string" ? "typescript" : "json"}
                tokens={tokens}
                compact
              />
            </>
          )}
          {data.mcp.error ? (
            <SelectableText style={[styles.plainText, { color: tokens.danger }]}>
              Error: {data.mcp.error}
            </SelectableText>
          ) : null}
        </View>
      )}

      {(data.tool === "read" || data.tool === "write") &&
        (imageFile !== undefined && isImagePath(data.filePath) ? (
          <ImagePreview path={data.filePath ?? ""} file={imageFile} tokens={tokens} onReveal={revealFile} preview={preview} onView={onViewImage} />
        ) : (
          <SyntaxHighlightBlock
            bare
            code={data.code || "// [Empty content or pending stream]"}
            language={data.language ?? "text"}
            // `filename` stays the bare path, because the block reads the
            // grammar from its extension; what is drawn is `filenameNode`.
            filename={displayPath}
            filenameNode={
              data.filePath ? (
                <CodeHeaderPath
                  path={data.filePath}
                  suffix={data.tool === "read" ? (lineRangeLabel(data.offset, data.limit) ?? data.lineRange) : undefined}
                  tokens={tokens}
                  compact={compact}
                  onReveal={revealFile}
                />
              ) : undefined
            }
            tokens={tokens}
            showLineNumbers={Boolean(data.code)}
            onRevealFile={revealFile}
            compact
          />
        ))}

      {data.tool === "edit" && (
        <SyntaxHighlightBlock
            bare
          code={data.diff || data.code || "// [Edit: diff applied]"}
          language="diff"
          filename={displayPath}
          filenameNode={
            data.filePath ? (
              <CodeHeaderPath path={data.filePath} tokens={tokens} compact={compact} onReveal={revealFile} />
            ) : undefined
          }
          tokens={tokens}
          // A diff built from the edit's old and new text names no file lines.
          showLineNumbers={!data.diffFromText}
          onRevealFile={revealFile}
          compact
        />
      )}

      {data.tool === "hub" && data.hub && <HubCallout data={data.hub} tokens={tokens} embedded />}
      {data.tool === "paseo" && data.paseo && <PaseoToolCallout data={data.paseo} tokens={tokens} compact={compact} raw={raw} error={data.error} />}

      {data.tool === "search" && data.search && (
        <View style={styles.section}>
          {data.search.files && data.search.files.length > 0 ? (
            <View>
              {data.search.files.slice(0, MAX_FILE_ROWS).map((file, index) => (
                <View key={`${index}:${file}`} style={styles.fileRow}>
                  <PathText path={file} tokens={tokens} compact={compact} style={{ fontSize: tokens.typography.block.meta.size }} fit />
                </View>
              ))}
              {data.search.files.length > MAX_FILE_ROWS ? (
                <Text style={styles.mutedText}>
                  {`+${data.search.files.length - MAX_FILE_ROWS} more`}
                </Text>
              ) : null}
            </View>
          ) : null}
          {data.search.webResults?.map((row, index) => (
            <View key={`${index}:${row.url}`} style={styles.webRow}>
              <SelectableText numberOfLines={1} style={styles.plainText}>
                {row.title}
              </SelectableText>
              <SelectableText {...(codeSurface as object)} numberOfLines={1} style={[styles.monoText, styles.mutedColor]}>
                {row.url}
              </SelectableText>
            </View>
          ))}
          {/* A web search's own answer: markdown prose, drawn as a fetch's result is. */}
          {data.search.annotations ? (
            <MarkdownView text={data.search.annotations.join("\n\n")} tokens={tokens} variant="compact" streaming={preview && isRunning} size={blockProseBase(tokens.typography)} />
          ) : null}
          {data.search.content ? (
            <View style={styles.terminalWindow}>
              <SelectableText {...selectionCodeText} style={styles.terminalOutput}>
                {renderTerminalOutput(data.search.content, tokens)}
              </SelectableText>
            </View>
          ) : null}
          {!data.search.files && !data.search.webResults && !data.search.annotations && !data.search.content ? (
            <Text style={styles.silentText}>{isRunning ? "Searching…" : "No results."}</Text>
          ) : null}
        </View>
      )}

      {data.tool === "fetch" && data.fetch && (
        <View style={styles.section}>
          <SelectableText {...(codeSurface as object)} style={styles.monoText}>
            {data.fetch.url}
          </SelectableText>
          {data.fetch.prompt ? (
            <SelectableText style={styles.mutedText}>
              {data.fetch.prompt}
            </SelectableText>
          ) : null}
          {data.fetch.result ? (
            <MarkdownView text={data.fetch.result} tokens={tokens} variant="compact" streaming={preview && isRunning} size={blockProseBase(tokens.typography)} />
          ) : (
            <Text style={styles.silentText}>{isRunning ? "Fetching…" : "No content returned."}</Text>
          )}
        </View>
      )}

      {data.tool === "worktree_setup" && data.worktree && (
        <View style={styles.section}>
          {data.worktree.worktreePath ? (
            <PathText path={data.worktree.worktreePath} tokens={tokens} compact={compact} fit style={{ fontSize: tokens.typography.block.label.size }} />
          ) : null}
          {data.worktree.branchName ? (
            <SelectableText {...(codeSurface as object)} style={[styles.monoText, styles.mutedColor]}>
              {data.worktree.branchName}
            </SelectableText>
          ) : null}
          {data.worktree.commands.map((step) => (
            <View key={step.index} style={styles.terminalWindow}>
              <View style={styles.inlineRow}>
                <SelectableText {...(codeSurface as object)} style={[styles.monoText, styles.flex]} numberOfLines={2}>
                  {`$ ${step.command}`}
                </SelectableText>
                {step.status === "running" ? <RunningDot color={tokens.accent} /> : null}
                {step.exitCode !== null && step.status !== "running" ? (
                  <Text style={[styles.metaText, step.exitCode !== 0 && { color: tokens.danger }]}>
                    {exitMark(step.exitCode)}
                  </Text>
                ) : null}
              </View>
              {step.log ? (
                <SelectableText {...selectionCodeText} style={styles.terminalOutput}>
                  {renderTerminalOutput(step.log, tokens)}
                </SelectableText>
              ) : null}
            </View>
          ))}
          {data.worktree.log ? (
            <View style={styles.terminalWindow}>
              <SelectableText {...selectionCodeText} style={styles.terminalOutput}>
                {renderTerminalOutput(data.worktree.log, tokens)}
              </SelectableText>
            </View>
          ) : null}
        </View>
      )}

      {/* The body and its preview show no row, so a verdict leads with the
          host's own plan-card title. */}
      {data.tool === "plan" && (
        <View style={styles.section}>
          {data.planOutcome ? <Text style={styles.sectionTitle}>{PLAN_OUTCOME_TITLE[data.planOutcome]}</Text> : null}
          {data.text ? (
            <MarkdownView text={data.text} tokens={tokens} variant="compact" streaming={preview && isRunning} size={blockProseBase(tokens.typography)} />
          ) : (
            <Text style={styles.silentText}>The plan is empty.</Text>
          )}
        </View>
      )}

      {/* Tool output as text (an ACP or Codex result):
          commands and logs far more often than prose, so it is set in the
          code face, as the row's own target already is. */}
      {data.tool === "plain_text" &&
        (data.text ? (
          <SelectableText {...selectionCodeText} style={styles.commandLine}>
            {data.text}
          </SelectableText>
        ) : (
          <Text style={styles.silentText}>No text.</Text>
        ))}

      {data.tool === "activity" && data.activity ? (
        <View style={styles.section}>
          {data.activity.sections.map((section, index) => (
            <View key={`${index}:${section.label ?? ""}`} style={styles.section}>
              {section.label ? <Text style={styles.sectionTitle}>{section.label}</Text> : null}
              {section.format === "markdown" ? (
                <MarkdownView text={section.text} tokens={tokens} variant="compact" size={blockProseBase(tokens.typography)} />
              ) : section.format === "path" ? (
                <PathText path={section.text} tokens={tokens} compact={compact} onReveal={revealFile} />
              ) : (
                <SyntaxHighlightBlock code={section.text} language={section.language ?? "text"} tokens={tokens} compact bare />
              )}
            </View>
          ))}
        </View>
      ) : null}

      {data.tool === "unknown" && (
        <View style={styles.section}>
          {stringifyValue(data.input) ? (
            <>
              <Text style={styles.sectionTitle}>Input</Text>
              <SyntaxHighlightBlock code={stringifyValue(data.input) ?? ""} language="json" tokens={tokens} compact bare />
            </>
          ) : null}
          {data.output ? (
            <View style={styles.terminalWindow}>
              <SelectableText {...selectionCodeText} style={styles.terminalOutput}>
                {renderTerminalOutput(data.output, tokens)}
              </SelectableText>
            </View>
          ) : (
            <Text style={styles.silentText}>
              {isRunning ? "Waiting for output…" : "The call returned no output."}
            </Text>
          )}
        </View>
      )}

      {!hasTypedBody && (
        <View style={styles.terminalWindow}>
          {data.output ? (
            <SelectableText {...selectionCodeText} style={styles.terminalOutput}>
              {renderTerminalOutput(data.output, tokens)}
            </SelectableText>
          ) : (
            <SelectableText style={styles.silentText}>
              {isRunning ? "Waiting for output…" : "The call returned no output."}
            </SelectableText>
          )}
        </View>
      )}
    </>
  );
}

interface BodyStyles {
  section: ViewStyle;
  inlineRow: ViewStyle;
  flex: ViewStyle;
  fileRow: ViewStyle;
  webRow: ViewStyle;
  terminalWindow: ViewStyle;
  terminalOutput: TextStyle;
  commandLine: TextStyle;
  commandBand: ViewStyle;
  clear: TextStyle;
  silentText: TextStyle;
  sectionTitle: TextStyle;
  plainText: TextStyle;
  mutedText: TextStyle;
  monoText: TextStyle;
  mutedColor: TextStyle;
  promptColor: TextStyle;
  metaText: TextStyle;
  strong: TextStyle;
}

/** Body styles, built only once a card is opened. */
function useBodyStyles(tokens: ExtendedThemeTokens, compact: boolean): BodyStyles {
  return useMemo(
    () =>
      StyleSheet.create({
        section: { gap: 6 },
        inlineRow: { flexDirection: "row", alignItems: "center", gap: 6 },
        flex: { flex: 1, minWidth: 0 },
        fileRow: { height: compact ? 28 : 24, justifyContent: "center" },
        webRow: { gap: 1 },
        // The opened body is already the code surface (S7 3.1): command
        // output sits on it directly, with no inner panel.
        terminalWindow: {
          gap: space.xs,
        },
        terminalOutput: {
          fontFamily: tokens.fontMono,
          fontSize: tokens.typography.mono.size,
          lineHeight: tokens.typography.mono.lineHeight,
          color: tokens.row.outputText,
        },
        commandLine: {
          fontFamily: tokens.fontMono,
          fontSize: tokens.typography.mono.size,
          lineHeight: tokens.typography.mono.lineHeight,
          color: tokens.row.outputText,
        },
        commandBand: { marginBottom: space.xs },
        // A UITextView paints its own white unless told otherwise.
        clear: { backgroundColor: "transparent" },
        silentText: {
          fontFamily: tokens.fontUi,
          fontSize: tokens.typography.block.meta.size,
          color: tokens.foregroundMuted,
          fontStyle: "italic",
          ...unselectable,
        },
        sectionTitle: {
          fontFamily: tokens.fontUi,
          fontSize: tokens.typography.block.meta.size,
          fontWeight: "500",
          color: tokens.foregroundMuted,
          ...unselectable,
        },
        plainText: {
          fontFamily: tokens.fontUi,
          fontSize: tokens.typography.block.label.size,
          lineHeight: tokens.typography.block.delta === 0 ? 19 : tokens.typography.block.label.lineHeight,
          color: tokens.foreground,
        },
        mutedText: {
          fontFamily: tokens.fontUi,
          fontSize: tokens.typography.block.meta.size,
          lineHeight: tokens.typography.block.delta === 0 ? 17 : tokens.typography.block.meta.lineHeight,
          color: tokens.foregroundMuted,
        },
        monoText: {
          fontFamily: tokens.fontMono,
          fontSize: tokens.typography.mono.size,
          color: tokens.foreground,
        },
        mutedColor: { color: tokens.foregroundMuted },
        promptColor: { color: tokens.row.meta },
        metaText: {
          fontFamily: tokens.fontUi,
          fontSize: tokens.typography.block.meta.size,
          color: tokens.foregroundMuted,
          fontVariant: ["tabular-nums"],
          ...unselectable,
        },
        strong: { fontWeight: "600" },
      }),
    [tokens, compact],
  );
}

